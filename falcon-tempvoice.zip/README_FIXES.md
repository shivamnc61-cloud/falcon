# Falcon Premium Bot v2 — Stability & Power Update

## Included fixes
- Giveaway code was left unchanged.
- Fixed the duplicated `on_member_join` handler that was preventing welcome/invite processing from reaching the variable replacement helper.
- No-Prefix remains a **global user setting**: once a user is granted No-Prefix, it works in every server where Falcon is present until expiry/removal.
- Fixed Anti-Nuke owner immunity check (`await is_bot_owner(...)`).
- Invite creation is explicitly **not an Anti-Nuke punishment event**. Creating a normal Discord invite is logged only; it cannot trigger an Anti-Nuke ban.
- AutoMod now stops command processing when it deletes/handles a violating message and uses the requested AutoMod emoji.
- Bot-owner mentions receive the requested crown reaction.
- Added server setup role management: Staff, VIP, Friends, create/list/remove.
- Added server Extra Owner management. Only the bot owner or current Discord server owner can add/remove Extra Owners.
- Added server customization: name/nickname, bio, avatar URL, banner URL, reset. Server owner, Extra Owners, and bot owners can manage it.
- Global bot account avatar/banner remain bot-owner-only because Discord applies those changes to the bot account globally.
- Added `lock all`, `unlock all`, `hide all`, and `unhide all`.
- Added a large Power Command shortcut library, pushing the registered prefix command count above 600 while keeping existing commands intact.
- Added better command error reporting instead of silently swallowing every unexpected command error.
- Added `requirements.txt`.
- Extended per-server autoresponders with contains/exact/starts/ends matching, channel/role filters, per-user cooldowns, response previews, `{delete}`, `{sendto:...}`, and saved `{embed:...}` insertion.
- Added per-server custom prefix commands with role/channel restrictions, cooldowns, `{args}` substitution, response previews, and confirmed deletion.
- Destructive removal of autoresponders, custom commands, saved embeds, greetings, and boost settings now asks for confirmation.
- Added per-server text/voice XP, XP rank cards and leveling-profile displays, XP leaderboards, streaks and daily claims, role rewards, and administration controls. Rank cards and profiles now also track and show eligible per-server voice time. Existing profile and general leaderboard commands remain unchanged; use `,levelprofile` and `,xpleaderboard` for leveling.
- Added configurable event logging for member joins/leaves, kicks, bans/unbans, timeouts, message edits/deletions, voice state changes, and channel/role changes. Configure it with `,eventlog` (alias `,setup_logs`) `enable [#channel]`, `channel #channel`, `status`, and `disable`; managing event logs requires Manage Server.

## Important permissions
For full functionality, give the bot the permissions it actually needs for the features you enable: Manage Channels, Manage Roles, Manage Messages, Kick Members, Ban Members, Moderate Members, Manage Webhooks, View Audit Log, and Send Messages/Embed Links. Enabling Anti-Nuke or AutoMod creates a private `#falcon-security-logs` channel and webhook; the webhook token is stored in the bot's SQLite database, so keep that database private.

## Main new commands
- `,setup` / `,setup create` / `,setup staff` / `,setup vip` / `,setup friends` / `,setup remove all` / `,setup list`
- `,extraowner add @user` / `,extraowner remove @user` / `,extraowner list`
- `,customize name <name>` / `,customize bio <text>` / `,customize avatar <url>` / `,customize banner <url>` / `,customize reset`
- `,lock all` / `,unlock all` / `,hide all` / `,unhide all`
- `,commandcount`

## AutoMod
- `,automod status`
- `,automod enable|disable invite|link|spam|duplicate|mentions|caps|emoji`
- `,automod limit spam <messages 2-20> <seconds 1-30>`
- `,automod limit duplicate <2-20>`
- `,automod limit mentions <1-50>`
- `,automod limit caps <50-100>`
- `,automod limit emoji <1-100>`
- `,automod punishment set <threshold 1-100> <delete|timeout|kick|ban> [timeout_minutes]`
- `,automod punishment remove <threshold>` / `,automod punishment list`
- `,automod violations [member]` / `,automod reset_violations [member]`
- `,automod exempt role|channel add|remove|list [target]`
- `,automod log #channel|off`
- `,automod native` opens the native Discord AutoMod dashboard for keyword, spam, mention, and profanity rules.
- The native AutoMod dashboard includes 7/30-day action counts, recent logs, offender-DM controls, and a toggle for five-violation timeout escalation.
- `,antinuke incidents` shows recent Anti-Nuke incidents; Anti-Nuke also rolls back unauthorized native AutoMod rule changes and detects invite create/delete bursts.
- `,antinuke` opens the dashboard for event guards, recovery settings, escalation mode, and threshold controls; `,antinuke status` retains the text summary.
- `,antinuke snapshots` shows persisted channel/role baselines; `,antinuke snapshot capture` refreshes the baseline.
- `,wl @member` opens the enabled-filter picker with Save, Whitelist All, and Remove All actions.
- `,automodwhitelist add|remove <user>` manages global AutoMod exemptions; `,automodwhitelist list` opens the security dashboard.
- `,securityowner|extraowner add|remove @member` / `,securityowner|extraowner list` (server owner only)
- AutoMod supports configurable flood thresholds, per-filter user exemptions, per-user/role/channel exemptions, and webhook-delivered action logs.
- Configured punishment rules escalate at the selected violation thresholds; counts are per member/server and reset on bot restart. If no escalation rule matches, existing behavior remains (delete violating messages and timeout message floods for five minutes).
- Viewing violation counts requires Manage Messages; configuring rules or resetting counts requires Manage Server. Timeout durations use minutes (1-40320); kick/ban still require the bot's permissions and role hierarchy.
- Emoji-spam detection counts custom and common Unicode emoji and uses a configurable per-message limit.
- The server owner and explicitly configured security owners can manage AutoMod and Anti-Nuke whitelists; only the server owner can appoint security owners.

## Anti-Nuke
Invite creation is deliberately excluded from Anti-Nuke punishment. Protections cover bans/unbans, kicks, bot adds, channel and role create/update/delete, emojis and stickers, role/member updates, role pings, restricted links, integrations, scheduled events, prunes, webhooks, server edits, and @everyone/@here. Unauthorized role pings containing 3 or more roles are removed. The `role_link` Anti-Nuke whitelist event allows trusted users/roles to post links and invites; other members' link/invite messages are removed while this module is enabled.

Enabling Anti-Nuke or AutoMod posts a combined module-status embed to the private security-log webhook and the command channel. The embed reports each Anti-Nuke module, AutoMod filters, recovery settings, punishment type, and the required bot role hierarchy. Automatic ban/quarantine uses a configurable cross-action threshold, and trusted users/roles can be event-scoped in the Anti-Nuke whitelist. Audit lookups share a per-guild request budget to avoid multiplying requests across event types. Channel/role/emoji/sticker/scheduled-event recovery and supported unauthorized-action rollback run immediately where possible.

Discord.py 2.7.1 does not dispatch AutoMod-rule create/update/delete gateway events, so those three protections are explicitly reported as unsupported in the status embed rather than marked enabled. The audit lookup budget and Discord's own API limits can delay or skip enforcement during bursts. Audit attribution requires View Audit Log and a recent, target-matched entry; when attribution is unavailable or rate-limited, the bot does not punish an unknown moderator. Channel/role hierarchy and bot permissions still apply, deleted integrations/webhooks cannot be restored, and all recovery is best-effort rather than guaranteed.

## Denycord-inspired community features
- Persistent ticket panels create private support channels; closing a ticket posts an HTML transcript to the ticket log channel and attempts to DM a copy to the ticket owner. Ticket templates can be set, listed, posted, and deleted.
- Reaction-role mappings assign/remove roles from raw reaction events and enforce Falcon's role hierarchy.
- Birthday announcements and member birthdays are stored per server. Daily announcements are claimed persistently to avoid duplicate sends after restarts; the optional role is removed after 24 hours. Use `,birthday check` for a manual announcement.
- `,livestats setup` creates voice channels for member, human, bot, and boost counts; `,livestats remove` removes the configured channels.
- `,voicehub setup [hub] [panel] [category]` configures an open-by-default join-to-create room system with persistent controls and owner-only room commands; when no hub is supplied, Falcon creates the hub and category. Use `,room info` for the full command list, or `,room set_channel` / `,room set_category` for split configuration.
- `,backup_create <name>` saves a structure backup and attempts to DM a JSON export; `,backup_restore <JSON attachment>` previews a non-destructive restore before confirmation.
- `,serverbackup channel #channel` followed by `enable` schedules hourly structure backups; `now`, `status`, and `disable` manage the schedule. Snapshots are never restored automatically.
- `,reminders_list` and `,reminders_cancel <id>` manage your reminders. Each user can have up to five active reminders per server or DM. Moderators can use `,warnings`, `,clearwarnings`, and `,unwarn`.
- `,afk [reason]` adds an `[AFK]` nickname prefix when Falcon has Manage Nicknames and a higher role; the original nickname is restored when the member sends a message, unless their nickname was changed while AFK.
- `,joinfilter_setup <enabled> [age_days] [no_avatar]` can kick accounts that fail the configured age/avatar requirements and attempts to DM each affected member with the specific reason before removal. A member with closed DMs is still filtered; the DM failure is logged.
