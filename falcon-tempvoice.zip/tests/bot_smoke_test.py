import asyncio
import io
import logging
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock, Mock

import aiosqlite
import discord
from PIL import Image

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def _stub_room_panel_emoji_download(cog, voice_module):
    image_buffer = io.BytesIO()
    Image.new("RGBA", (48, 48), "#F0F2F5").save(image_buffer, format="PNG")
    image_bytes = image_buffer.getvalue()
    cog._load_room_panel_emoji_images = AsyncMock(
        return_value={
            key: image_bytes for key in voice_module.VOICE_BUTTON_EMOJIS
        }
    )


def test_automod_enforcement_and_exemptions() -> None:
    import main as bot_module

    async def verify_automod() -> None:
        bot = bot_module.bot
        original_database = bot.db
        original_event_check = bot_module._an_event_enabled
        original_security_check = bot_module._an_message_security
        original_send = bot_module.send_v2
        database = await aiosqlite.connect(":memory:")
        bot.db = database
        await database.executescript(
            """
            CREATE TABLE automod_settings (
                guild_id INTEGER PRIMARY KEY, enabled INTEGER, anti_invite INTEGER,
                anti_link INTEGER, anti_spam INTEGER, anti_duplicate INTEGER,
                anti_mentions INTEGER, anti_caps INTEGER, anti_emoji INTEGER,
                spam_limit INTEGER, spam_window_seconds INTEGER, duplicate_limit INTEGER,
                mention_limit INTEGER, caps_percent INTEGER, emoji_limit INTEGER,
                log_channel_id INTEGER
            );
            CREATE TABLE automod_channel_whitelist (guild_id INTEGER, channel_id INTEGER);
            CREATE TABLE automod_whitelist (guild_id INTEGER, user_id INTEGER);
            CREATE TABLE automod_filter_whitelist (
                guild_id INTEGER, user_id INTEGER, filter_name TEXT,
                PRIMARY KEY (guild_id, user_id, filter_name)
            );
            CREATE TABLE automod_role_whitelist (guild_id INTEGER, role_id INTEGER);
            CREATE TABLE automod_punishments (
                guild_id INTEGER, violation_threshold INTEGER, action TEXT, duration_minutes INTEGER
            );
            INSERT INTO automod_settings VALUES (1, 1, 1, 0, 0, 0, 0, 0, 0, 2, 5, 3, 5, 80, 12, NULL);
            """
        )
        bot_module._an_event_enabled = AsyncMock(return_value=False)
        bot_module._an_message_security = AsyncMock(return_value=False)
        bot_module.send_v2 = AsyncMock()
        bot.automod_violations.clear()

        def message(content, *, user_id=10, channel_id=20, manage_messages=False):
            author = SimpleNamespace(
                id=user_id,
                bot=False,
                mention=f"<@{user_id}>",
                roles=[],
                guild_permissions=discord.Permissions(manage_messages=manage_messages),
                timeout=AsyncMock(),
                kick=AsyncMock(),
            )
            guild = SimpleNamespace(
                id=1,
                owner_id=99,
                get_channel=lambda _channel_id: None,
            )
            channel = SimpleNamespace(id=channel_id, mention=f"<#${channel_id}>")
            result = SimpleNamespace(
                guild=guild,
                author=author,
                channel=channel,
                content=content,
                mentions=[],
                role_mentions=[],
                mention_everyone=False,
                jump_url="https://discord.test/message",
            )
            result.delete = AsyncMock()
            return result

        try:
            invite = message("Join https://discord.gg/example")
            assert await bot_module._automod_check(invite) is True
            invite.delete.assert_awaited_once()
            bot_module.send_v2.assert_awaited_once()

            await database.execute(
                "INSERT INTO automod_whitelist VALUES (1, 11)"
            )
            await database.commit()
            exempt = message("Join https://discord.gg/exempt", user_id=11)
            assert await bot_module._automod_check(exempt) is False
            exempt.delete.assert_not_awaited()

            await database.execute(
                "UPDATE automod_settings SET anti_invite=0, anti_spam=1, spam_limit=2 WHERE guild_id=1"
            )
            await database.commit()
            first = message("hello", user_id=12)
            second = message("hello again", user_id=12)
            assert await bot_module._automod_check(first) is False
            assert await bot_module._automod_check(second) is True
            second.author.timeout.assert_awaited_once()

            await database.execute(
                "INSERT INTO automod_filter_whitelist VALUES (1, 13, 'spam')"
            )
            await database.commit()
            scoped_first = message("one", user_id=13)
            scoped_second = message("two", user_id=13)
            assert await bot_module._automod_check(scoped_first) is False
            assert await bot_module._automod_check(scoped_second) is False
        finally:
            bot_module._an_event_enabled = original_event_check
            bot_module._an_message_security = original_security_check
            bot_module.send_v2 = original_send
            bot.automod_violations.clear()
            await database.close()
            bot.db = original_database

    asyncio.run(verify_automod())


def test_automod_uses_private_dedicated_log_with_top_avatar(monkeypatch) -> None:
    import main as bot_module

    class FakeTextChannel:
        def __init__(self, channel_id, name):
            self.id = channel_id
            self.name = name
            self.mention = f"<#{channel_id}>"
            self.permission_updates = []
            self.overwrites = {}
            self.edit_calls = []
            self.hooks = []

        async def set_permissions(self, target, **permissions):
            self.permission_updates.append((target, permissions))

        async def edit(self, **kwargs):
            self.edit_calls.append(kwargs)
            self.overwrites = kwargs.get("overwrites", self.overwrites)

        async def webhooks(self):
            return self.hooks

        async def create_webhook(self, name, **_kwargs):
            webhook = FakeWebhook(len(self.hooks) + 1, name)
            self.hooks.append(webhook)
            return webhook

    class FakeWebhook:
        def __init__(self, webhook_id, name):
            self.id = webhook_id
            self.name = name
            self.token = f"token-{webhook_id}"
            self.sent = []

        async def fetch(self):
            return self

        async def send(self, **kwargs):
            self.sent.append(kwargs)

    class FakeRole:
        position = 1
        permissions = SimpleNamespace(administrator=False, manage_guild=True)

        @staticmethod
        def is_default():
            return False

    class FakeGuild:
        id = 7
        default_role = object()
        me = object()
        roles = [FakeRole()]

        def __init__(self, old_channel):
            self.channels = {old_channel.id: old_channel}
            self.text_channels = [old_channel]
            self.created = []

        def get_channel(self, channel_id):
            return self.channels.get(channel_id)

        async def create_text_channel(self, name, **kwargs):
            channel = FakeTextChannel(max(self.channels) + 1, name)
            channel.overwrites = kwargs.get("overwrites", {})
            self.channels[channel.id] = channel
            self.text_channels.append(channel)
            self.created.append((name, kwargs))
            return channel

    async def verify_log_channel() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE automod_settings (guild_id INTEGER PRIMARY KEY, log_channel_id INTEGER);
            CREATE TABLE security_log_webhooks (
                guild_id INTEGER PRIMARY KEY, channel_id INTEGER, webhook_id INTEGER, webhook_token TEXT
            );
            CREATE TABLE security_extra_owners (guild_id INTEGER, user_id INTEGER);
            CREATE TABLE antinuke_v2_settings (guild_id INTEGER PRIMARY KEY, log_channel_id INTEGER);
            CREATE TABLE module_log_webhooks (
                guild_id INTEGER, module TEXT, channel_id INTEGER, webhook_id INTEGER,
                webhook_token TEXT, PRIMARY KEY(guild_id, module)
            );
            INSERT INTO automod_settings VALUES (7, 10);
            INSERT INTO security_log_webhooks VALUES (7, 10, 20, 'token');
            INSERT INTO antinuke_v2_settings VALUES (7, 10);
            """
        )
        avatar_url = "https://cdn.example.test/falcon.png"
        monkeypatch.setattr(
            bot_module,
            "bot",
            SimpleNamespace(db=database, user=SimpleNamespace(display_avatar=SimpleNamespace(url=avatar_url))),
        )
        monkeypatch.setattr(discord, "TextChannel", FakeTextChannel)
        monkeypatch.setattr(
            discord.Webhook,
            "from_url",
            staticmethod(
                lambda url, **_kwargs: next(
                    hook
                    for channel in guild.channels.values()
                    for hook in channel.hooks
                    if url.endswith(f"/{hook.id}/{hook.token}")
                )
            ),
        )
        send = AsyncMock()
        monkeypatch.setattr(bot_module, "send_v2", send)

        old_channel = FakeTextChannel(10, "falcon-security-logs")
        guild = FakeGuild(old_channel)
        try:
            log_channel = await bot_module._ensure_automod_log(guild)
            assert log_channel.name == "falcon-automod-log"
            assert guild.created[0][0] == "falcon-automod-log"
            overwrites = guild.created[0][1]["overwrites"]
            assert overwrites[guild.default_role].view_channel is False
            assert overwrites[guild.me].view_channel is True
            assert not log_channel.permission_updates
            await bot_module._ensure_automod_log(guild)
            assert not log_channel.edit_calls
            log_channel.overwrites[guild.default_role] = discord.PermissionOverwrite(view_channel=True)
            await bot_module._ensure_automod_log(guild)
            assert len(log_channel.edit_calls) == 1

            async with database.execute(
                "SELECT log_channel_id FROM automod_settings WHERE guild_id=7"
            ) as cursor:
                assert await cursor.fetchone() == (11,)
            async with database.execute(
                "SELECT log_channel_id FROM antinuke_v2_settings WHERE guild_id=7"
            ) as cursor:
                assert await cursor.fetchone() == (10,)

            antinuke_channel = await bot_module._ensure_antinuke_log(guild)
            assert antinuke_channel.name == "falcon-antinuke-log"
            assert antinuke_channel.id != log_channel.id
            async with database.execute(
                "SELECT log_channel_id FROM antinuke_v2_settings WHERE guild_id=7"
            ) as cursor:
                assert await cursor.fetchone() == (antinuke_channel.id,)

            message = SimpleNamespace(
                guild=guild,
                author=SimpleNamespace(id=3, mention="<@3>"),
                channel=SimpleNamespace(mention="<#30>"),
                jump_url="https://discord.test/messages/1",
            )
            await bot_module._automod_log(
                message,
                "Invite link",
                violation_count=1,
                punishment="Message deleted",
            )
            assert not send.await_count
            assert len(log_channel.hooks[0].sent) == 1
            webhook_payload = log_channel.hooks[0].sent[0]
            log_embed = webhook_payload["embed"]
            assert webhook_payload["username"] == "Falcon AutoMod Logs"
            assert webhook_payload["avatar_url"] == avatar_url
            assert log_embed.thumbnail.url == avatar_url
        finally:
            await database.close()

    asyncio.run(verify_log_channel())


def test_automod_enable_sends_only_automod_log(monkeypatch) -> None:
    import main as bot_module

    async def verify_enable_log() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE automod_settings (guild_id INTEGER PRIMARY KEY, enabled INTEGER, "
            "anti_invite INTEGER, anti_link INTEGER, anti_spam INTEGER, anti_duplicate INTEGER, "
            "anti_mentions INTEGER, anti_caps INTEGER, anti_emoji INTEGER)"
        )
        await database.commit()
        channel = SimpleNamespace(id=11, mention="<#11>")
        write_log = AsyncMock()
        monkeypatch.setattr(bot_module, "bot", SimpleNamespace(db=database, user=None))
        monkeypatch.setattr(bot_module, "_ensure_falcon_protection_role", AsyncMock(return_value=None))
        monkeypatch.setattr(bot_module, "_ensure_automod_log", AsyncMock(return_value=channel))
        monkeypatch.setattr(bot_module, "_send_security_log", write_log)
        ctx = SimpleNamespace(
            guild=SimpleNamespace(id=7),
            author=SimpleNamespace(
                id=3,
                mention="<@3>",
                guild_permissions=discord.Permissions(manage_guild=True),
            ),
            send=AsyncMock(),
        )
        try:
            await bot_module.automod_cmd.callback(ctx, "enable")
            write_log.assert_awaited_once()
            assert write_log.await_args.args[:2] == (ctx.guild, channel)
            log_embed = write_log.await_args.args[2]
            assert log_embed.title == "AutoMod Enabled"
            assert "Anti-Nuke" not in log_embed.description
            assert log_embed.fields[0].name == "Filter Status"
            response_embed = ctx.send.await_args.kwargs["embed"]
            assert response_embed.title == "AutoMod Enabled"
            assert channel.mention in response_embed.description
        finally:
            await database.close()

    asyncio.run(verify_enable_log())


def test_native_automod_syncs_and_pauses_a_discord_rule() -> None:
    import native_automod

    class FakeRule:
        def __init__(self, rule_id, **payload):
            self.id = rule_id
            self.name = payload["name"]
            self.payload = payload
            self.edits = []

        async def edit(self, **payload):
            self.edits.append(payload)

    class FakeGuild:
        id = 7

        def __init__(self):
            self.rules = []
            self.created = []

        def get_role(self, _role_id):
            return None

        def get_channel(self, _channel_id):
            return None

        async def fetch_automod_rules(self):
            return self.rules

        async def create_automod_rule(self, **payload):
            rule = FakeRule(44, **payload)
            self.rules.append(rule)
            self.created.append(payload)
            return rule

    async def verify_native_rule_sync() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE automod_settings (guild_id INTEGER PRIMARY KEY, log_channel_id INTEGER)"
        )
        await database.execute("INSERT INTO automod_settings VALUES (7, 55)")
        await database.commit()
        cog = native_automod.NativeAutoMod(SimpleNamespace(db=database, user=None))
        await cog.cog_load()
        guild = FakeGuild()
        try:
            view = native_automod.NativeAutoModView(cog, guild, owner_id=3)
            await view.load_module()
            assert view.make_embed().title == "Falcon Native AutoMod"
            assert view.channel_select.max_values == 25

            await cog.save_rule_config(
                guild.id,
                "spam",
                enabled=True,
                mode="block",
                exempt_roles=[],
                exempt_channels=[],
            )
            rule_id = await cog.sync_rule(guild, "spam")
            assert rule_id == 44
            assert len(guild.created) == 1
            payload = guild.created[0]
            assert payload["name"] == "Falcon AutoMod · Spam"
            assert payload["trigger"].type == discord.AutoModRuleTriggerType.spam
            assert payload["enabled"] is True
            assert {action.type for action in payload["actions"]} == {
                discord.AutoModRuleActionType.block_message,
                discord.AutoModRuleActionType.send_alert_message,
            }

            await cog.save_rule_config(
                guild.id,
                "spam",
                enabled=False,
                mode="block",
                exempt_roles=[],
                exempt_channels=[],
                rule_id=rule_id,
            )
            await cog.sync_rule(guild, "spam")
            assert len(guild.created) == 1
            assert guild.rules[0].edits[-1]["enabled"] is False
            config = await cog.get_rule_config(guild.id, "spam")
            assert config["rule_id"] == 44
            assert config["enabled"] is False

            keyword_rule = FakeRule(45, name="Falcon AutoMod · Keyword", enabled=True)
            guild.rules.append(keyword_rule)
            await cog.save_rule_config(
                guild.id,
                "keyword",
                enabled=False,
                mode="block",
                exempt_roles=[],
                exempt_channels=[],
                rule_id=45,
            )
            await cog.sync_rule(guild, "keyword")
            assert keyword_rule.edits[-1]["enabled"] is False
        finally:
            await database.close()

    asyncio.run(verify_native_rule_sync())


def test_antinuke_strips_dangerous_permissions_from_linked_roles(monkeypatch) -> None:
    import main as bot_module

    async def verify_linked_role_sanitization() -> None:
        guild = SimpleNamespace(id=7)
        executor = SimpleNamespace(id=22, mention="<@22>")
        audit_entry = SimpleNamespace(user=executor)
        monkeypatch.setattr(bot_module, "_an_event_enabled", AsyncMock(return_value=True))
        monkeypatch.setattr(bot_module, "_an_can_fetch", lambda *_args: True)
        monkeypatch.setattr(bot_module, "_an_audit", AsyncMock(return_value=audit_entry))
        monkeypatch.setattr(bot_module, "_an_is_immune", AsyncMock(return_value=False))
        monkeypatch.setattr(bot_module, "_an_punish", AsyncMock(return_value="banned"))
        write_log = AsyncMock()
        monkeypatch.setattr(bot_module, "_an_log", write_log)
        role = SimpleNamespace(
            id=70,
            name="Linked Role",
            guild=guild,
            tags=SimpleNamespace(is_guild_connection=lambda: True),
            permissions=discord.Permissions(administrator=True, manage_roles=True),
            edit=AsyncMock(),
        )
        await bot_module.antinuke_linked_role_create(role)
        role.edit.assert_awaited_once()
        safe_permissions = role.edit.await_args.kwargs["permissions"]
        assert not safe_permissions.administrator
        assert not safe_permissions.manage_roles
        write_log.assert_awaited_once()

        ordinary_role = SimpleNamespace(
            id=71,
            name="Ordinary Role",
            guild=guild,
            tags=SimpleNamespace(is_guild_connection=lambda: False),
            permissions=discord.Permissions(administrator=True),
            edit=AsyncMock(),
        )
        await bot_module.antinuke_linked_role_create(ordinary_role)
        ordinary_role.edit.assert_not_awaited()

    asyncio.run(verify_linked_role_sanitization())


def test_antinuke_invite_bursts_are_cleaned_and_logged(monkeypatch) -> None:
    import main as bot_module

    async def verify_invite_bursts() -> None:
        guild = SimpleNamespace(id=7)
        inviter = SimpleNamespace(id=22, mention="<@22>")
        monkeypatch.setattr(bot_module, "_an_event_enabled", AsyncMock(return_value=True))
        monkeypatch.setattr(bot_module, "_an_is_immune", AsyncMock(return_value=False))
        punish = AsyncMock(return_value="banned")
        write_log = AsyncMock()
        monkeypatch.setattr(bot_module, "_an_punish", punish)
        monkeypatch.setattr(bot_module, "_an_log", write_log)
        create_key = (guild.id, inviter.id)
        previous_creates = list(bot_module._AN_INVITE_CREATES[create_key])
        previous_risk = list(bot_module._AN_RISK_TRACKER[create_key])
        bot_module._AN_INVITE_CREATES[create_key].clear()
        bot_module._AN_RISK_TRACKER[create_key].clear()
        try:
            invites = [
                SimpleNamespace(
                    guild=guild,
                    inviter=inviter,
                    code=f"invite-{index}",
                    delete=AsyncMock(),
                )
                for index in range(5)
            ]
            for invite in invites[:4]:
                await bot_module.antinuke_invite_create(invite)
            punish.assert_not_awaited()
            for invite in invites[4:]:
                await bot_module.antinuke_invite_create(invite)
            for invite in invites:
                invite.delete.assert_awaited_once()
            punish.assert_awaited_once()
            assert punish.await_args.kwargs["event_name"] == "invite_create"
            assert len(bot_module._AN_RISK_TRACKER[create_key]) >= 5
            write_log.assert_awaited_once()

            entry = SimpleNamespace(user=inviter)
            monkeypatch.setattr(bot_module, "_an_can_fetch", lambda *_args: True)
            audit = AsyncMock(return_value=entry)
            monkeypatch.setattr(bot_module, "_an_audit", audit)
            delete_key = (guild.id, inviter.id)
            previous_deletes = list(bot_module._AN_INVITE_DELETES[delete_key])
            bot_module._AN_INVITE_DELETES[delete_key].clear()
            bot_module._AN_RISK_TRACKER[delete_key].clear()
            try:
                for index in range(5):
                    await bot_module.antinuke_invite_delete(
                        SimpleNamespace(guild=guild, code=f"removed-{index}")
                    )
                assert audit.await_count == 5
                assert audit.await_args.args[1] == discord.AuditLogAction.invite_delete
                assert punish.await_count == 2
                assert punish.await_args.kwargs["event_name"] == "invite_delete"
                assert len(bot_module._AN_RISK_TRACKER[delete_key]) >= 5
                assert write_log.await_count == 2
            finally:
                bot_module._AN_INVITE_DELETES.pop(delete_key, None)
                if previous_deletes:
                    bot_module._AN_INVITE_DELETES[delete_key].extend(previous_deletes)
                bot_module._AN_RISK_TRACKER[delete_key].clear()
                bot_module._AN_RISK_TRACKER[delete_key].extend(previous_risk)
        finally:
            bot_module._AN_INVITE_CREATES.pop(create_key, None)
            if previous_creates:
                bot_module._AN_INVITE_CREATES[create_key].extend(previous_creates)
            bot_module._AN_RISK_TRACKER[create_key].clear()
            bot_module._AN_RISK_TRACKER[create_key].extend(previous_risk)

    asyncio.run(verify_invite_bursts())


def test_antinuke_automod_rule_events_rollback_and_log(monkeypatch) -> None:
    import main as bot_module

    async def verify_rule_protection() -> None:
        guild = SimpleNamespace(id=7)
        executor = SimpleNamespace(id=22, mention="<@22>")
        audit_entry = SimpleNamespace(user=executor)
        monkeypatch.setattr(bot_module, "_an_event_enabled", AsyncMock(return_value=True))
        monkeypatch.setattr(bot_module, "_an_can_fetch", lambda *_args: True)
        monkeypatch.setattr(bot_module, "_an_audit", AsyncMock(return_value=audit_entry))
        monkeypatch.setattr(bot_module, "_an_is_immune", AsyncMock(return_value=False))
        monkeypatch.setattr(bot_module, "_an_punish", AsyncMock(return_value="banned"))
        write_log = AsyncMock()
        monkeypatch.setattr(bot_module, "_an_log", write_log)

        created_rule = SimpleNamespace(
            id=100,
            name="Untrusted rule",
            guild=guild,
            delete=AsyncMock(),
        )
        await bot_module.antinuke_automod_rule_create(created_rule)
        created_rule.delete.assert_awaited_once()

        original_rule = SimpleNamespace(
            id=101,
            name="Protected rule",
            guild=guild,
            event_type=discord.AutoModRuleEventType.message_send,
            trigger=SimpleNamespace(type=discord.AutoModRuleTriggerType.keyword),
            actions=[],
            enabled=True,
            exempt_roles=[],
            exempt_channels=[],
            edit=AsyncMock(),
        )
        changed_rule = SimpleNamespace(
            id=101,
            name="Protected rule",
            guild=guild,
            trigger=SimpleNamespace(type=discord.AutoModRuleTriggerType.keyword_preset),
            actions=[SimpleNamespace(type=discord.AutoModRuleActionType.block_message)],
            exempt_roles=[],
            exempt_channels=[],
        )
        await bot_module.antinuke_automod_rule_update(original_rule, changed_rule)
        original_rule.edit.assert_awaited_once()
        assert original_rule.edit.await_args.kwargs["trigger"] is original_rule.trigger

        restored_rule = SimpleNamespace(id=102)
        guild.create_automod_rule = AsyncMock(return_value=restored_rule)
        deleted_rule = SimpleNamespace(
            id=103,
            name="Deleted protected rule",
            guild=guild,
            event_type=discord.AutoModRuleEventType.message_send,
            trigger=discord.AutoModTrigger(type=discord.AutoModRuleTriggerType.spam),
            actions=[
                discord.AutoModRuleAction(
                    type=discord.AutoModRuleActionType.block_message,
                    custom_message="Blocked",
                )
            ],
            enabled=True,
            exempt_roles=[],
            exempt_channels=[],
        )
        await bot_module.antinuke_automod_rule_delete(deleted_rule)
        guild.create_automod_rule.assert_awaited_once()
        assert guild.create_automod_rule.await_args.kwargs["name"] == deleted_rule.name
        assert write_log.await_count == 3

    asyncio.run(verify_rule_protection())


def test_native_automod_action_is_logged_and_dashboard_route_opens(monkeypatch) -> None:
    import main as bot_module
    import native_automod

    async def verify_native_action_log() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE automod_settings (guild_id INTEGER PRIMARY KEY, log_channel_id INTEGER)"
        )
        await database.execute("INSERT INTO automod_settings VALUES (7, 12)")
        await database.commit()
        channel = SimpleNamespace(id=12)
        guild = SimpleNamespace(
            id=7,
            name="Test Guild",
            owner_id=1,
            get_channel=lambda channel_id: channel if channel_id == 12 else None,
        )
        bot = SimpleNamespace(db=database, user=None)
        cog = native_automod.NativeAutoMod(bot)
        await cog.cog_load()
        await cog.save_rule_config(
            7,
            "spam",
            enabled=True,
            mode="block",
            exempt_roles=[],
            exempt_channels=[],
            rule_id=99,
        )
        member = SimpleNamespace(id=42, mention="<@42>", send=AsyncMock())
        execution = SimpleNamespace(
            guild=guild,
            guild_id=7,
            rule_id=99,
            user_id=42,
            channel_id=12,
            member=member,
            action=SimpleNamespace(type=discord.AutoModRuleActionType.block_message),
            matched_keyword="blocked phrase",
            matched_content=None,
        )
        write_log = AsyncMock()
        monkeypatch.setattr(bot_module, "_send_security_log", write_log)
        edit_dashboard = AsyncMock()
        monkeypatch.setattr(native_automod, "edit_interaction_v2", edit_dashboard)
        try:
            await cog.on_automod_action(execution)
            async with database.execute(
                "SELECT module, action, matched_keyword FROM native_automod_violations"
            ) as cursor:
                assert await cursor.fetchone() == ("Spam", "Block Message", "blocked phrase")
            write_log.assert_awaited_once()
            log_embed = write_log.await_args.args[2]
            assert log_embed.title == "AutoMod Action"
            assert "**Module:** Spam" in log_embed.description
            assert "blocked phrase" in log_embed.description

            assert await cog.get_settings(7) == (False, True)
            await cog.save_settings(7, dm_enabled=True, escalation_enabled=False)
            cog._escalate = AsyncMock()
            await cog.on_automod_action(execution)
            member.send.assert_awaited_once()
            cog._escalate.assert_not_awaited()

            view = native_automod.NativeAutoModView(cog, guild, owner_id=3)
            view.module = "spam"
            await view.load_module()
            fields = {field.name: field.value for field in view.make_embed().fields}
            assert fields["7-Day Actions"] == "2"
            assert fields["30-Day Actions"] == "2"
            assert fields["Offender DMs"] == "ON"
            assert fields["Repeat Escalation"] == "OFF"
            assert "<@42>" in fields["Recent Logs"]
            assert "Block Message" in fields["Recent Logs"]

            interaction = SimpleNamespace(user=SimpleNamespace(id=3))
            dm_button = next(
                item for item in view.children if getattr(item, "label", None) == "Toggle DMs"
            )
            escalation_button = next(
                item for item in view.children if getattr(item, "label", None) == "Toggle Escalation"
            )
            await dm_button.callback(interaction)
            await escalation_button.callback(interaction)
            assert await cog.get_settings(7) == (False, True)
            assert edit_dashboard.await_count == 2
        finally:
            await database.close()

    async def verify_dashboard_route() -> None:
        manager = SimpleNamespace(open_dashboard=AsyncMock())
        original_bot = bot_module.bot
        monkeypatch.setattr(
            bot_module,
            "bot",
            SimpleNamespace(get_cog=lambda name: manager if name == "NativeAutoMod" else None),
        )
        ctx = SimpleNamespace(
            guild=SimpleNamespace(id=7),
            author=SimpleNamespace(
                guild_permissions=discord.Permissions(manage_guild=True)
            ),
            send=AsyncMock(),
        )
        try:
            await bot_module.automod_cmd.callback(ctx, "native")
            manager.open_dashboard.assert_awaited_once_with(ctx)
        finally:
            bot_module.bot = original_bot

    asyncio.run(verify_native_action_log())
    asyncio.run(verify_dashboard_route())


def test_antinuke_enable_uses_own_embed_and_log_channel(monkeypatch) -> None:
    import main as bot_module

    async def verify_enable_log() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE antinuke_settings (guild_id INTEGER PRIMARY KEY, enabled INTEGER)"
        )
        await database.execute(
            "CREATE TABLE antinuke_v2_events (guild_id INTEGER, event_name TEXT, enabled INTEGER)"
        )
        await database.commit()
        channel = SimpleNamespace(id=12, mention="<#12>")
        write_log = AsyncMock()
        monkeypatch.setattr(bot_module, "bot", SimpleNamespace(db=database, user=None))
        monkeypatch.setattr(bot_module, "_ensure_falcon_protection_role", AsyncMock(return_value=None))
        monkeypatch.setattr(bot_module, "_ensure_antinuke_log", AsyncMock(return_value=channel))
        monkeypatch.setattr(bot_module, "_send_security_log", write_log)
        ctx = SimpleNamespace(
            guild=SimpleNamespace(id=7),
            author=SimpleNamespace(
                id=3,
                mention="<@3>",
                guild_permissions=discord.Permissions(administrator=True),
            ),
            send=AsyncMock(),
        )
        try:
            await bot_module.antinuke_cmd.callback(ctx, "enable")
            write_log.assert_awaited_once()
            assert write_log.await_args.args[:2] == (ctx.guild, channel)
            log_embed = write_log.await_args.args[2]
            response_embed = ctx.send.await_args.kwargs["embed"]
            assert log_embed.title == "Anti-Nuke Enabled"
            assert "AutoMod" not in log_embed.description
            assert channel.mention in log_embed.description
            assert log_embed.fields[0].name == "Event Guards"
            assert response_embed.title == "Anti-Nuke Enabled"
        finally:
            await database.close()

    asyncio.run(verify_enable_log())


def test_antinuke_log_persists_risk_scored_incident(monkeypatch) -> None:
    import main as bot_module

    async def verify_incident_log() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE antinuke_v2_settings (guild_id INTEGER PRIMARY KEY, "
            "log_channel_id INTEGER, action_threshold INTEGER, action_window_seconds INTEGER)"
        )
        await database.execute(
            "CREATE TABLE antinuke_incidents ("
            "incident_id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER, event_name TEXT, "
            "executor_id INTEGER, severity TEXT, risk_score INTEGER, event_count INTEGER, "
            "reason TEXT, created_at TEXT)"
        )
        await database.execute("INSERT INTO antinuke_v2_settings VALUES (7, 12, 3, 10)")
        await database.commit()
        channel = SimpleNamespace(id=12)
        guild = SimpleNamespace(id=7, get_channel=lambda _channel_id: channel, system_channel=None)
        executor = SimpleNamespace(id=22, mention="<@22>")
        write_log = AsyncMock()
        monkeypatch.setattr(bot_module, "bot", SimpleNamespace(db=database, user=None))
        monkeypatch.setattr(bot_module, "_send_security_log", write_log)
        key = (guild.id, executor.id)
        bucket = bot_module._AN_RISK_TRACKER[key]
        previous = list(bucket)
        try:
            now = asyncio.get_running_loop().time()
            bucket.clear()
            bucket.extend((now - 2, now - 1, now))
            await bot_module._an_log(guild, "Channel Deleted", executor, "Channel restored; executor banned.")
            async with database.execute(
                "SELECT severity, risk_score, event_count, event_name FROM antinuke_incidents"
            ) as cursor:
                assert await cursor.fetchone() == ("CRITICAL", 100, 3, "Channel Deleted")
            write_log.assert_awaited_once()
            incident_embed = write_log.await_args.args[2]
            assert "Risk:** 100/100" in incident_embed.description
            assert "Activity:** 3/3 event(s) in 10s" in incident_embed.description
            assert incident_embed.footer.text.endswith("Incident #1")
        finally:
            bucket.clear()
            bucket.extend(previous)
            await database.close()

    asyncio.run(verify_incident_log())


def test_antinuke_snapshots_persist_channel_and_role_baselines(monkeypatch) -> None:
    import json

    import main as bot_module

    async def verify_snapshots() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE antinuke_resource_snapshots ("
            "guild_id INTEGER, resource_type TEXT, resource_id INTEGER, resource_name TEXT, "
            "snapshot TEXT, captured_at TEXT, PRIMARY KEY(guild_id,resource_type,resource_id))"
        )
        await database.commit()
        channel = SimpleNamespace(
            id=80,
            name="general",
            type=discord.ChannelType.text,
            position=2,
            category_id=None,
            topic="welcome",
            nsfw=False,
            slowmode_delay=4,
            bitrate=None,
            user_limit=None,
            overwrites={},
        )
        default_role = SimpleNamespace(is_default=lambda: True, managed=False)
        role = SimpleNamespace(
            id=81,
            name="Moderator",
            is_default=lambda: False,
            managed=False,
            color=SimpleNamespace(value=0x123456),
            hoist=True,
            mentionable=False,
            permissions=discord.Permissions(manage_messages=True),
            position=3,
        )
        guild = SimpleNamespace(id=7, channels=[channel], roles=[default_role, role])
        original_bot = bot_module.bot
        monkeypatch.setattr(bot_module, "bot", SimpleNamespace(db=database))
        try:
            assert await bot_module._snapshot_guild_resources(guild) == 2
            async with database.execute(
                "SELECT resource_type,resource_name,snapshot FROM antinuke_resource_snapshots "
                "WHERE guild_id=7 ORDER BY resource_type"
            ) as cursor:
                rows = await cursor.fetchall()
            assert [(row[0], row[1]) for row in rows] == [
                ("channel", "general"),
                ("role", "Moderator"),
            ]
            role_snapshot = json.loads(rows[1][2])
            assert role_snapshot["permissions"] == role.permissions.value
            assert role_snapshot["position"] == 3

            context = SimpleNamespace(
                guild=guild,
                author=SimpleNamespace(guild_permissions=discord.Permissions(administrator=True)),
                send=AsyncMock(),
            )
            await bot_module.antinuke_cmd.callback(context, "snapshots")
            assert context.send.await_args.kwargs["embed"].title == "Anti-Nuke Resource Snapshots"
            assert "Moderator" in context.send.await_args.kwargs["embed"].description
        finally:
            bot_module.bot = original_bot
            await database.close()

    asyncio.run(verify_snapshots())


def test_security_whitelist_dashboard_updates_all_stores(monkeypatch) -> None:
    import main as bot_module

    async def verify_whitelist_updates() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE automod_whitelist (guild_id INTEGER, user_id INTEGER, PRIMARY KEY(guild_id, user_id));
            CREATE TABLE automod_role_whitelist (guild_id INTEGER, role_id INTEGER, PRIMARY KEY(guild_id, role_id));
            CREATE TABLE automod_channel_whitelist (guild_id INTEGER, channel_id INTEGER, PRIMARY KEY(guild_id, channel_id));
            CREATE TABLE antinuke_v2_whitelist (guild_id INTEGER, user_id INTEGER, events TEXT, PRIMARY KEY(guild_id, user_id));
            CREATE TABLE antinuke_v2_role_whitelist (guild_id INTEGER, role_id INTEGER, events TEXT, PRIMARY KEY(guild_id, role_id));
            CREATE TABLE antinuke_settings (guild_id INTEGER PRIMARY KEY, whitelist TEXT DEFAULT '');
            INSERT INTO antinuke_settings VALUES (7, '99');
            """
        )
        monkeypatch.setattr(bot_module, "bot", SimpleNamespace(db=database))
        edit_interaction = AsyncMock()
        monkeypatch.setattr(bot_module, "edit_interaction_v2", edit_interaction)
        guild = SimpleNamespace(id=7)
        panel_context = SimpleNamespace(
            guild=SimpleNamespace(id=7, owner_id=3),
            author=SimpleNamespace(id=3),
            send=AsyncMock(),
        )
        await bot_module.automod_whitelist_cmd.callback(panel_context)
        assert isinstance(panel_context.send.await_args.kwargs["view"], bot_module.SecurityWhitelistView)
        view = bot_module.SecurityWhitelistView(guild, owner_id=3)
        try:
            initial = await view._build_embed()
            assert len(initial.fields) == 5
            view.scope_select._values = ["antinuke_users"]
            interaction = SimpleNamespace()
            await view.select_scope(interaction)
            edit_interaction.assert_awaited_once()
            assert edit_interaction.await_args.kwargs["view"] is view
            assert [field.name.split(" (")[0] for field in edit_interaction.await_args.kwargs["embed"].fields] == ["Anti-Nuke users"]

            view.selected_target = ("user", 42, "<@42>")
            await view._apply_target(add=True)
            async with database.execute("SELECT user_id FROM automod_whitelist WHERE guild_id=7") as cursor:
                assert await cursor.fetchall() == [(42,)]
            async with database.execute("SELECT user_id, events FROM antinuke_v2_whitelist WHERE guild_id=7") as cursor:
                assert await cursor.fetchall() == [(42, "*")]
            async with database.execute("SELECT whitelist FROM antinuke_settings WHERE guild_id=7") as cursor:
                assert await cursor.fetchone() == ("42,99",)
            assert "whitelisted across supported systems" in view.notice
            assert "<@42>" in (await view._build_embed()).description

            await view._apply_target(add=False)
            async with database.execute("SELECT user_id FROM automod_whitelist WHERE guild_id=7") as cursor:
                assert await cursor.fetchall() == []
            async with database.execute("SELECT user_id FROM antinuke_v2_whitelist WHERE guild_id=7") as cursor:
                assert await cursor.fetchall() == []
            async with database.execute("SELECT whitelist FROM antinuke_settings WHERE guild_id=7") as cursor:
                assert await cursor.fetchone() == ("99",)

            view.selected_target = ("role", 55, "<@&55>")
            await view._apply_target(add=True)
            async with database.execute("SELECT events FROM antinuke_v2_role_whitelist WHERE guild_id=7 AND role_id=55") as cursor:
                assert await cursor.fetchone() == ("*",)
            view.selected_target = ("channel", 66, "<#66>")
            await view._apply_target(add=True)
            async with database.execute("SELECT channel_id FROM automod_channel_whitelist WHERE guild_id=7") as cursor:
                assert await cursor.fetchall() == [(66,)]
        finally:
            await database.close()

    asyncio.run(verify_whitelist_updates())


def test_member_automod_whitelist_picker_saves_multiple_filters(monkeypatch) -> None:
    import main as bot_module

    async def verify_member_filter_whitelist() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE automod_settings (
                guild_id INTEGER PRIMARY KEY, enabled INTEGER, anti_invite INTEGER,
                anti_link INTEGER, anti_spam INTEGER, anti_duplicate INTEGER,
                anti_mentions INTEGER, anti_caps INTEGER, anti_emoji INTEGER
            );
            CREATE TABLE automod_whitelist (guild_id INTEGER, user_id INTEGER, PRIMARY KEY(guild_id, user_id));
            CREATE TABLE automod_filter_whitelist (
                guild_id INTEGER, user_id INTEGER, filter_name TEXT,
                PRIMARY KEY(guild_id, user_id, filter_name)
            );
            INSERT INTO automod_settings VALUES (7, 1, 1, 0, 1, 0, 0, 0, 1);
            """
        )
        member = SimpleNamespace(id=42, mention="<@42>")
        guild = SimpleNamespace(id=7, owner_id=3)
        context = SimpleNamespace(
            guild=guild,
            author=SimpleNamespace(id=3),
            message=SimpleNamespace(mentions=[member], reference=None),
            send=AsyncMock(),
        )
        monkeypatch.setattr(bot_module, "bot", SimpleNamespace(db=database, user=None))
        monkeypatch.setattr(
            bot_module,
            "_resolve_context_member",
            AsyncMock(return_value=member),
        )
        edit_interaction = AsyncMock()
        monkeypatch.setattr(bot_module, "edit_interaction_v2", edit_interaction)
        try:
            await bot_module.automod_whitelist_cmd.callback(context, arguments="<@42>")
            view = context.send.await_args.kwargs["view"]
            assert isinstance(view, bot_module.AutoModMemberWhitelistView)
            assert {option.value for option in view.filter_select.options} == {"invite", "spam", "emoji"}
            assert {item.label for item in view.children if isinstance(item, discord.ui.Button)} == {
                "Save", "Whitelist All", "Remove All"
            }

            view.filter_select._values = ["spam", "emoji"]
            interaction = SimpleNamespace(user=SimpleNamespace(id=3))
            await view.select_filters(interaction)
            save_button = next(item for item in view.children if getattr(item, "label", None) == "Save")
            await save_button.callback(interaction)
            async with database.execute(
                "SELECT filter_name FROM automod_filter_whitelist WHERE guild_id=7 AND user_id=42"
            ) as cursor:
                assert {row[0] for row in await cursor.fetchall()} == {"spam", "emoji"}
            async with database.execute(
                "SELECT user_id FROM automod_whitelist WHERE guild_id=7"
            ) as cursor:
                assert await cursor.fetchall() == []

            all_button = next(
                item for item in view.children if getattr(item, "label", None) == "Whitelist All"
            )
            await all_button.callback(interaction)
            async with database.execute(
                "SELECT user_id FROM automod_whitelist WHERE guild_id=7"
            ) as cursor:
                assert await cursor.fetchall() == [(42,)]
            async with database.execute(
                "SELECT filter_name FROM automod_filter_whitelist WHERE guild_id=7 AND user_id=42"
            ) as cursor:
                assert await cursor.fetchall() == []

            remove_button = next(
                item for item in view.children if getattr(item, "label", None) == "Remove All"
            )
            await remove_button.callback(interaction)
            async with database.execute(
                "SELECT user_id FROM automod_whitelist WHERE guild_id=7"
            ) as cursor:
                assert await cursor.fetchall() == []
        finally:
            await database.close()

    asyncio.run(verify_member_filter_whitelist())


def test_antinuke_event_all_toggles_every_guard(monkeypatch) -> None:
    import main as bot_module

    async def verify_event_toggle() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE antinuke_v2_events (guild_id INTEGER, event_name TEXT, enabled INTEGER, "
            "PRIMARY KEY(guild_id, event_name))"
        )
        await database.commit()
        monkeypatch.setattr(bot_module, "bot", SimpleNamespace(db=database))
        ctx = SimpleNamespace(
            guild=SimpleNamespace(id=7),
            author=SimpleNamespace(guild_permissions=discord.Permissions(administrator=True)),
            send=AsyncMock(),
        )
        try:
            await bot_module.antinuke_cmd.callback(ctx, "event", "all", "off")
            async with database.execute(
                "SELECT event_name, enabled FROM antinuke_v2_events WHERE guild_id=7"
            ) as cursor:
                rows = await cursor.fetchall()
            assert len(rows) == len(bot_module.ANTINUKE_EVENTS)
            assert {enabled for _event_name, enabled in rows} == {0}

            await bot_module.antinuke_cmd.callback(ctx, "event", "all", "on")
            async with database.execute(
                "SELECT enabled FROM antinuke_v2_events WHERE guild_id=7"
            ) as cursor:
                assert {row[0] for row in await cursor.fetchall()} == {1}
        finally:
            await database.close()

    asyncio.run(verify_event_toggle())


def test_antinuke_dashboard_persists_event_and_punishment_controls(monkeypatch) -> None:
    import main as bot_module
    import antinuke_dashboard

    async def verify_dashboard_controls() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE antinuke_settings (guild_id INTEGER PRIMARY KEY, enabled INTEGER);
            CREATE TABLE antinuke_v2_events (
                guild_id INTEGER, event_name TEXT, enabled INTEGER,
                PRIMARY KEY(guild_id, event_name)
            );
            CREATE TABLE antinuke_v2_settings (
                guild_id INTEGER PRIMARY KEY, recreate_channels INTEGER DEFAULT 1,
                recreate_roles INTEGER DEFAULT 1, punish_action TEXT DEFAULT 'ban',
                action_threshold INTEGER DEFAULT 3, action_window_seconds INTEGER DEFAULT 10,
                log_channel_id INTEGER
            );
            CREATE TABLE antinuke_incidents (
                incident_id INTEGER PRIMARY KEY, guild_id INTEGER, event_name TEXT,
                executor_id INTEGER, severity TEXT, risk_score INTEGER, created_at TEXT
            );
            INSERT INTO antinuke_settings VALUES (7, 1);
            INSERT INTO antinuke_v2_settings VALUES (7, 1, 1, 'ban', 3, 10, NULL);
            """
        )
        event_names = {"channel_delete": "Channel Deletion", "role_delete": "Role Deletion"}
        bot = SimpleNamespace(db=database, user=None)
        guild = SimpleNamespace(id=7)
        view = antinuke_dashboard.AntiNukeDashboardView(bot, guild, 3, event_names)
        edit = AsyncMock()
        monkeypatch.setattr(antinuke_dashboard, "edit_interaction_v2", edit)
        interaction = SimpleNamespace(user=SimpleNamespace(id=3))
        try:
            await view.load_state()
            assert view.global_enabled is True
            view.event_select._values = ["channel_delete"]
            await view.select_event(interaction)
            toggle = next(item for item in view.children if getattr(item, "label", None) == "Toggle Event")
            await toggle.callback(interaction)
            async with database.execute(
                "SELECT enabled FROM antinuke_v2_events WHERE guild_id=7 AND event_name='channel_delete'"
            ) as cursor:
                assert await cursor.fetchone() == (0,)

            await view.all_events_off.callback(interaction)
            async with database.execute(
                "SELECT event_name,enabled FROM antinuke_v2_events WHERE guild_id=7"
            ) as cursor:
                assert dict(await cursor.fetchall()) == {"channel_delete": 0, "role_delete": 0}

            view.punish_select._values = ["quarantine"]
            await view.select_punishment(interaction)
            async with database.execute(
                "SELECT punish_action FROM antinuke_v2_settings WHERE guild_id=7"
            ) as cursor:
                assert await cursor.fetchone() == ("quarantine",)
            await view.save_threshold(5, 20)
            async with database.execute(
                "SELECT action_threshold,action_window_seconds "
                "FROM antinuke_v2_settings WHERE guild_id=7"
            ) as cursor:
                assert await cursor.fetchone() == (5, 20)
            assert edit.await_count == 4

            monkeypatch.setattr(bot_module, "bot", bot)
            context = SimpleNamespace(
                guild=guild,
                author=SimpleNamespace(
                    id=3,
                    guild_permissions=discord.Permissions(administrator=True),
                ),
                send=AsyncMock(),
            )
            await bot_module.antinuke_cmd.callback(context)
            assert isinstance(
                context.send.await_args.kwargs["view"],
                antinuke_dashboard.AntiNukeDashboardView,
            )
        finally:
            await database.close()

    asyncio.run(verify_dashboard_controls())


def test_antiraid_times_out_high_risk_new_account_with_embed_log(monkeypatch) -> None:
    import datetime

    import main as bot_module

    class RolePosition:
        def __init__(self, position):
            self.position = position

        def __gt__(self, other):
            return self.position > other.position

    async def verify_suspicious_join() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE antinuke_v2_settings (guild_id INTEGER PRIMARY KEY, log_channel_id INTEGER)"
        )
        await database.execute("INSERT INTO antinuke_v2_settings VALUES (7, NULL)")
        await database.commit()
        channel = SimpleNamespace(id=8)
        guild = SimpleNamespace(
            id=7,
            owner_id=1,
            me=SimpleNamespace(
                top_role=RolePosition(10),
                guild_permissions=discord.Permissions(moderate_members=True),
            ),
            system_channel=channel,
            get_channel=lambda _channel_id: None,
        )
        member = SimpleNamespace(
            id=22,
            mention="<@22>",
            bot=False,
            guild=guild,
            created_at=discord.utils.utcnow() - datetime.timedelta(days=2),
            avatar=None,
            guild_permissions=discord.Permissions.none(),
            top_role=RolePosition(1),
            timed_out_until=None,
            timeout=AsyncMock(),
        )
        write_log = AsyncMock()
        original_bot = bot_module.bot
        monkeypatch.setattr(bot_module, "bot", SimpleNamespace(db=database, user=None))
        monkeypatch.setattr(bot_module, "_send_security_log", write_log)
        try:
            risk = bot_module._antiraid_member_risk(member)
            assert risk == 60
            assert await bot_module._antiraid_handle_suspicious_join(
                member, phase="active lockdown"
            ) is True
            member.timeout.assert_awaited_once()
            assert member.timeout.await_args.args[0] == datetime.timedelta(minutes=10)
            write_log.assert_awaited_once()
            incident_embed = write_log.await_args.args[2]
            assert incident_embed.title == "Anti-Raid Risk Alert"
            assert "Risk:** 60/100" in incident_embed.description
            assert "timed out for 10 minutes" in incident_embed.description
        finally:
            bot_module.bot = original_bot
            await database.close()

    asyncio.run(verify_suspicious_join())


def test_channel_delete_requires_owner_or_administrator() -> None:
    import main as bot_module

    async def verify_channel_delete_access() -> None:
        channel = SimpleNamespace(id=20, mention="<#20>", delete=AsyncMock())
        bot_member = SimpleNamespace(
            guild_permissions=discord.Permissions(manage_channels=True)
        )
        guild = SimpleNamespace(id=7, owner_id=3, me=bot_member)
        denied_context = SimpleNamespace(
            guild=guild,
            author=SimpleNamespace(
                id=4,
                guild_permissions=discord.Permissions(manage_channels=True),
            ),
            send=AsyncMock(),
        )
        await bot_module.channel_delete.callback(denied_context, channel)
        assert "Only the server owner or an Administrator" in denied_context.send.await_args.args[0]
        channel.delete.assert_not_awaited()

        owner_context = SimpleNamespace(
            guild=guild,
            author=SimpleNamespace(
                id=3,
                mention="<@3>",
                guild_permissions=discord.Permissions.none(),
            ),
            send=AsyncMock(),
        )
        await bot_module.channel_delete.callback(owner_context, channel, reason="cleanup")
        assert isinstance(owner_context.send.await_args.kwargs["view"], bot_module.ChannelDeleteConfirmationView)
        channel.delete.assert_not_awaited()

    asyncio.run(verify_channel_delete_access())


def test_channel_delete_picker_requires_selection_and_deletes_on_confirm(monkeypatch) -> None:
    import main as bot_module

    async def verify_picker() -> None:
        channels = [
            SimpleNamespace(id=20, name="old-channel", mention="<#20>", delete=AsyncMock()),
            SimpleNamespace(id=22, name="second-channel", mention="<#22>", delete=AsyncMock()),
        ]
        guild = SimpleNamespace(
            id=7,
            owner_id=3,
            me=SimpleNamespace(
                guild_permissions=discord.Permissions(manage_channels=True)
            ),
            get_channel=lambda channel_id: next(
                (channel for channel in channels if channel.id == channel_id), None
            ),
        )
        context = SimpleNamespace(
            guild=guild,
            author=SimpleNamespace(
                id=3,
                mention="<@3>",
                guild_permissions=discord.Permissions.none(),
            ),
            send=AsyncMock(),
        )
        monkeypatch.setattr(bot_module, "edit_interaction_v2", AsyncMock())
        await bot_module.channel_delete.callback(context)
        view = context.send.await_args.kwargs["view"]
        assert view.channels == []
        assert view.channel_select.max_values == 25
        delete_button = next(item for item in view.children if getattr(item, "label", None) == "Delete Channels")
        cancel_button = next(item for item in view.children if getattr(item, "label", None) == "Cancel")
        assert delete_button.emoji.name == "delete"
        assert cancel_button.emoji.name == "cross"
        assert delete_button.disabled

        view.channel_select._values = [SimpleNamespace(id=20), SimpleNamespace(id=22)]
        await view.select_channel(SimpleNamespace())
        assert view.channels == channels
        assert not delete_button.disabled
        interaction = SimpleNamespace(
            response=SimpleNamespace(defer=AsyncMock()),
            edit_original_response=AsyncMock(),
        )
        await delete_button.callback(interaction)
        for channel in channels:
            channel.delete.assert_awaited_once()
        interaction.response.defer.assert_awaited_once()
        assert "old-channel" in interaction.edit_original_response.await_args.kwargs["content"]
        assert "second-channel" in interaction.edit_original_response.await_args.kwargs["content"]

        cancel_channel = SimpleNamespace(
            id=21,
            name="keep-channel",
            mention="<#21>",
            delete=AsyncMock(),
        )
        cancel_view = bot_module.ChannelDeleteConfirmationView(context, cancel_channel, "cleanup")
        cancel_interaction = SimpleNamespace()
        cancel_button = next(
            item for item in cancel_view.children if getattr(item, "label", None) == "Cancel"
        )
        await cancel_button.callback(cancel_interaction)
        cancel_channel.delete.assert_not_awaited()

    asyncio.run(verify_picker())


def test_bulk_ban_prompts_and_excludes_owner_admin_and_invoker() -> None:
    import main as bot_module

    async def verify_bulk_targets() -> None:
        def member(user_id, *, bot=False, admin=False):
            return SimpleNamespace(
                id=user_id,
                bot=bot,
                guild_permissions=discord.Permissions(administrator=admin),
            )

        targets = [
            member(1),
            member(2),
            member(3, admin=True),
            member(4),
            member(5, bot=True),
            member(99, bot=True),
        ]
        guild = SimpleNamespace(
            owner_id=1,
            members=targets,
            chunked=True,
            me=SimpleNamespace(
                id=99,
                guild_permissions=discord.Permissions(
                    administrator=True,
                    ban_members=True,
                    manage_guild=True,
                ),
            ),
        )
        ctx = SimpleNamespace(
            guild=guild,
            author=SimpleNamespace(id=2),
            interaction=None,
            send=AsyncMock(),
        )
        await bot_module.banall.callback(ctx, scope="all", reason="test")
        view = ctx.send.await_args.kwargs["view"]
        assert {member.id for member in view.targets} == {4, 5}
        assert "2" in ctx.send.await_args.kwargs["embed"].description

    asyncio.run(verify_bulk_targets())


def test_falcon_protection_role_is_admin_and_respects_hierarchy(monkeypatch) -> None:
    import main as bot_module

    class Role:
        def __init__(self, name, position, permissions):
            self.name = name
            self.position = position
            self.permissions = permissions

        def __ge__(self, other):
            return self.position >= other.position

        def __hash__(self):
            return id(self)

    class BotMember:
        def __init__(self):
            self.guild_permissions = discord.Permissions(manage_roles=True)
            self.top_role = Role("Falcon", 10, discord.Permissions.none())
            self.roles = [self.top_role]

        async def add_roles(self, role, *, reason):
            self.roles.append(role)

    class Guild:
        id = 7

        def __init__(self, roles=()):
            self.me = BotMember()
            self.roles = list(roles)

        async def create_role(self, name, *, permissions, reason):
            role = Role(name, 1, permissions)
            self.roles.append(role)
            return role

    async def verify_roles() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute("CREATE TABLE security_extra_owners (guild_id INTEGER, user_id INTEGER)")
        await database.commit()
        monkeypatch.setattr(bot_module, "bot", SimpleNamespace(db=database))
        guild = Guild()
        try:
            role = await bot_module._ensure_falcon_protection_role(guild, "Falcon AutoMod")
            assert role.permissions.administrator
            assert role in guild.me.roles
            assert role.position < guild.me.top_role.position

            high_role = Role("Falcon Anti-Nuke", 20, discord.Permissions(administrator=True))
            guild.roles.append(high_role)
            try:
                await bot_module._ensure_falcon_protection_role(guild, "Falcon Anti-Nuke")
            except RuntimeError as error:
                assert "below Falcon's top role" in str(error)
            else:
                raise AssertionError("A role above Falcon's top role must not be assignable")
        finally:
            await database.close()

    asyncio.run(verify_roles())


def test_warn_and_ban_success_messages_start_with_manifest_tick(monkeypatch) -> None:
    import main as bot_module
    import zyre_features

    async def verify_success_messages() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE zyre_warnings (warning_id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER, "
            "user_id INTEGER, moderator_id INTEGER, reason TEXT, created_at TEXT)"
        )
        await database.commit()
        warn_ctx = SimpleNamespace(
            guild=SimpleNamespace(id=7),
            author=SimpleNamespace(id=3),
            send=AsyncMock(),
        )
        member = SimpleNamespace(id=4, mention="<@4>")
        zyre = zyre_features.ZyreFeatures(SimpleNamespace(db=database))
        zyre._resolve_member = AsyncMock(return_value=member)
        try:
            await zyre_features.ZyreFeatures.warn.callback(zyre, warn_ctx, member, reason="test")
            warning_message = warn_ctx.send.await_args.args[0]
            assert warning_message.startswith("<:fp_tick:1556945922137661514> **Warning Recorded**")
            assert "<:fp_arrow:1551870150204985354> <@4> has 1 active warning(s)." in warning_message

            member.ban = AsyncMock()
            ctx = SimpleNamespace(author=SimpleNamespace(id=3))
            view = bot_module.ModerationConfirmView(ctx, "ban", member, "test")
            edit = AsyncMock()
            monkeypatch.setattr(bot_module, "edit_interaction_v2", edit)
            await view._finish(SimpleNamespace(), True)
            member.ban.assert_awaited_once_with(reason="test")
            result_embed = edit.await_args.kwargs["embed"]
            assert result_embed.description.startswith("<:fp_tick:1556945922137661514> **Member Banned**")
            assert "<:fp_arrow:1551870150204985354> <@4> was banned." in result_embed.description
        finally:
            await database.close()

    asyncio.run(verify_success_messages())


def test_afk_stays_active_when_nickname_cannot_be_changed(monkeypatch) -> None:
    import zyre_features

    async def verify_afk_without_nickname() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE zyre_afk (
                guild_id INTEGER, user_id INTEGER, status TEXT, created_at TEXT,
                original_nick TEXT, PRIMARY KEY(guild_id, user_id)
            );
            CREATE TABLE zyre_settings (guild_id INTEGER PRIMARY KEY, anti_swear INTEGER DEFAULT 0);
            INSERT INTO zyre_settings VALUES (7, 0);
            """
        )
        member = SimpleNamespace(id=2, nick=None, display_name="User", mention="<@2>")
        context = SimpleNamespace(
            guild=SimpleNamespace(id=7),
            author=member,
            send=AsyncMock(),
        )
        cog = zyre_features.ZyreFeatures(SimpleNamespace(db=database))
        cog._set_afk_nickname = AsyncMock(return_value=False)
        cog._ensure_settings = AsyncMock()
        cog._automod_enabled = AsyncMock(return_value=False)
        cog._automod_whitelisted = AsyncMock(return_value=False)
        send = AsyncMock()
        monkeypatch.setattr(zyre_features, "send_v2", send)
        try:
            await zyre_features.ZyreFeatures.afk.callback(cog, context, status="sojao")
            assert context.send.await_args.args == ("AFK status set: sojao.",)
            async with database.execute(
                "SELECT status FROM zyre_afk WHERE guild_id=7 AND user_id=2"
            ) as cursor:
                assert await cursor.fetchone() == ("sojao",)

            message = SimpleNamespace(
                guild=context.guild,
                author=SimpleNamespace(id=9, bot=False),
                content="",
                mentions=[member],
                channel=SimpleNamespace(),
            )
            await cog.process_message(message)
            send.assert_awaited_once()
            assert "is AFK: sojao" in send.await_args.args[1]
        finally:
            await database.close()

    asyncio.run(verify_afk_without_nickname())


def test_giphy_search_retries_once_without_blocking(monkeypatch) -> None:
    import community_features

    class Response:
        def __init__(self, status, payload):
            self.status = status
            self.payload = payload
            self.headers = {}
            self.request_info = None
            self.history = ()

        async def __aenter__(self):
            return self

        async def __aexit__(self, *_args):
            return None

        async def json(self):
            return self.payload

        def raise_for_status(self):
            raise AssertionError(f"Unexpected status {self.status}")

    class Session:
        calls = []
        responses = [
            Response(503, {}),
            Response(200, {"data": [{"images": {"original": {"url": "https://gif.test/a.gif"}}}]}),
        ]

        def __init__(self, *, timeout):
            self.timeout = timeout

        async def __aenter__(self):
            return self

        async def __aexit__(self, *_args):
            return None

        def get(self, url, *, params):
            self.calls.append((url, params, self.timeout.total))
            return self.responses.pop(0)

    monkeypatch.setenv("GIPHY_API_KEY", "test-key")
    monkeypatch.setattr(community_features.aiohttp, "ClientSession", Session)
    cog = community_features.CommunityFeatures(SimpleNamespace(user=None))
    urls = asyncio.run(cog._request_fun_gif_urls("slap"))
    assert urls == ["https://gif.test/a.gif"]
    assert len(Session.calls) == 2
    assert all(call[0] == "https://api.giphy.com/v1/gifs/search" for call in Session.calls)
    assert all(call[1]["api_key"] == "test-key" for call in Session.calls)
    assert all(call[2] == 7 for call in Session.calls)


def test_fun_spam_commands_share_one_response() -> None:
    import community_features

    async def verify_fun_spam() -> None:
        member = SimpleNamespace(id=2, mention="<@2>")
        cog = community_features.CommunityFeatures(SimpleNamespace(user=None))
        cog.send_fun_action = AsyncMock()
        guild = SimpleNamespace(get_member=lambda member_id: member if member_id == 2 else None)
        ctx = SimpleNamespace(
            bot=SimpleNamespace(get_cog=lambda _name: cog),
            guild=guild,
            message=SimpleNamespace(mentions=[], reference=None),
            send=AsyncMock(),
            interaction=None,
        )
        command = community_features._make_fun_command("hug")
        await command.callback(ctx, arguments="spam <@2>")
        cog.send_fun_action.assert_awaited_once_with(ctx, "hug", member, spam=True)

        class Cog:
            async def _fetch_fun_gif(self, _action):
                return None

            async def send(self, ctx, action, target, *, spam=False):
                await community_features.CommunityFeatures.send_fun_action(
                    self, ctx, action, target, spam=spam
                )

        ctx.author = SimpleNamespace(mention="<@1>")
        ctx.send = AsyncMock()
        await Cog().send(ctx, "hug", member, spam=True)
        ctx.send.assert_awaited_once()
        response_embed = ctx.send.await_args.kwargs["embed"]
        assert response_embed.title == "Hug Spam"
        assert response_embed.description.count("hugged <@2>") == 5

    asyncio.run(verify_fun_spam())


def test_role_alias_authorization() -> None:
    from community_features import CommunityFeatures

    class Role:
        def __init__(self, role_id, position):
            self.id = role_id
            self.position = position
            self.mention = f"<@&{role_id}>"

        def is_default(self):
            return False

        def __ge__(self, other):
            return self.position >= other.position

    async def verify_role_toggle() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE role_mappings (guild_id INTEGER, alias TEXT, role_id INTEGER)"
        )
        await database.execute("INSERT INTO role_mappings VALUES (1, 'fam', 5)")
        await database.commit()
        bot = SimpleNamespace(db=database)
        cog = CommunityFeatures(bot)
        role = Role(5, 10)
        member = SimpleNamespace(
            id=10,
            mention="<@10>",
            top_role=Role(6, 1),
            roles=[],
            add_roles=AsyncMock(),
            remove_roles=AsyncMock(),
        )
        author = SimpleNamespace(
            id=10,
            guild_permissions=discord.Permissions.none(),
            top_role=Role(6, 1),
        )
        guild = SimpleNamespace(
            id=1,
            me=SimpleNamespace(
                guild_permissions=discord.Permissions(manage_roles=True),
                top_role=Role(7, 100),
            ),
            get_role=lambda role_id: role if role_id == role.id else None,
        )
        ctx = SimpleNamespace(
            guild=guild,
            author=author,
            interaction=None,
            send=AsyncMock(),
        )
        try:
            await cog.toggle_member_role(ctx, "fam", member)
            member.add_roles.assert_awaited_once()
            assert member.add_roles.await_args.args == (role,)
            assert member.add_roles.await_args.kwargs["reason"].startswith("fam role toggle by")
            success_message = ctx.send.await_args_list[0].args[0]
            assert success_message.startswith("<:fp_tick:1556945922137661514> **Role Added**")
            assert "<:fp_arrow:1551870150204985354> <@&5> added to <@10>" in success_message

            other_member = SimpleNamespace(id=11, top_role=Role(8, 2))
            await cog.toggle_member_role(ctx, "fam", other_member)
            assert "only toggle this role for yourself" in ctx.send.await_args.args[0]
        finally:
            await database.close()

    asyncio.run(verify_role_toggle())


def test_role_create_and_setup_create_are_distinct() -> None:
    import community_features

    created_role = SimpleNamespace(mention="<@&55>")
    create_role = AsyncMock(return_value=created_role)
    configure_alias = AsyncMock()
    cog = SimpleNamespace(_configure_role_alias=configure_alias)
    ctx = SimpleNamespace(
        guild=SimpleNamespace(create_role=create_role),
        author=SimpleNamespace(id=3),
        interaction=None,
        send=AsyncMock(),
    )
    existing_role = SimpleNamespace(id=88)

    async def verify_commands() -> None:
        await community_features.CommunityFeatures.role_create.callback(
            cog, ctx, name="Moderators"
        )
        create_role.assert_awaited_once()
        assert create_role.await_args.kwargs["name"] == "Moderators"
        assert create_role.await_args.kwargs["permissions"] == discord.Permissions.none()

        await community_features.CommunityFeatures.setup_create.callback(
            cog, ctx, "mod", existing_role
        )
        configure_alias.assert_awaited_once_with(ctx, "mod", existing_role)

    asyncio.run(verify_commands())


def test_voice_room_access_override_persists_and_status_is_embed() -> None:
    import denycord_voice_backup

    async def verify_voice_room() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE denycord_voice_rooms (
                guild_id INTEGER, channel_id INTEGER, owner_id INTEGER, locked INTEGER,
                user_limit INTEGER, rtc_region TEXT, chat_open INTEGER, hidden INTEGER DEFAULT 0
            );
            CREATE TABLE denycord_voice_overrides (
                guild_id INTEGER, channel_id INTEGER, user_id INTEGER,
                allow_connect INTEGER, allow_chat INTEGER,
                PRIMARY KEY(guild_id, channel_id, user_id)
            );
            INSERT INTO denycord_voice_rooms VALUES (1, 10, 2, 1, 0, NULL, 1, 0);
            """
        )
        owner = SimpleNamespace(id=2, mention="<@2>", top_role=SimpleNamespace(position=10))
        blocked = SimpleNamespace(
            id=3,
            mention="<@3>",
            top_role=SimpleNamespace(position=1),
            move_to=AsyncMock(),
        )
        bot_member = SimpleNamespace(
            id=99,
            guild_permissions=discord.Permissions(move_members=True),
        )
        permissions = SimpleNamespace(manage_channels=True)
        channel = SimpleNamespace(
            id=10,
            name="Room",
            members=[owner, blocked],
            overwrites={},
            overwrites_for=lambda _target: discord.PermissionOverwrite(),
            permissions_for=lambda _member: permissions,
            set_permissions=AsyncMock(),
            edit=AsyncMock(),
        )
        owner.voice = SimpleNamespace(channel=channel)
        guild = SimpleNamespace(
            id=1,
            owner_id=1,
                premium_tier=2,
            me=bot_member,
            default_role=object(),
            get_member=lambda member_id: {2: owner, 3: blocked}.get(member_id),
        )
        channel.guild = guild
        bot = SimpleNamespace(db=database)
        cog = denycord_voice_backup.DenycordVoiceBackup(bot)
        try:
            result = await cog._perform_room_action(guild, owner, "block", blocked.id)
            assert "blocked" in result
            blocked.move_to.assert_awaited_once()
            assert blocked.move_to.await_args.args == (None,)
            assert blocked.move_to.await_args.kwargs["reason"].startswith(
                "Blocked from managed room by"
            )
            async with database.execute(
                "SELECT allow_connect, allow_chat FROM denycord_voice_overrides "
                "WHERE guild_id=1 AND channel_id=10 AND user_id=3"
            ) as cursor:
                assert await cursor.fetchone() == (0, 0)

            await cog._apply_room_overrides(channel)
            assert channel.set_permissions.await_args.kwargs == {
                "view_channel": False,
                "connect": False,
                "send_messages": False,
            }

            status = await cog._perform_room_action(guild, owner, "status")
            assert isinstance(status, discord.Embed)
            assert status.fields[0].value == "Locked"
            assert status.fields[-1].value == "<@3>"
            await database.executemany(
                "INSERT INTO denycord_voice_overrides "
                "(guild_id, channel_id, user_id, allow_connect, allow_chat) "
                "VALUES (1, 10, ?, ?, ?)",
                [
                    (user_id, int(user_id % 2 == 0), int(user_id % 2 == 0))
                    for user_id in range(1000, 1600)
                ],
            )
            await database.commit()
            status = await cog._perform_room_action(guild, owner, "status")
            allowed_field = next(field for field in status.fields if field.name == "Allowed")
            blocked_field = next(field for field in status.fields if field.name == "Blocked")
            assert len(allowed_field.value) <= 1024
            assert len(blocked_field.value) <= 1024
            assert "more" in allowed_field.value
            assert "more" in blocked_field.value

            assert "hidden" in await cog._perform_room_action(guild, owner, "hide")
            await cog._perform_room_action(guild, owner, "lock")
            await cog._perform_room_action(guild, owner, "unlock")
            async with database.execute(
                "SELECT locked, hidden FROM denycord_voice_rooms WHERE guild_id=1 AND channel_id=10"
            ) as cursor:
                assert await cursor.fetchone() == (0, 1)

            assert "128 kbps" in await cog._perform_room_action(guild, owner, "bitrate", 128)
            channel.edit.assert_awaited_once_with(
                bitrate=128_000, reason=f"Room bitrate changed by {owner}"
            )
        finally:
            await database.close()

    asyncio.run(verify_voice_room())


def test_voice_room_card_shows_emoji_legend_and_open_text_permissions() -> None:
    import denycord_voice_backup

    class Target:
        def __init__(self, target_id, mention=None):
            self.id = target_id
            self.mention = mention

        __hash__ = object.__hash__

    cog = denycord_voice_backup.DenycordVoiceBackup(SimpleNamespace(user=None))
    owner = Target(2, "<@2>")
    bot_member = Target(99)
    everyone = Target(1)
    guild = SimpleNamespace(
        me=bot_member,
        default_role=everyone,
        roles=[],
    )
    channel = SimpleNamespace(name="Room", mention="<#10>")

    _stub_room_panel_emoji_download(cog, denycord_voice_backup)
    panel = asyncio.run(cog._room_panel_view(channel, owner))
    overwrites = asyncio.run(cog._room_overwrites(guild, owner))

    with Image.open(io.BytesIO(panel.card_image)) as card_image:
        assert card_image.format == "PNG"
        assert card_image.width == 1280
        assert card_image.height > 500
    assert isinstance(panel.children[0], discord.ui.Container)
    card = panel.children[0]
    assert card.accent_color == 0xD4AF37
    assert isinstance(card.children[0], discord.ui.TextDisplay)
    assert card.children[0].content == (
        "# TempVoice Interface\n"
        "This **interface** can be used to manage temporary voice channels. "
        "More options are available with **/voice** commands."
    )
    assert isinstance(card.children[1], discord.ui.MediaGallery)
    image_item = card.children[1].items[0]
    assert image_item.media.url == f"attachment://{panel.card_filename}"
    assert len(image_item.description) <= 256
    assert "Room: Room" in image_item.description
    assert "30 voice controls" in image_item.description
    assert all(
        isinstance(child, discord.ui.ActionRow)
        for child in panel.children[1:]
    )
    panel_buttons = [
        child for child in panel.walk_children()
        if isinstance(child, discord.ui.Button)
    ]
    assert all(button.style is discord.ButtonStyle.secondary for button in panel_buttons)
    assert len(panel_buttons) == 30
    assert len([
        child for child in panel.walk_children()
        if isinstance(child, discord.ui.Button)
    ]) == len(denycord_voice_backup.ROOM_PANEL_BUTTONS)
    assert not any(
        isinstance(child, discord.ui.Select)
        for child in panel.walk_children()
    )
    assert overwrites[everyone].view_channel is True
    assert overwrites[everyone].connect is True
    assert overwrites[everyone].send_messages is True
    assert overwrites[owner].send_messages is True
    assert overwrites[owner].embed_links is True
    assert overwrites[bot_member].send_messages is True
    assert overwrites[bot_member].embed_links is True
    assert overwrites[bot_member].attach_files is True


def test_tempvoice_startup_refreshes_saved_room_panel(monkeypatch) -> None:
    import denycord_voice_backup

    class Cursor:
        async def __aenter__(self):
            return self

        async def __aexit__(self, *_args):
            return None

        async def fetchall(self):
            return [(1, 10, 2, 99)]

    class Room:
        id = 10
        name = "Room"
        mention = "<#10>"

        def __init__(self, message):
            self.fetch_message = AsyncMock(return_value=message)

    class Message:
        edit = AsyncMock()

    message = Message()
    room = Room(message)
    guild = SimpleNamespace(get_channel=lambda channel_id: room)
    database = SimpleNamespace(execute=Mock(return_value=Cursor()))
    bot = SimpleNamespace(
        db=database,
        get_guild=Mock(return_value=guild),
    )
    monkeypatch.setattr(denycord_voice_backup.discord, "VoiceChannel", Room)
    cog = denycord_voice_backup.DenycordVoiceBackup(bot)
    _stub_room_panel_emoji_download(cog, denycord_voice_backup)

    assert asyncio.run(cog._refresh_saved_room_panels())
    room.fetch_message.assert_awaited_once_with(99)
    kwargs = message.edit.await_args.kwargs
    assert "embed" not in kwargs
    assert isinstance(kwargs["view"], discord.ui.LayoutView)
    assert len(kwargs["attachments"]) == 1
    assert kwargs["view"].children[0].children[1].items[0].media.url == (
        f"attachment://{kwargs['view'].card_filename}"
    )
    assert kwargs["view"].children[0].children[1].items[0].description.startswith(
        "FALCON VOICE ROOM. Room: Room · Owner:"
    )
    all_panel_buttons = [
        child for child in kwargs["view"].walk_children()
        if isinstance(child, discord.ui.Button)
    ]
    assert len(all_panel_buttons) == len(denycord_voice_backup.ROOM_PANEL_BUTTONS)
    assert all(button.label is None for button in all_panel_buttons)
    assert {button.emoji.id for button in all_panel_buttons} == {
        emoji.id for emoji in denycord_voice_backup.VOICE_BUTTON_EMOJIS.values()
    }
    action_rows = [
        child for child in kwargs["view"].walk_children()
        if isinstance(child, discord.ui.ActionRow)
    ]
    assert len(action_rows) == 6
    assert all(len(row.children) <= 5 for row in action_rows)


def test_voice_room_names_use_one_emoji_prefix(monkeypatch) -> None:
    import denycord_voice_backup

    monkeypatch.setattr(denycord_voice_backup.random, "choice", lambda values: values[0])

    assert denycord_voice_backup._format_room_name("Owner's room") == "🎧 Owner's room"
    assert denycord_voice_backup._format_room_name("🌿 Garden") == "🎧 Garden"
    assert denycord_voice_backup._format_room_name("\n") == "🎧 Temporary room"


def test_voice_room_upstream_aliases_and_category_setup() -> None:
    import denycord_voice_backup

    async def verify_setup_commands() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE denycord_voice_settings ("
            "guild_id INTEGER PRIMARY KEY, hub_channel_id INTEGER NOT NULL, "
            "panel_channel_id INTEGER NOT NULL, category_id INTEGER, enabled INTEGER NOT NULL DEFAULT 1)"
        )
        await database.execute(
            "INSERT INTO denycord_voice_settings VALUES (1, 10, 20, NULL, 1)"
        )
        await database.execute(
            "CREATE TABLE denycord_voice_generators ("
            "guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL, category_id INTEGER, "
            "created_by INTEGER, created_at TEXT NOT NULL, PRIMARY KEY(guild_id, channel_id))"
        )
        await database.execute(
            "INSERT INTO denycord_voice_generators VALUES (1, 10, NULL, 2, '2026-10-17T00:00:00+00:00')"
        )
        await database.commit()
        cog = denycord_voice_backup.DenycordVoiceBackup(SimpleNamespace(db=database))
        hub = SimpleNamespace(mention="<#10>")
        ctx = SimpleNamespace(
            guild=SimpleNamespace(id=1, get_channel=lambda channel_id: hub if channel_id == 10 else None),
            interaction=None,
            send=AsyncMock(),
        )
        category = SimpleNamespace(id=30, name="Temporary Rooms")
        try:
            assert set(denycord_voice_backup.DenycordVoiceBackup.room.aliases) >= {
                "temp_vc", "temp", "tv", "temp_voice"
            }
            assert {"info", "set_channel", "set_category"} <= set(
                denycord_voice_backup.DenycordVoiceBackup.room.all_commands
            )
            assert {"hide", "unhide", "ban", "bitrate"} <= set(
                denycord_voice_backup.DenycordVoiceBackup.room.all_commands
            )

            await denycord_voice_backup.DenycordVoiceBackup.room_set_category.callback(
                cog, ctx, category
            )
            async with database.execute(
                "SELECT category_id FROM denycord_voice_settings WHERE guild_id=1"
            ) as cursor:
                assert await cursor.fetchone() == (30,)
            async with database.execute(
                "SELECT category_id FROM denycord_voice_generators WHERE guild_id=1 AND channel_id=10"
            ) as cursor:
                assert await cursor.fetchone() == (30,)

            await denycord_voice_backup.DenycordVoiceBackup.room_set_category.callback(
                cog, ctx, None
            )
            async with database.execute(
                "SELECT category_id FROM denycord_voice_settings WHERE guild_id=1"
            ) as cursor:
                assert await cursor.fetchone() == (None,)
            async with database.execute(
                "SELECT category_id FROM denycord_voice_generators WHERE guild_id=1 AND channel_id=10"
            ) as cursor:
                assert await cursor.fetchone() == (None,)

            await denycord_voice_backup.DenycordVoiceBackup.room.callback(cog, ctx)
            ctx.send.assert_awaited()
            assert "<#10>" in ctx.send.await_args.kwargs["embed"].description
        finally:
            await database.close()

    asyncio.run(verify_setup_commands())


def test_voicehub_setup_creates_persistent_shared_interface() -> None:
    import denycord_voice_backup

    class FakeMember:
        def __init__(self, member_id, *, permissions=None):
            self.id = member_id
            self.mention = f"<@{member_id}>"
            self.guild_permissions = permissions or discord.Permissions.none()

        def __str__(self):
            return f"member-{self.id}"

    class FakeChannel:
        def __init__(self, channel_id, name, permissions):
            self.id = channel_id
            self.name = name
            self.mention = f"<#${channel_id}>"
            self.permissions = permissions
            self.messages = []

        def permissions_for(self, _member):
            return self.permissions

        async def send(self, **kwargs):
            self.messages.append(kwargs)
            return SimpleNamespace(id=900 + self.id)

    async def verify_setup() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE denycord_voice_settings ("
            "guild_id INTEGER PRIMARY KEY, hub_channel_id INTEGER NOT NULL, "
            "panel_channel_id INTEGER NOT NULL, category_id INTEGER, interface_message_id INTEGER, "
            "enabled INTEGER NOT NULL DEFAULT 1)"
        )
        await database.execute(
            "CREATE TABLE denycord_voice_generators ("
            "guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL, category_id INTEGER, "
            "created_by INTEGER, created_at TEXT NOT NULL, PRIMARY KEY(guild_id, channel_id))"
        )
        await database.commit()

        bot_member = FakeMember(
            99,
            permissions=discord.Permissions(manage_channels=True, move_members=True),
        )
        everyone = FakeMember(1)
        everyone.mention = "@everyone"
        channel_permissions = SimpleNamespace(
            view_channel=True,
            connect=True,
            move_members=True,
            send_messages=True,
            embed_links=True,
            attach_files=True,
        )

        class FakeGuild:
            id = 5
            name = "Test Guild"
            icon = None
            default_role = everyone
            me = bot_member

            def __init__(self):
                self.created = []

            async def create_category(self, name, **_kwargs):
                category = SimpleNamespace(id=10, name=name)
                self.created.append(("category", category))
                return category

            async def create_voice_channel(self, name, **_kwargs):
                channel = FakeChannel(11, name, channel_permissions)
                self.created.append(("voice", channel))
                return channel

            async def create_text_channel(self, name, **_kwargs):
                channel = FakeChannel(12, name, channel_permissions)
                self.created.append(("text", channel))
                return channel

        guild = FakeGuild()
        ctx = SimpleNamespace(
            guild=guild,
            author=FakeMember(2),
            send=AsyncMock(),
        )
        cog = denycord_voice_backup.DenycordVoiceBackup(
            SimpleNamespace(db=database, user=None)
        )
        _stub_room_panel_emoji_download(cog, denycord_voice_backup)
        try:
            await denycord_voice_backup.DenycordVoiceBackup.voicehub.callback(
                cog, ctx, "setup", None, None, None
            )
            assert [kind for kind, _channel in guild.created] == ["category", "voice", "text"]
            panel = guild.created[-1][1]
            assert panel.name == "voice-interface"
            assert len(panel.messages) == 1
            panel_view = panel.messages[0]["view"]
            assert isinstance(panel_view, discord.ui.LayoutView)
            assert "embed" not in panel.messages[0]
            assert panel.messages[0]["file"].filename == panel_view.card_filename
            with Image.open(io.BytesIO(panel_view.card_image)) as card_image:
                assert card_image.format == "PNG"
            assert "FALCON VOICE ROOM" in (
                    panel_view.children[0].children[1].items[0].description
            )
            assert sum(
                isinstance(child, discord.ui.Button)
                for child in panel_view.walk_children()
            ) == len(denycord_voice_backup.ROOM_PANEL_BUTTONS)
            async with database.execute(
                "SELECT hub_channel_id, panel_channel_id, interface_message_id "
                "FROM denycord_voice_settings WHERE guild_id=5"
            ) as cursor:
                assert await cursor.fetchone() == (11, 12, 912)
            async with database.execute(
                "SELECT channel_id, category_id, created_by FROM denycord_voice_generators WHERE guild_id=5"
            ) as cursor:
                assert await cursor.fetchone() == (11, 10, 2)
        finally:
            await database.close()

    asyncio.run(verify_setup())


def test_voice_interface_setup_edits_saved_card_instead_of_sending_duplicate() -> None:
    import denycord_voice_backup

    async def verify_update() -> None:
        cog = denycord_voice_backup.DenycordVoiceBackup(SimpleNamespace(user=None))
        existing_message = SimpleNamespace(id=123, edit=AsyncMock())
        panel = SimpleNamespace(
            fetch_message=AsyncMock(return_value=existing_message),
            send=AsyncMock(),
        )
        guild = SimpleNamespace(name="Test Guild", icon=None)
        _stub_room_panel_emoji_download(cog, denycord_voice_backup)

        message_id = await cog._ensure_voice_interface(guild, panel, 123)

        assert message_id == 123
        panel.fetch_message.assert_awaited_once_with(123)
        panel.send.assert_not_awaited()
        existing_message.edit.assert_awaited_once()
        assert "embed" not in existing_message.edit.await_args.kwargs
        assert len(existing_message.edit.await_args.kwargs["attachments"]) == 1
        panel_view = existing_message.edit.await_args.kwargs["view"]
        assert isinstance(panel_view, discord.ui.LayoutView)
        assert "Test Guild" in (
            panel_view.children[0].children[1].items[0].description
        )

    asyncio.run(verify_update())


def test_created_room_interface_is_posted_only_in_voice_chat() -> None:
    import denycord_voice_backup

    class FakeMember:
        def __init__(self, member_id, *, display_name="Member", permissions=None):
            self.id = member_id
            self.display_name = display_name
            self.guild_permissions = permissions or discord.Permissions.none()
            self.voice = None
            self.move_to = AsyncMock()

    async def verify_room_creation() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE denycord_voice_settings (
                guild_id INTEGER PRIMARY KEY, hub_channel_id INTEGER NOT NULL,
                panel_channel_id INTEGER NOT NULL, category_id INTEGER, interface_message_id INTEGER
            );
            CREATE TABLE denycord_voice_rooms (
                guild_id INTEGER, channel_id INTEGER, owner_id INTEGER, created_at TEXT,
                locked INTEGER DEFAULT 0, user_limit INTEGER DEFAULT 0, rtc_region TEXT,
                    chat_open INTEGER DEFAULT 1, hidden INTEGER DEFAULT 0, panel_message_id INTEGER,
                PRIMARY KEY(guild_id, channel_id)
            );
            INSERT INTO denycord_voice_settings VALUES (5, 20, 30, NULL, 930);
            """
        )
        bot_member = FakeMember(
            99,
            permissions=discord.Permissions(manage_channels=True, move_members=True),
        )
        everyone = FakeMember(1)
        hub_permissions = SimpleNamespace(
            view_channel=True,
            connect=True,
            move_members=True,
        )
        hub = SimpleNamespace(id=20, permissions_for=lambda _member: hub_permissions)
        room = SimpleNamespace(
            id=40,
            name="Ada's room",
            mention="<#40>",
            guild=None,
            send=AsyncMock(return_value=SimpleNamespace(id=41)),
        )

        class FakeGuild:
            id = 5
            me = bot_member
            default_role = everyone

            def get_channel(self, channel_id):
                return hub if channel_id == 20 else None

            create_voice_channel = AsyncMock(return_value=room)

        guild = FakeGuild()
        room.guild = guild
        member = FakeMember(7, display_name="Ada")
        member.guild = guild
        member.mention = "<@7>"
        bot = SimpleNamespace(db=database, user=None)
        cog = denycord_voice_backup.DenycordVoiceBackup(bot)
        _stub_room_panel_emoji_download(cog, denycord_voice_backup)
        try:
            await cog._create_temp_room(member, None)
            member.move_to.assert_awaited_once_with(
                room, reason="Joined the VoiceMaster create channel"
            )
            room.send.assert_awaited_once()
            panel_view = room.send.await_args.kwargs["view"]
            assert isinstance(panel_view, discord.ui.LayoutView)
            assert room.send.await_args.kwargs["file"].filename == panel_view.card_filename
            assert "Room: Ada's room" in (
                panel_view.children[0].children[1].items[0].description
            )
            assert guild.create_voice_channel.await_count == 1
        finally:
            await database.close()

    asyncio.run(verify_room_creation())


def test_noprefix_success_uses_public_premium_message() -> None:
    import premium_features

    async def verify_noprefix_message() -> None:
        import main as bot_module

        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE noprefix (user_id INTEGER PRIMARY KEY, expiry TEXT, granted_by INTEGER, "
            "started_at TEXT, permanent INTEGER)"
        )
        bot = SimpleNamespace(db=database, is_owner=AsyncMock(return_value=True))
        cog = premium_features.PremiumFeatures(bot)
        ctx = SimpleNamespace(
            author=SimpleNamespace(id=1),
            interaction=None,
            send=AsyncMock(),
        )
        user = SimpleNamespace(id=2, mention="<@2>")
        original_parser = premium_features.parse_duration
        premium_features.parse_duration = lambda _duration: None
        try:
            await premium_features.PremiumFeatures.noprefix_add.callback(
                cog, ctx, user, "permanent"
            )
            message = ctx.send.await_args.args[0]
            assert f"{bot_module.FP_TICK}  __**No-Prefix Enabled**__" in message
            assert f"{bot_module.ARROW}  **No-prefix enabled for <@2>**" in message
            assert "> Duration                 Status\n> Permanent          Active" in message
            assert message.endswith("-# Falcon Premium • No-Prefix")
            assert "embed" not in ctx.send.await_args.kwargs
        finally:
            premium_features.parse_duration = original_parser
            await database.close()

    asyncio.run(verify_noprefix_message())


def test_giveaway_heading_is_a_standalone_message() -> None:
    import main as bot_module

    async def verify_giveaway_messages() -> None:
        original_database = bot_module.bot.db
        database = await aiosqlite.connect(":memory:")
        bot_module.bot.db = database
        await database.execute(
            "CREATE TABLE giveaway_settings (guild_id INTEGER PRIMARY KEY, required_role_id INTEGER, "
            "embed_color INTEGER, embed_image_url TEXT, reaction_emoji TEXT)"
        )
        await database.execute(
            "INSERT INTO giveaway_settings VALUES (1, NULL, NULL, 'https://assets.test/banner.gif', '<:wave:111111111111111111>')"
        )
        await database.execute(
            "CREATE TABLE giveaways (msg_id INTEGER, prize TEXT, host_id INTEGER, winners INTEGER, "
            "guild_id INTEGER, channel_id INTEGER, ends_at TEXT, active INTEGER, announcement_msg_id INTEGER)"
        )
        await database.commit()
        giveaway_message = SimpleNamespace(id=123, add_reaction=AsyncMock())
        announcement_message = SimpleNamespace(id=456)
        channel = SimpleNamespace(id=2, send=AsyncMock(return_value=announcement_message))
        ctx = SimpleNamespace(
            guild=SimpleNamespace(id=1, get_role=lambda _role_id: None),
            channel=channel,
            author=SimpleNamespace(id=3, mention="<@3>"),
            send=AsyncMock(return_value=giveaway_message),
        )
        try:
            await bot_module.gcreate.callback(ctx, "10m", 1, prize="Premium")
            channel.send.assert_awaited_once_with(
                f"{bot_module.GIVEAWAY_EMOJI} **New Giveaway** {bot_module.GIVEAWAY_EMOJI}"
            )
            ctx.send.assert_awaited_once()
            assert ctx.send.await_args.args == ()
            assert ctx.send.await_args.kwargs["embed"].color.value == 0xFFDD00
            assert ctx.send.await_args.kwargs["embed"].image.url == "https://assets.test/banner.gif"
            giveaway_message.add_reaction.assert_awaited_once()
            assert giveaway_message.add_reaction.await_args.args == ("<:wave:111111111111111111>",)
            async with database.execute(
                "SELECT announcement_msg_id FROM giveaways WHERE msg_id=123"
            ) as cursor:
                assert await cursor.fetchone() == (announcement_message.id,)
        finally:
            await database.close()
            bot_module.bot.db = original_database

    asyncio.run(verify_giveaway_messages())


def test_giveaway_expiry_worker_uses_one_second_poll(monkeypatch) -> None:
    import main as bot_module

    async def verify_poll_interval() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE giveaways (msg_id INTEGER, channel_id INTEGER, active INTEGER, ends_at TEXT)"
        )
        await database.commit()
        state = {"closed": False}
        delays = []

        async def capture_sleep(delay):
            delays.append(delay)
            state["closed"] = True

        client = SimpleNamespace(
            db=database,
            wait_until_ready=AsyncMock(return_value=None),
            is_closed=lambda: state["closed"],
        )
        monkeypatch.setattr(bot_module.asyncio, "sleep", capture_sleep)
        try:
            await bot_module.FalconBot.giveaway_expiry_task(client)
            assert delays == [bot_module.GIVEAWAY_EXPIRY_POLL_INTERVAL]
            assert delays == [1.0]
        finally:
            await database.close()

    asyncio.run(verify_poll_interval())


def test_setgiveaway_saves_emoji_and_uploaded_banner(monkeypatch) -> None:
    import main as bot_module

    async def verify_settings() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE giveaway_settings (guild_id INTEGER PRIMARY KEY, winner_role_id INTEGER, "
            "bypass_role_id INTEGER, required_role_id INTEGER, embed_title TEXT, embed_color INTEGER, "
            "embed_image_url TEXT, reaction_emoji TEXT)"
        )
        await database.commit()
        original_database = bot_module.bot.db
        bot_module.bot.db = database
        channel = SimpleNamespace(id=20)
        guild = SimpleNamespace(id=7, get_emoji=lambda _emoji_id: None)
        author = SimpleNamespace(id=3)
        attachment = SimpleNamespace(
            filename="giveaway-banner.gif",
            content_type="image/gif",
            url="https://assets.test/giveaway-banner.gif",
        )
        send_interaction = AsyncMock()
        monkeypatch.setattr(bot_module, "send_interaction_v2", send_interaction)
        ctx = SimpleNamespace(
            guild=guild,
            channel=channel,
            author=author,
            message=SimpleNamespace(attachments=[], role_mentions=[]),
            send=AsyncMock(),
        )
        try:
            await bot_module.setgiveaway.callback(
                ctx, "emoji", value="<:wave:111111111111111111>"
            )
            await bot_module.setgiveaway.callback(ctx, "image")
            prompt_embed = ctx.send.await_args_list[1].kwargs["embed"]
            upload_view = ctx.send.await_args_list[1].kwargs["view"]
            assert prompt_embed.title == "Giveaway Banner"
            assert any(button.label == "Upload Banner" for button in upload_view.children)
            remove_button = next(
                button for button in upload_view.children
                if button.label == "Remove Banner"
            )
            modal = bot_module.GiveawayBannerModal(guild.id, author.id)
            modal_payload = modal.to_components()
            assert modal_payload[0]["type"] == discord.ComponentType.label.value
            assert modal_payload[0]["component"]["type"] == discord.ComponentType.file_upload.value
            assert modal_payload[0]["component"]["required"] is False
            assert modal_payload[1]["type"] == 1
            assert modal_payload[1]["components"][0]["type"] == discord.ComponentType.text_input.value
            modal.banner_upload._values = [attachment]
            await modal.on_submit(SimpleNamespace(user=author))
            send_interaction.assert_awaited_once()
            assert send_interaction.await_args.kwargs["embed"].image.url == attachment.url
            modal.banner_upload._values = []
            modal.banner_url._value = "https://assets.test/from-link.png"
            await modal.on_submit(SimpleNamespace(user=author))
            assert send_interaction.await_count == 2
            assert send_interaction.await_args.kwargs["embed"].image.url == modal.banner_url.value
            modal.banner_url._value = "https://klipy.com/gifs/marody"
            await modal.on_submit(SimpleNamespace(user=author))
            assert send_interaction.await_count == 3
            assert "direct image link" in send_interaction.await_args.args[1]
            assert bot_module._is_direct_giveaway_image_url(
                "https://assets.test/from-link.png?size=large"
            )
            assert not bot_module._is_direct_giveaway_image_url(
                "https://klipy.com/gifs/marody"
            )
            async with database.execute(
                "SELECT embed_image_url, reaction_emoji FROM giveaway_settings WHERE guild_id=7"
            ) as cursor:
                assert await cursor.fetchone() == (
                    "https://assets.test/from-link.png",
                    "<:wave:111111111111111111>",
                )
            await remove_button.callback(SimpleNamespace(user=author))
            assert send_interaction.await_count == 4
            async with database.execute(
                "SELECT embed_image_url FROM giveaway_settings WHERE guild_id=7"
            ) as cursor:
                assert await cursor.fetchone() == (None,)
            await bot_module.setgiveaway.callback(ctx, "emoji")
            assert "Usage: `,setgiveaway emoji <emoji/emoji id>`" in ctx.send.await_args.args[0]
            await bot_module.setgiveaway.callback(ctx, "bypassrole")
            assert "Usage: `,setgiveaway bypassrole <role id>`" in ctx.send.await_args.args[0]
            await bot_module.setgiveaway.callback(ctx, "winnerrole")
            assert "Usage: `,setgiveaway winnerrole <role id>`" in ctx.send.await_args.args[0]
        finally:
            bot_module.bot.db = original_database
            await database.close()

    asyncio.run(verify_settings())


def test_timer_heading_is_plain_message_above_timer_embed(monkeypatch) -> None:
    import main as bot_module

    async def verify_timer_messages() -> None:
        original_bot = bot_module.bot
        previous_timer = bot_module.active_timers.pop(987, None)
        task = SimpleNamespace(cancel=lambda: None)

        def schedule(coroutine):
            coroutine.close()
            return task

        bot_module.bot = SimpleNamespace(loop=SimpleNamespace(create_task=schedule))
        channel = SimpleNamespace(id=5, send=AsyncMock())
        context = SimpleNamespace(
            guild=SimpleNamespace(id=987),
            channel=channel,
            send=AsyncMock(),
        )
        try:
            await bot_module.tstart.callback(context, "30s", label="Tea")
            timer_emoji = bot_module._manifest_emoji("fp_timer", "⏱️")
            channel.send.assert_awaited_once_with(f"{timer_emoji} **Timer** {timer_emoji}")
            context.send.assert_awaited_once()
            assert context.send.await_args.args == ()
            assert context.send.await_args.kwargs["embed"].description.startswith("**Tea**")
        finally:
            bot_module.active_timers.pop(987, None)
            if previous_timer is not None:
                bot_module.active_timers[987] = previous_timer
            bot_module.bot = original_bot

    asyncio.run(verify_timer_messages())


def test_giveaway_end_updates_components_v2_message(monkeypatch) -> None:
    import main as bot_module

    async def verify_giveaway_end_messages() -> None:
        original_bot = bot_module.bot
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE giveaways (
                msg_id INTEGER, forced_winner INTEGER, prize TEXT, host_id INTEGER,
                winners INTEGER, guild_id INTEGER, active INTEGER, announcement_msg_id INTEGER
            );
            CREATE TABLE giveaway_settings (
                guild_id INTEGER, winner_role_id INTEGER, bypass_role_id INTEGER,
                required_role_id INTEGER, embed_title TEXT, embed_color INTEGER,
                embed_image_url TEXT, reaction_emoji TEXT
            );
            INSERT INTO giveaways VALUES (123, NULL, 'Premium', 3, 1, 1, 1, 456);
            """
        )
        message = SimpleNamespace(
            reactions=[],
            jump_url="https://discord.test/giveaway/123",
        )
        announcement = SimpleNamespace(id=456, edit=AsyncMock())

        async def fetch_message(message_id):
            return message if message_id == 123 else announcement

        guild = SimpleNamespace(id=1, get_role=lambda _role_id: None)
        channel = SimpleNamespace(
            id=2,
            guild=guild,
            fetch_message=AsyncMock(side_effect=fetch_message),
            send=AsyncMock(),
        )
        bot_module.bot = SimpleNamespace(db=database, get_channel=lambda _channel_id: channel)
        edit_message_v2 = AsyncMock()
        monkeypatch.setattr(bot_module, "edit_message_v2", edit_message_v2)
        try:
            await asyncio.gather(
                bot_module.resolve_giveaway(123, 2),
                bot_module.resolve_giveaway(123, 2),
            )
            channel.send.assert_not_awaited()
            announcement.edit.assert_awaited_once_with(
                content=(
                    f"{bot_module.GIVEAWAY_ENDED_EMOJI} "
                    f"**Giveaway Ended** {bot_module.GIVEAWAY_ENDED_EMOJI}"
                )
            )
            edit_message_v2.assert_awaited_once()
            assert edit_message_v2.await_args.args == (message,)
            description = edit_message_v2.await_args.kwargs["embed"].description
            assert "Giveaway Ended" not in description
            assert f"{bot_module.DOT} Hosted by:" in description
            assert f"{bot_module.FP_TICK} **Winner(s):**" in description
        finally:
            await database.close()
            bot_module.bot = original_bot

    asyncio.run(verify_giveaway_end_messages())


def test_winner_notification_replies_to_giveaway(monkeypatch) -> None:
    import main as bot_module

    async def verify_winner_reply() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE giveaways (
                msg_id INTEGER, forced_winner INTEGER, prize TEXT, host_id INTEGER,
                winners INTEGER, guild_id INTEGER, active INTEGER, announcement_msg_id INTEGER
            );
            CREATE TABLE giveaway_settings (
                guild_id INTEGER, winner_role_id INTEGER, bypass_role_id INTEGER,
                required_role_id INTEGER, embed_title TEXT, embed_color INTEGER,
                embed_image_url TEXT, reaction_emoji TEXT
            );
            INSERT INTO giveaways VALUES (123, 7, '100', 7, 1, 1, 1, 456);
            """
        )
        winner = SimpleNamespace(id=7, mention="<@7>")
        giveaway_message = SimpleNamespace(reactions=[], jump_url="https://discord.test/giveaway/123")
        announcement = SimpleNamespace(id=456, edit=AsyncMock())

        async def fetch_message(message_id):
            return giveaway_message if message_id == 123 else announcement

        channel = SimpleNamespace(
            guild=SimpleNamespace(id=1, get_role=lambda _role_id: None, get_member=lambda _user_id: winner),
            fetch_message=AsyncMock(side_effect=fetch_message),
            send=AsyncMock(),
        )
        original_bot = bot_module.bot
        bot_module.bot = SimpleNamespace(
            db=database,
            user=SimpleNamespace(id=99),
            get_channel=lambda _channel_id: channel,
        )
        send = AsyncMock()
        monkeypatch.setattr(bot_module, "send_v2", send)
        monkeypatch.setattr(bot_module, "edit_message_v2", AsyncMock())
        try:
            await bot_module.resolve_giveaway(123, 2)
            send.assert_awaited_once()
            assert send.await_args.args[0] is channel
            assert send.await_args.args[1] == "Congrats, <@7> you have won **100**, hosted by <@7>"
            assert send.await_args.kwargs["reference"] is giveaway_message
            assert send.await_args.kwargs["mention_author"] is False
            button = send.await_args.kwargs["view"].children[0]
            assert button.label == "Giveaway Link"
            assert button.url == giveaway_message.jump_url
        finally:
            bot_module.bot = original_bot
            await database.close()

    asyncio.run(verify_winner_reply())


def test_legacy_giveaway_end_updates_previous_header(monkeypatch) -> None:
    import main as bot_module

    async def verify_legacy_reply() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE giveaways (
                msg_id INTEGER, forced_winner INTEGER, prize TEXT, host_id INTEGER,
                winners INTEGER, guild_id INTEGER, active INTEGER, announcement_msg_id INTEGER
            );
            CREATE TABLE giveaway_settings (
                guild_id INTEGER, winner_role_id INTEGER, bypass_role_id INTEGER,
                required_role_id INTEGER, embed_title TEXT, embed_color INTEGER,
                embed_image_url TEXT, reaction_emoji TEXT
            );
            INSERT INTO giveaways VALUES (321, NULL, 'Prize', 3, 1, 1, 1, NULL);
            """
        )
        giveaway_message = SimpleNamespace(reactions=[], jump_url="https://discord.test/giveaway/321")
        header = SimpleNamespace(
            content=f"{bot_module.GIVEAWAY_EMOJI} **New Giveaway** {bot_module.GIVEAWAY_EMOJI}",
            author=SimpleNamespace(id=99),
            edit=AsyncMock(),
        )

        async def history(*, limit, before):
            assert limit == 5
            assert before is giveaway_message
            yield header

        async def fetch_message(message_id):
            assert message_id == 321
            return giveaway_message

        guild = SimpleNamespace(id=1, get_role=lambda _role_id: None)
        channel = SimpleNamespace(
            id=2,
            guild=guild,
            history=history,
            fetch_message=AsyncMock(side_effect=fetch_message),
            send=AsyncMock(),
        )
        original_bot = bot_module.bot
        bot_module.bot = SimpleNamespace(
            db=database,
            user=SimpleNamespace(id=99),
            get_channel=lambda _channel_id: channel,
        )
        monkeypatch.setattr(bot_module, "edit_message_v2", AsyncMock())
        try:
            await bot_module.resolve_giveaway(321, 2)
            channel.send.assert_not_awaited()
            header.edit.assert_awaited_once_with(
                content=(
                    f"{bot_module.GIVEAWAY_ENDED_EMOJI} "
                    f"**Giveaway Ended** {bot_module.GIVEAWAY_ENDED_EMOJI}"
                )
            )
        finally:
            bot_module.bot = original_bot
            await database.close()

    asyncio.run(verify_legacy_reply())


def test_edit_message_v2_does_not_send_legacy_embeds_for_v2_messages() -> None:
    from components_v2 import edit_message_v2

    message = SimpleNamespace(
        flags=SimpleNamespace(is_components_v2=True),
        edit=AsyncMock(),
    )

    asyncio.run(edit_message_v2(message, embed=discord.Embed(description="Updated")))

    message.edit.assert_awaited_once()
    assert "embeds" not in message.edit.await_args.kwargs
    assert isinstance(message.edit.await_args.kwargs["view"], discord.ui.LayoutView)


def test_edit_message_v2_disables_view_without_legacy_embeds() -> None:
    from components_v2 import edit_message_v2

    message = SimpleNamespace(
        flags=SimpleNamespace(is_components_v2=True),
        edit=AsyncMock(),
    )

    asyncio.run(edit_message_v2(message, view=discord.ui.View()))

    message.edit.assert_awaited_once()
    assert "embeds" not in message.edit.await_args.kwargs
    assert isinstance(message.edit.await_args.kwargs["view"], discord.ui.LayoutView)


def test_components_v2_places_embed_thumbnail_on_right() -> None:
    from components_v2 import make_layout_view

    embed = discord.Embed(title="Security event", description="Details")
    embed.set_thumbnail(url="https://assets.test/bot-avatar.png")
    layout = make_layout_view(embed=embed)
    section = layout.children[0].children[0]

    assert isinstance(section, discord.ui.Section)
    assert isinstance(section.accessory, discord.ui.Thumbnail)
    assert section.accessory.media.url == "https://assets.test/bot-avatar.png"
    assert not any(isinstance(item, discord.ui.MediaGallery) for item in layout.children[0].children)


def test_steal_menu_extracts_and_processes_five_modes(monkeypatch) -> None:
    import main as bot_module

    source = SimpleNamespace(
        content="<:wave:111111111111111111> <:heart:222222222222222222>",
        stickers=[
            SimpleNamespace(name="sticker_one", url="https://assets.test/one.png", format=SimpleNamespace(name="png"), description="", emoji="🙂"),
            SimpleNamespace(name="sticker_two", url="https://assets.test/two.png", format=SimpleNamespace(name="png"), description="", emoji="🙂"),
        ],
        attachments=[
            SimpleNamespace(filename="image.png", url="https://assets.test/image.png", content_type="image/png")
        ],
        embeds=[
            SimpleNamespace(
                image=SimpleNamespace(url="https://assets.test/preview.gif?width=400"),
                thumbnail=None,
                video=None,
            )
        ],
        author=SimpleNamespace(id=1),
    )

    async def verify_modes() -> None:
        monkeypatch.setattr(bot_module, "_download_steal_asset", AsyncMock(return_value=b"image"))
        assets = bot_module._steal_message_assets(source)
        assert tuple(map(len, assets)) == (2, 2, 2, 2)

        expected_counts = {
            "emoji_one": (1, 0),
            "sticker_one": (0, 1),
            "all_emoji": (4, 0),
            "all_stickers": (0, 4),
            "both": (4, 4),
        }
        for mode, expected in expected_counts.items():
            guild = SimpleNamespace(
                emojis=[],
                stickers=[],
                filesize_limit=1024,
                create_custom_emoji=AsyncMock(),
                create_sticker=AsyncMock(),
            )
            added, failures, created_assets = await bot_module._steal_selected_assets(guild, source, mode)
            assert (guild.create_custom_emoji.await_count, guild.create_sticker.await_count) == expected
            assert added == sum(expected)
            assert failures == []
            assert len(created_assets) == added

        class FakeEmoji:
            name = "wave"
            url = "https://assets.test/wave.gif"

            def __str__(self):
                return "<:wave:123>"

        result_embed = bot_module._build_steal_result_embed(
            [("emoji", FakeEmoji()),
             ("sticker", SimpleNamespace(name="dance", url="https://assets.test/dance.gif"))],
            [],
        )
        assert "<" in result_embed.fields[0].value
        assert result_embed.fields[1].name == "Sticker"
        assert result_embed.image.url == "https://assets.test/wave.gif"

    asyncio.run(verify_modes())


def test_oversized_gif_is_compressed_and_stays_animated() -> None:
    import io

    from PIL import Image

    import main as bot_module

    frames = [Image.effect_noise((384, 384), 100).convert("RGB") for _ in range(4)]
    source = io.BytesIO()
    frames[0].save(
        source,
        format="GIF",
        save_all=True,
        append_images=frames[1:],
        duration=100,
        loop=0,
    )
    for frame in frames:
        frame.close()
    original = source.getvalue()
    compressed = bot_module._compress_steal_gif(original, max(1, len(original) // 3))

    assert len(compressed) <= len(original) // 3
    with Image.open(io.BytesIO(compressed)) as optimized:
        assert optimized.n_frames > 1


def test_oversized_png_is_resized_and_remains_png() -> None:
    import io

    from PIL import Image

    import main as bot_module

    image = Image.effect_noise((1024, 1024), 100).convert("RGB")
    source = io.BytesIO()
    image.save(source, format="PNG")
    image.close()
    compressed = bot_module._compress_steal_image(source.getvalue(), 128 * 1024, ".png")

    assert len(compressed) <= 128 * 1024
    with Image.open(io.BytesIO(compressed)) as optimized:
        assert optimized.format == "PNG"
        assert optimized.width < 1024


def test_steal_upload_limits_account_for_emoji_base64() -> None:
    import main as bot_module

    guild = SimpleNamespace(filesize_limit=100 * 1024 * 1024)

    assert bot_module._steal_upload_limit(guild) == 23 * 1024 * 1024
    assert bot_module._steal_upload_limit(guild, for_sticker=True) == 31 * 1024 * 1024
    guild.filesize_limit = 8 * 1024 * 1024
    assert bot_module._steal_upload_limit(guild) == 8 * 1024 * 1024


def test_steal_command_has_five_menu_options() -> None:
    import main as bot_module

    source = SimpleNamespace(author=SimpleNamespace(mention="<@1>"))
    view = bot_module.StealMenuView(source, invoker_id=1)
    select = view.children[0]

    assert [option.value for option in select.options] == [
        "emoji_one", "sticker_one", "all_emoji", "all_stickers", "both"
    ]
    assert bot_module.bot.get_command("steal") is not None
    assert "steal" not in bot_module.bot.get_command("emoji").aliases


def test_steal_source_resolves_reply_and_mentioned_user() -> None:
    import main as bot_module

    async def verify_sources() -> None:
        reply_source = SimpleNamespace(
            content="",
            stickers=[],
            attachments=[],
            embeds=[
                SimpleNamespace(
                    image=SimpleNamespace(url="https://assets.test/reply.gif"),
                    thumbnail=None,
                    video=None,
                )
            ],
        )
        reply_context = SimpleNamespace(
            message=SimpleNamespace(
                reference=SimpleNamespace(resolved=reply_source), mentions=[]
            ),
            channel=SimpleNamespace(),
        )
        assert await bot_module._find_steal_source(reply_context) is reply_source

        mentioned_user = SimpleNamespace(id=7)
        mentioned_source = SimpleNamespace(
            content="<:wave:111111111111111111>", stickers=[], attachments=[], author=mentioned_user
        )

        async def history(limit):
            assert limit == 50
            yield mentioned_source

        mention_context = SimpleNamespace(
            message=SimpleNamespace(reference=None, mentions=[mentioned_user]),
            channel=SimpleNamespace(history=history),
        )
        assert await bot_module._find_steal_source(mention_context) is mentioned_source

    asyncio.run(verify_sources())


def test_premium_gift_grants_default_allocation() -> None:
    from premium_features import PremiumFeatures, parse_stored_datetime, utc_now

    async def verify_gift() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE premium_allocations (
                allocation_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL, granted_by INTEGER NOT NULL,
                started_at TEXT NOT NULL, expires_at TEXT,
                guild_limit INTEGER NOT NULL, status TEXT NOT NULL
            );
            CREATE TABLE premium_users (user_id INTEGER PRIMARY KEY, expiry TEXT);
            """
        )
        feature = PremiumFeatures(SimpleNamespace(db=database, owner_ids={1}))
        feature._is_manager = lambda _user_id: True
        target = SimpleNamespace(id=123456789012345, mention="<@123456789012345>")
        feature._resolve_user = AsyncMock(return_value=target)
        context = SimpleNamespace(
            author=SimpleNamespace(id=1),
            interaction=None,
            send=AsyncMock(),
        )
        try:
            await PremiumFeatures.premium_gift.callback(feature, context, str(target.id))
            async with database.execute(
                "SELECT user_id, expires_at, guild_limit, status FROM premium_allocations"
            ) as cursor:
                row = await cursor.fetchone()
            assert row[0] == target.id
            assert row[2:] == (1, "active")
            assert (parse_stored_datetime(row[1]) - utc_now()).days in {29, 30}
            context.send.assert_awaited_once()
        finally:
            await database.close()

    asyncio.run(verify_gift())


def test_interaction_responses_are_public() -> None:
    from components_v2 import send_interaction_v2, send_v2

    async def verify_visibility() -> None:
        destination = SimpleNamespace(send=AsyncMock())
        await send_v2(destination, "public", ephemeral=True)
        assert destination.send.call_args.kwargs.get("ephemeral", False) is False

        response = SimpleNamespace(send_message=AsyncMock(), is_done=lambda: False)
        interaction = SimpleNamespace(response=response)
        await send_interaction_v2(interaction, "public", ephemeral=True)
        assert response.send_message.call_args.kwargs["ephemeral"] is False
        await send_interaction_v2(interaction, "private", ephemeral=True, allow_ephemeral=True)
        assert response.send_message.call_args.kwargs["ephemeral"] is True

    asyncio.run(verify_visibility())


def test_embed_builder_refreshes_existing_preview(monkeypatch) -> None:
    import community_features

    edit_interaction = AsyncMock()
    edit_message = AsyncMock()
    monkeypatch.setattr(
        community_features,
        "build_custom_embed",
        lambda *_args: discord.Embed(title="Updated preview"),
    )
    monkeypatch.setattr(community_features, "edit_interaction_v2", edit_interaction)
    monkeypatch.setattr(community_features, "edit_message_v2", edit_message)

    async def verify_refresh() -> None:
        view = community_features.AdvancedEmbedBuilderView(
            SimpleNamespace(bot=SimpleNamespace(user=None)),
            1,
            "sample",
            owner_id=2,
        )
        component_interaction = SimpleNamespace(
            user=SimpleNamespace(id=2),
            guild=SimpleNamespace(),
            channel=SimpleNamespace(),
            message=object(),
        )
        await view._refresh_preview(component_interaction)
        edit_interaction.assert_awaited_once()
        assert edit_interaction.await_args.args == (component_interaction,)
        assert edit_interaction.await_args.kwargs["view"] is view

        preview_message = object()
        view.message = preview_message
        modal_interaction = SimpleNamespace(
            user=SimpleNamespace(id=2),
            guild=SimpleNamespace(),
            channel=SimpleNamespace(),
            message=None,
            response=SimpleNamespace(defer=AsyncMock()),
            delete_original_response=AsyncMock(),
        )
        await view._refresh_preview(modal_interaction)
        modal_interaction.response.defer.assert_awaited_once_with(ephemeral=True)
        edit_message.assert_awaited_once()
        assert edit_message.await_args.args[0] is preview_message
        assert edit_message.await_args.kwargs["view"] is view
        modal_interaction.delete_original_response.assert_awaited_once()

    asyncio.run(verify_refresh())


def test_feature_embed_designs_persist_greet_boost_and_autoresponder(monkeypatch) -> None:
    import json

    import community_features

    async def verify_feature_persistence() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE greeting_settings (
                guild_id INTEGER PRIMARY KEY, channel_id INTEGER NOT NULL,
                join_config TEXT, leave_config TEXT,
                join_enabled INTEGER NOT NULL DEFAULT 1, leave_enabled INTEGER NOT NULL DEFAULT 1,
                updated_by INTEGER NOT NULL, updated_at TEXT NOT NULL
            );
            CREATE TABLE custom_embeds (
                guild_id INTEGER NOT NULL, name TEXT NOT NULL, config TEXT NOT NULL,
                created_by INTEGER NOT NULL, updated_at TEXT NOT NULL,
                PRIMARY KEY(guild_id, name)
            );
            CREATE TABLE boost_settings (
                guild_id INTEGER PRIMARY KEY, channel_id INTEGER NOT NULL, message TEXT NOT NULL,
                embed_name TEXT, updated_by INTEGER NOT NULL, updated_at TEXT NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1
            );
            CREATE TABLE autoresponders (
                guild_id INTEGER NOT NULL, trigger TEXT NOT NULL, response TEXT NOT NULL,
                mode TEXT NOT NULL DEFAULT 'contains',
                updated_by INTEGER NOT NULL, updated_at TEXT NOT NULL,
                PRIMARY KEY(guild_id, trigger)
            );
            INSERT INTO autoresponders (guild_id, trigger, response, updated_by, updated_at) VALUES
                (7, 'hello', 'Welcome {user.mention}! {delete} {sendto:55} {embed:old}', 8, 'now');
            """
        )
        bot = SimpleNamespace(db=database, user=SimpleNamespace(id=99, name="Falcon"))
        cog = community_features.CommunityFeatures(bot)
        editor_calls = []

        async def capture_editor(interaction, name, config=None, **kwargs):
            editor_calls.append({"name": name, "config": config, **kwargs})

        monkeypatch.setattr(cog, "_open_embed_editor", capture_editor)
        config = {"title": "{username}", "description": "A saved feature embed", "color": "#FFDD00"}
        try:
            await cog.save_greeting(7, "join", config, 8)
            async with database.execute(
                "SELECT join_config FROM greeting_settings WHERE guild_id=7"
            ) as cursor:
                greeting_row = await cursor.fetchone()
            assert json.loads(greeting_row[0]) == config
            greeting_interaction = SimpleNamespace(
                guild=SimpleNamespace(id=7),
                user=SimpleNamespace(id=8),
            )
            await cog.open_greeting_embed_editor(greeting_interaction, "join")
            assert editor_calls[-1]["name"] == "join greeting"
            await editor_calls[-1]["save_callback"](config)

            channel = SimpleNamespace(id=22)
            guild = SimpleNamespace(
                id=7,
                system_channel=channel,
                premium_subscription_count=3,
                premium_tier=1,
                get_channel=lambda _channel_id: None,
            )
            ctx = SimpleNamespace(
                guild=guild,
                channel=channel,
                author=SimpleNamespace(id=8, mention="<@8>"),
                interaction=object(),
                send=AsyncMock(),
            )

            await community_features.CommunityFeatures.boost_design.callback(cog, ctx, "boost-card")
            await editor_calls[-1]["save_callback"](config)
            async with database.execute(
                "SELECT embed_name FROM boost_settings WHERE guild_id=7"
            ) as cursor:
                boost_row = await cursor.fetchone()
            assert boost_row == ("boost-card",)

            await community_features.CommunityFeatures.autoresponder_design.callback(
                cog, ctx, "hello", "hello-card"
            )
            await editor_calls[-1]["save_callback"](config)
            async with database.execute(
                "SELECT response FROM autoresponders WHERE guild_id=7 AND trigger='hello'"
            ) as cursor:
                responder_row = await cursor.fetchone()
            assert responder_row[0] == "Welcome {user.mention}! {delete} {sendto:55} {embed:hello-card}"

            await community_features.CommunityFeatures.embed_import.callback(
                cog, ctx, "imported-card", config=json.dumps(config)
            )
            async with database.execute(
                "SELECT config FROM custom_embeds WHERE guild_id=7 AND name='imported-card'"
            ) as cursor:
                imported_config = await cursor.fetchone()
            assert json.loads(imported_config[0]) == config

            await community_features.CommunityFeatures.autoresponder_matchmode.callback(
                cog, ctx, "hello", "startswith"
            )
            async with database.execute(
                "SELECT mode FROM autoresponders WHERE guild_id=7 AND trigger='hello'"
            ) as cursor:
                assert await cursor.fetchone() == ("startswith",)
        finally:
            await database.close()

    asyncio.run(verify_feature_persistence())


def test_autoresponder_matches_whole_words_and_extracts_arguments() -> None:
    import community_features

    assert community_features._matches_autoresponder_trigger(
        "  Hello there", "hello", "startswith"
    )
    assert not community_features._matches_autoresponder_trigger(
        "hellothere", "hello", "startswith"
    )
    assert community_features._matches_autoresponder_trigger(
        "Say hello", "hello", "endswith"
    )
    assert not community_features._matches_autoresponder_trigger(
        "Sayhello", "hello", "endswith"
    )
    assert community_features._autoresponder_arguments(
        "hello world today", "hello", "startswith"
    ) == ["world", "today"]
    assert community_features._autoresponder_arguments(
        "today hello world", "hello", "contains"
    ) == ["today", "world"]


def test_help_panels_keep_original_layout_and_manifest_role_emoji() -> None:
    import main as bot_module

    home = bot_module.build_main_help_embed()
    assert home.title is None
    assert home.footer.text is None
    assert "**Auto Roles**" in home.description
    assert "Falcon • Command Center" not in home.description

    moderation = bot_module.build_section_embed("moderation")
    assert moderation.title == "Moderation"
    assert moderation.footer.text is None
    assert "`,channel delete #channel`" in moderation.description
    assert bot_module.HELP_SECTIONS["autoroles"]["emoji"] == bot_module.E_ROLE


def test_full_command_registry() -> None:
    import main as bot_module

    async def verify_registry() -> None:
        bot = bot_module.bot
        original_database_path = bot_module.DATABASE_PATH
        original_wait_until_ready = bot.wait_until_ready
        bot_module.DATABASE_PATH = ":memory:"
        bot.wait_until_ready = AsyncMock(return_value=None)
        try:
            await bot.setup_hook()
            commands = list(bot.walk_commands())
            assert bot.shard_count == 10
            assert bot.get_command("premium gift") is not None
            assert bot_module.DOT == bot_module.EMOJI_MANIFEST["dot"]
            for room_action in (
                "info", "set_channel", "set_category", "rename", "limit", "lock", "unlock",
                "allow", "block", "clear", "permit", "openchat", "closechat", "kick", "mute",
                "unmute", "summon", "claim", "transfer", "region", "status", "reset",
            ):
                assert bot.get_command(f"room {room_action}") is not None
            assert bot.get_command("setup create") is not None
            for name in ("close", "delete", "rename"):
                assert bot.get_command(name) is not None, f"Ticket command missing: {name}"
            for name in ("lock", "unlock", "hide", "unhide"):
                assert bot.get_command(name) is not None, f"Channel command missing: {name}"
            for emoji_name in ("delete", "cross"):
                emoji_value = bot_module.EMOJI_MANIFEST[emoji_name]
                assert emoji_value.startswith(("<:", "<a:")) and emoji_value.endswith(">")
            assert {
                name: bot_module.EMOJI_MANIFEST[name]
                for name in ("online", "offline", "dnd", "idle")
            } == {
                "online": "🟢",
                "offline": "⚫",
                "dnd": "🔴",
                "idle": "🟡",
            }
            assert len(commands) >= 250, f"Expected full command registry, found {len(commands)} commands"
            slash_roots = {command.name: command for command in bot.tree.get_commands()}
            assert len(slash_roots) <= 100, "Slash command tree exceeds Discord's global cap"

            removed_commands = {
                "play", "lplay", "lavalinkstatus", "lavalinkstart", "lavalinkstop",
                "search", "skip", "pause", "resume", "stop", "queue", "shuffle",
                "volume", "history", "lyrics", "nowplaying", "join",
            }
            assert not removed_commands.intersection(bot.all_commands), "Music commands are still registered"
            for name in ("np", "tag", "afk", "rps", "rr_add", "rr_remove", "rr_list", "sync"):
                assert name not in slash_roots, f"Short command is exposed as a slash command: {name}"
                assert name in bot.all_commands, f"Prefix-only command was lost: {name}"
            for name in ("moderation", "security", "utility"):
                assert name in slash_roots, f"Full command group missing from slash registry: {name}"
            assert slash_roots["voice"].get_command("permit") is not None
            assert slash_roots["tempvoice"].get_command("restore") is not None
            assert slash_roots["security"].get_command("antinuke") is not None
            assert slash_roots["utility"].get_command("serverinfo") is not None
            assert slash_roots["role"].get_command("all").get_command("bot") is not None
            assert "roleall" in bot.all_commands, "Bulk role command missing"
            for name in ("banall", "unbanall", "unball", "unroleall"):
                assert name in bot.all_commands, f"Bulk command missing: {name}"
            assert "purgeall" in bot.all_commands, "Purge-all command missing"
            for name in (
                "role add", "role remove", "role all bot", "role all humans", "role create",
                "automod", "warn", "warnings", "clearwarnings", "unwarn", "slowmode",
                "leave setup", "leave enable", "leave test", "leave reset",
                "greet enable", "greet embed", "greet preview", "greet config",
                "boost setup", "boost embed", "boost preview", "boost config",
                    "autoresponder enable", "autoresponder restrictions", "autoresponder delete",
                    "customcommand create", "customcommand edit", "customcommand enable",
                    "customcommand delete", "embed test",
                "help greet", "help leave", "help boost", "help autoresponder",
                    "help customcommand", "help embed", "help config",
            ):
                assert bot.get_command(name) is not None, f"Command missing: {name}"
            for name in ("jail", "unjail", "setjail"):
                assert bot.get_command(name) is not None, f"Command missing: {name}"

            for command in commands:
                assert callable(command.callback), f"Command has no callback: {command.qualified_name}"
                command.signature
                command.clean_params
        finally:
            pending = [task for task in asyncio.all_tasks() if task is not asyncio.current_task()]
            for task in pending:
                task.cancel()
            if pending:
                await asyncio.gather(*pending, return_exceptions=True)
            for cog_name in reversed(tuple(bot.cogs)):
                await bot.remove_cog(cog_name)
            await bot.close()
            bot.wait_until_ready = original_wait_until_ready
            bot_module.DATABASE_PATH = original_database_path

    asyncio.run(verify_registry())


def test_database_connection_migrates_legacy_file_without_deleting_it(tmp_path) -> None:
    import main as bot_module

    async def verify_migration() -> None:
        legacy_path = tmp_path / "falcon_data.db"
        source = await aiosqlite.connect(legacy_path)
        await source.execute("CREATE TABLE preserved_data (value TEXT NOT NULL)")
        await source.execute("INSERT INTO preserved_data VALUES ('kept')")
        await source.commit()
        await source.close()

        database = await bot_module._connect_database("falcon_data.db", project_dir=tmp_path)
        try:
            async with database.execute("SELECT value FROM preserved_data") as cursor:
                assert await cursor.fetchone() == ("kept",)
        finally:
            await database.close()

        assert legacy_path.exists()
        assert (tmp_path / "data" / "falcon_data.db").exists()

    asyncio.run(verify_migration())


def test_shard_connection_log_filter_only_keeps_first_connect_record() -> None:
    import main as bot_module

    log_filter = bot_module._SingleShardConnectLogFilter()
    first = logging.LogRecord(
        "discord.gateway", logging.INFO, __file__, 1,
        "Shard ID 1 has connected to Gateway", (), None,
    )
    second = logging.LogRecord(
        "discord.gateway", logging.INFO, __file__, 2,
        "Shard ID 2 has connected to Gateway", (), None,
    )
    unrelated = logging.LogRecord(
        "discord.gateway", logging.INFO, __file__, 3,
        "Shard ID 2 resumed its Gateway connection", (), None,
    )

    assert log_filter.filter(first) is True
    assert log_filter.filter(second) is False
    assert log_filter.filter(unrelated) is True


def test_rotating_presence_includes_counts_help_shards_and_owner() -> None:
    import main as bot_module

    activities = bot_module._build_presence_activities(
        member_count=12345,
        server_count=67,
        shard_count=10,
        owner_name="Falcon Owner",
    )

    assert len(activities) == 3
    assert activities[0].type is discord.ActivityType.streaming
    assert activities[0].name == "12,345 users | 67 servers"
    assert activities[0].url == bot_module.STREAM_STATUS_URL
    assert activities[1].type is discord.ActivityType.streaming
    assert activities[1].name == "/help | 10 shards"
    assert activities[1].url == bot_module.STREAM_STATUS_URL
    assert activities[2].type is discord.ActivityType.streaming
    assert activities[2].name == "Owner: Falcon Owner"
    assert activities[2].url == bot_module.STREAM_STATUS_URL
def test_shards_launch_in_sequence() -> None:
    import main as bot_module

    async def verify_launch() -> None:
        client = bot_module.FalconBot()
        client.shard_count = 3
        client.shard_ids = None
        client._connection.shard_count = None
        active_launches = 0
        max_active_launches = 0

        async def launch_shard(*_args, **_kwargs):
            nonlocal active_launches, max_active_launches
            active_launches += 1
            max_active_launches = max(max_active_launches, active_launches)
            await asyncio.sleep(0)
            active_launches -= 1

        launch_shard = AsyncMock(side_effect=launch_shard)
        client.launch_shard = launch_shard
        try:
            await client.launch_shards()
            assert launch_shard.await_count == 3
            assert [call.args[1] for call in launch_shard.await_args_list] == [0, 1, 2]
            assert [call.kwargs["initial"] for call in launch_shard.await_args_list] == [True, False, False]
            assert max_active_launches == 1
        finally:
            await client.close()

    asyncio.run(verify_launch())




def test_identify_hook_waits_only_within_same_discord_bucket(monkeypatch) -> None:
    import main as bot_module

    waits = []

    async def capture_sleep(delay):
        waits.append(delay)

    monkeypatch.setattr(bot_module.asyncio, "sleep", capture_sleep)
    client = SimpleNamespace(
        identify_max_concurrency=2,
        _identify_bucket_locks={},
        _identify_bucket_last_started={},
    )

    async def verify_buckets() -> None:
        await bot_module.FalconBot.before_identify_hook(client, 0, initial=True)
        await bot_module.FalconBot.before_identify_hook(client, 1)
        await bot_module.FalconBot.before_identify_hook(client, 2)
        assert len(waits) == 1
        assert 5.0 <= waits[0] <= 5.1

    asyncio.run(verify_buckets())


def test_on_ready_schedules_startup_work_without_blocking(monkeypatch) -> None:
    import main as bot_module

    class PendingTask:
        def done(self):
            return False

        def cancel(self):
            return None

    scheduled = []

    def schedule(coroutine):
        coroutine.close()
        task = PendingTask()
        scheduled.append(task)
        return task

    monkeypatch.setattr(
        bot_module,
        "bot",
        SimpleNamespace(
            status_rotation_task=None,
            post_ready_task=None,
            golden_neon_sync_task=None,
        ),
    )
    monkeypatch.setattr(bot_module.asyncio, "create_task", schedule)

    async def verify_ready_handler():
        await bot_module.on_ready()
        assert len(scheduled) == 3
        await bot_module.on_ready()
        assert len(scheduled) == 3

    asyncio.run(verify_ready_handler())


def test_post_ready_initialization_runs_parallel_startup_tasks(monkeypatch) -> None:
    import main as bot_module

    started = []
    release = [asyncio.Event(), asyncio.Event(), asyncio.Event()]

    async def fake_tree_sync():
        started.append("tree")
        await release[0].wait()
        return []

    async def fake_sync_emojis():
        started.append("emoji")
        await release[1].wait()
        return True

    async def fake_warm_guilds(*_args, **_kwargs):
        started.append("warm")
        await release[2].wait()
        return None

    monkeypatch.setattr(bot_module.bot, "slash_commands_synced", False)
    monkeypatch.setattr(bot_module.bot.tree, "sync", AsyncMock(side_effect=fake_tree_sync))
    monkeypatch.setattr(bot_module, "sync_application_emojis", AsyncMock(side_effect=fake_sync_emojis))
    monkeypatch.setattr(bot_module, "_warm_guild_runtime_state", AsyncMock(side_effect=fake_warm_guilds))
    monkeypatch.setattr(type(bot_module.bot), "guilds", property(lambda _self: [SimpleNamespace()]), raising=False)

    async def verify_parallel():
        task = asyncio.create_task(bot_module._post_ready_initialization())
        await asyncio.sleep(0.05)
        assert set(started) == {"tree", "emoji", "warm"}
        for gate in release:
            gate.set()
        await asyncio.wait_for(task, timeout=1)

    asyncio.run(verify_parallel())


def test_apply_golden_neon_to_existing_guilds_runs_concurrently(monkeypatch) -> None:
    import main as bot_module

    calls = []
    start = asyncio.Event()
    released = asyncio.Event()

    async def fake_apply(guild):
        calls.append(guild.id)
        await start.wait()
        await released.wait()
        return True

    guilds = [SimpleNamespace(id=10), SimpleNamespace(id=20), SimpleNamespace(id=30)]
    monkeypatch.setattr(type(bot_module.bot), "guilds", property(lambda _self: guilds), raising=False)
    monkeypatch.setattr(bot_module, "apply_golden_neon_name_style", fake_apply)

    async def verify_parallel():
        task = asyncio.create_task(bot_module.apply_golden_neon_to_existing_guilds())
        await asyncio.sleep(0.05)
        assert len(calls) == len(guilds)
        start.set()
        released.set()
        await asyncio.wait_for(task, timeout=1)
        assert set(calls) == {10, 20, 30}

    asyncio.run(verify_parallel())


def test_active_custom_greeting_detection() -> None:
    import main as bot_module

    async def verify_greeting_detection() -> None:
        original_database = bot_module.bot.db
        database = await aiosqlite.connect(":memory:")
        bot_module.bot.db = database
        await database.execute(
            "CREATE TABLE greeting_settings (guild_id INTEGER PRIMARY KEY, channel_id INTEGER, join_config TEXT, "
            "leave_config TEXT, join_enabled INTEGER, leave_enabled INTEGER, "
            "join_card_enabled INTEGER DEFAULT 0, leave_card_enabled INTEGER DEFAULT 0)"
        )
        await database.executemany(
            "INSERT INTO greeting_settings VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            [
                (1, 10, "{}", None, 1, 1, 0, 0),
                (2, 10, None, "{}", 1, 0, 0, 0),
                (3, 10, None, None, 1, 1, 1, 0),
            ],
        )
        await database.commit()
        try:
            assert await bot_module._active_custom_greeting_channel_id(1, "join") == 10
            assert await bot_module._active_custom_greeting_channel_id(1, "leave") is None
            assert await bot_module._active_custom_greeting_channel_id(2, "leave") is None
            assert await bot_module._active_custom_greeting_channel_id(3, "join") == 10
            assert await bot_module._active_custom_greeting_channel_id(3, "leave") is None
            assert await bot_module._active_custom_greeting_channel_id(999, "join") is None
            assert await bot_module._active_custom_greeting_channel_id(1, "vanity") is None
            missing_channel_guild = SimpleNamespace(get_channel=lambda _channel_id: None)
            assert await bot_module._active_custom_greeting_channel_id(
                1, "join", missing_channel_guild
            ) is None
        finally:
            await database.close()
            bot_module.bot.db = original_database

    asyncio.run(verify_greeting_detection())


def test_boost_settings_add_embed_migration() -> None:
    from community_features import CommunityFeatures

    async def verify_migration() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE boost_settings (guild_id INTEGER PRIMARY KEY, channel_id INTEGER NOT NULL, "
            "message TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1, updated_by INTEGER NOT NULL, "
            "updated_at TEXT NOT NULL)"
        )
        await database.execute(
            "INSERT INTO boost_settings VALUES (1, 5, 'Thanks {user.mention}', 1, 7, '2026-01-01')"
        )
        await database.commit()
        cog = CommunityFeatures(SimpleNamespace(db=database))
        try:
            await cog.cog_load()
            async with database.execute("PRAGMA table_info(boost_settings)") as cursor:
                columns = {row[1] for row in await cursor.fetchall()}
            assert "embed_name" in columns
            assert "card_enabled" in columns
            async with database.execute(
                "SELECT channel_id, message, enabled, embed_name, card_enabled "
                "FROM boost_settings WHERE guild_id=1"
            ) as cursor:
                assert await cursor.fetchone() == (5, "Thanks {user.mention}", 1, None, 0)
        finally:
            await database.close()

    asyncio.run(verify_migration())


def test_boost_event_renders_saved_embed(monkeypatch) -> None:
    import community_features

    async def verify_boost_embed() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            "CREATE TABLE boost_settings (guild_id INTEGER, channel_id INTEGER, message TEXT, "
            "enabled INTEGER, embed_name TEXT, card_enabled INTEGER DEFAULT 0);"
            "CREATE TABLE custom_embeds (guild_id INTEGER, name TEXT, config TEXT);"
            "INSERT INTO boost_settings VALUES (1, 5, 'Thanks {user.mention}', 1, 'thanks', 0);"
            "INSERT INTO custom_embeds VALUES (1, 'thanks', '{\"title\":\"Thanks {user.name}\","
            "\"description\":\"Boost #{boost_count}\",\"color\":\"#FFDD00\"}');"
        )
        channel = SimpleNamespace(id=5, name="boosts", mention="#boosts")
        guild = SimpleNamespace(
            id=1,
            name="Test Server",
            owner_id=99,
            member_count=10,
            premium_subscription_count=4,
            premium_tier=2,
            icon=None,
            get_member=lambda _user_id: None,
            get_channel=lambda channel_id: channel if channel_id == channel.id else None,
        )
        member = SimpleNamespace(
            id=2,
            name="Booster",
            display_name="Booster",
            mention="<@2>",
            display_avatar=SimpleNamespace(url="https://cdn.test/avatar.png"),
            created_at=None,
            joined_at=None,
            guild=guild,
        )
        sender = AsyncMock()
        monkeypatch.setattr(community_features, "send_v2", sender)
        cog = community_features.CommunityFeatures(
            SimpleNamespace(db=database, user=SimpleNamespace(name="Falcon", id=99))
        )
        try:
            await cog.on_member_update(
                SimpleNamespace(premium_since=None),
                SimpleNamespace(premium_since=object(), **member.__dict__),
            )
            sender.assert_awaited_once()
            sent_embed = sender.await_args.kwargs["embed"]
            assert sent_embed.title == "Thanks Booster"
            assert sent_embed.description == "Boost #4"
        finally:
            await database.close()

    asyncio.run(verify_boost_embed())


def test_boost_card_keeps_thanks_outside_image(monkeypatch) -> None:
    import io

    import community_features

    async def verify_boost_card() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            "CREATE TABLE boost_settings (guild_id INTEGER, channel_id INTEGER, message TEXT, "
            "enabled INTEGER, embed_name TEXT, card_enabled INTEGER);"
            "INSERT INTO boost_settings VALUES (1, 5, 'old text', 1, NULL, 1);"
        )
        channel = SimpleNamespace(id=5, mention="#boosts")
        guild = SimpleNamespace(
            id=1,
            name="Example Server",
            premium_subscription_count=8,
            premium_tier=2,
            get_channel=lambda _channel_id: channel,
        )
        member = SimpleNamespace(
            id=2,
            display_name="Booster",
            mention="<@2>",
            guild=guild,
            premium_since=object(),
        )
        send = AsyncMock()
        monkeypatch.setattr(community_features, "send_v2", send)
        cog = community_features.CommunityFeatures(SimpleNamespace(db=database, user=None))
        card = discord.File(io.BytesIO(b"card"), filename="booster.png")
        cog._build_member_event_card = AsyncMock(return_value=card)
        try:
            await cog.on_member_update(SimpleNamespace(premium_since=None), member)
            cog._build_member_event_card.assert_awaited_once_with(
                member,
                "boost",
                "LEVEL 2  •  BOOST #8",
            )
            send.assert_awaited_once()
            assert "Thank you <@2> for boosting **Example Server**!" == send.await_args.args[1]
            assert send.await_args.kwargs["file"] is card
            assert send.await_args.kwargs["embed"].image.url == "attachment://booster.png"
        finally:
            await database.close()

    asyncio.run(verify_boost_card())


def test_greeting_card_uses_configured_channel(monkeypatch) -> None:
    import io

    import community_features

    async def verify_greeting_card() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE greeting_settings (guild_id INTEGER PRIMARY KEY, channel_id INTEGER, "
            "join_config TEXT, leave_config TEXT, join_enabled INTEGER, leave_enabled INTEGER, "
            "join_card_enabled INTEGER, leave_card_enabled INTEGER)"
        )
        await database.execute("INSERT INTO greeting_settings VALUES (1, 5, NULL, NULL, 1, 1, 1, 0)")
        await database.commit()
        channel = SimpleNamespace(id=5)
        guild = SimpleNamespace(
            id=1,
            name="Example Server",
            member_count=4,
            icon=None,
            get_channel=lambda _channel_id: channel,
        )
        member = SimpleNamespace(id=2, display_name="New Member", guild=guild)
        send = AsyncMock()
        monkeypatch.setattr(community_features, "send_v2", send)
        cog = community_features.CommunityFeatures(SimpleNamespace(db=database, user=None))
        card = discord.File(io.BytesIO(b"card"), filename="welcome.png")
        cog._build_member_event_card = AsyncMock(return_value=card)
        try:
            assert await cog.send_configured_greeting(member, "join") is True
            cog._build_member_event_card.assert_awaited_once_with(member, "join", "MEMBER #4")
            send.assert_awaited_once()
            assert send.await_args.args[0] is channel
            assert send.await_args.kwargs["file"] is card
            assert send.await_args.kwargs["embed"].image.url == "attachment://welcome.png"
        finally:
            await database.close()

    asyncio.run(verify_greeting_card())


def test_boost_and_greeting_card_toggles_are_independent() -> None:
    import community_features

    async def verify_card_toggles() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            "CREATE TABLE boost_settings (guild_id INTEGER PRIMARY KEY, card_enabled INTEGER DEFAULT 0);"
            "INSERT INTO boost_settings VALUES (1, 0);"
            "CREATE TABLE greeting_settings (guild_id INTEGER PRIMARY KEY, channel_id INTEGER, "
            "join_card_enabled INTEGER DEFAULT 0, leave_card_enabled INTEGER DEFAULT 0);"
            "INSERT INTO greeting_settings VALUES (1, 5, 0, 0);"
        )
        cog = community_features.CommunityFeatures(SimpleNamespace(db=database))
        ctx = SimpleNamespace(
            guild=SimpleNamespace(id=1),
            author=SimpleNamespace(id=2),
            interaction=None,
            send=AsyncMock(),
        )
        try:
            await community_features.CommunityFeatures.boost_card.callback(cog, ctx, "enable")
            async with database.execute("SELECT card_enabled FROM boost_settings WHERE guild_id=1") as cursor:
                assert await cursor.fetchone() == (1,)
            await community_features.CommunityFeatures.greet_card.callback(cog, ctx, "enable", "both")
            async with database.execute(
                "SELECT join_card_enabled, leave_card_enabled FROM greeting_settings WHERE guild_id=1"
            ) as cursor:
                assert await cursor.fetchone() == (1, 1)
            await community_features.CommunityFeatures.greet_card.callback(cog, ctx, "disable", "leave")
            async with database.execute(
                "SELECT join_card_enabled, leave_card_enabled FROM greeting_settings WHERE guild_id=1"
            ) as cursor:
                assert await cursor.fetchone() == (1, 0)
            await community_features.CommunityFeatures.boost_card.callback(cog, ctx, "disable")
            async with database.execute("SELECT card_enabled FROM boost_settings WHERE guild_id=1") as cursor:
                assert await cursor.fetchone() == (0,)
        finally:
            await database.close()

    asyncio.run(verify_card_toggles())


def test_member_event_cards_render_png_with_optional_server_icon() -> None:
    import io

    from PIL import Image

    from community_features import render_member_event_card

    def png(color):
        output = io.BytesIO()
        Image.new("RGB", (32, 32), color).save(output, format="PNG")
        return output.getvalue()

    avatar = png("#ff00ff")
    server_icon = png("#00ffff")
    for event_kind in ("boost", "join", "leave"):
        card_bytes = render_member_event_card(
            avatar,
            "A very long member display name that needs fitting",
            "Example Server",
            event_kind,
            "MEMBER #52",
            guild_icon_bytes=server_icon,
        )
        assert card_bytes.startswith(b"\x89PNG\r\n\x1a\n")
        with Image.open(io.BytesIO(card_bytes)) as card:
            assert card.size == (1100, 360)


def test_levelup_card_posts_rank_image_when_enabled() -> None:
    import io

    import leveling_features

    async def verify_levelup_card() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE leveling_settings (
                guild_id INTEGER PRIMARY KEY, enabled INTEGER, xp_min INTEGER, xp_max INTEGER,
                cooldown_seconds INTEGER, multiplier REAL, voice_xp INTEGER,
                voice_interval_seconds INTEGER, daily_reward INTEGER, levelup_card_enabled INTEGER
            );
            INSERT INTO leveling_settings VALUES (1, 1, 15, 25, 60, 1.0, 10, 60, 100, 1);
            CREATE TABLE leveling_users (
                guild_id INTEGER, user_id INTEGER, xp INTEGER, streak INTEGER DEFAULT 0,
                last_claim_date TEXT, last_message_xp TEXT, updated_at TEXT, voice_seconds INTEGER DEFAULT 0,
                PRIMARY KEY(guild_id, user_id)
            );
            INSERT INTO leveling_users VALUES (1, 2, 250, 0, NULL, NULL, 'now', 30);
            CREATE TABLE leveling_rewards (guild_id INTEGER, level INTEGER, role_id INTEGER);
            """
        )
        member = SimpleNamespace(
            id=2,
            display_name="Member",
            mention="<@2>",
            roles=[],
            add_roles=AsyncMock(),
        )
        me = SimpleNamespace(top_role=SimpleNamespace())
        guild = SimpleNamespace(
            id=1,
            name="Example Server",
            me=me,
            system_channel=None,
            get_member=lambda _user_id: member,
            get_role=lambda _role_id: None,
        )
        member.guild = guild
        destination = SimpleNamespace(send=AsyncMock())
        cog = leveling_features.LevelingFeatures(SimpleNamespace(db=database))
        card = discord.File(io.BytesIO(b"rank card"), filename="rank.png")
        cog._rank_card = AsyncMock(return_value=card)
        try:
            await cog._grant_level_rewards(guild, member.id, 0, 1, channel=destination)
            cog._rank_card.assert_awaited_once()
            destination.send.assert_awaited_once()
            assert destination.send.await_args.kwargs["content"] == "<@2> leveled up!"
            assert destination.send.await_args.kwargs["embed"].title == "Level Up! Member reached Level 1"
            assert destination.send.await_args.kwargs["file"] is card

            ctx = SimpleNamespace(guild=guild, interaction=None, send=AsyncMock())
            await cog.levelup_card.callback(cog, ctx, "disable")
            async with database.execute(
                "SELECT levelup_card_enabled FROM leveling_settings WHERE guild_id=1"
            ) as cursor:
                assert await cursor.fetchone() == (0,)
        finally:
            await database.close()

    asyncio.run(verify_levelup_card())


def test_leveling_settings_migrate_levelup_card_flag() -> None:
    import leveling_features

    async def verify_migration() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE leveling_settings (guild_id INTEGER PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 0, "
            "xp_min INTEGER NOT NULL DEFAULT 15, xp_max INTEGER NOT NULL DEFAULT 25, "
            "cooldown_seconds INTEGER NOT NULL DEFAULT 60, multiplier REAL NOT NULL DEFAULT 1.0, "
            "voice_xp INTEGER NOT NULL DEFAULT 10, voice_interval_seconds INTEGER NOT NULL DEFAULT 60, "
            "daily_reward INTEGER NOT NULL DEFAULT 100)"
        )
        await database.execute("INSERT INTO leveling_settings (guild_id) VALUES (1)")
        await database.commit()
        cog = leveling_features.LevelingFeatures(SimpleNamespace(db=database))
        cog.voice_worker.start = lambda: None
        try:
            await cog.cog_load()
            settings = await cog._settings(1)
            assert settings["levelup_card_enabled"] == 0
            async with database.execute("PRAGMA table_info(leveling_settings)") as cursor:
                assert "levelup_card_enabled" in {row[1] for row in await cursor.fetchall()}
        finally:
            cog.cog_unload()
            await database.close()

    asyncio.run(verify_migration())


def test_leveling_settings_default_read_does_not_write() -> None:
    import leveling_features

    async def verify_read_only_defaults() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.execute(
            "CREATE TABLE leveling_settings ("
            "guild_id INTEGER PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 0, "
            "xp_min INTEGER NOT NULL DEFAULT 15, xp_max INTEGER NOT NULL DEFAULT 25, "
            "cooldown_seconds INTEGER NOT NULL DEFAULT 60, multiplier REAL NOT NULL DEFAULT 1.0, "
            "voice_xp INTEGER NOT NULL DEFAULT 10, voice_interval_seconds INTEGER NOT NULL DEFAULT 60, "
            "daily_reward INTEGER NOT NULL DEFAULT 100, levelup_card_enabled INTEGER NOT NULL DEFAULT 0)"
        )
        cog = leveling_features.LevelingFeatures(SimpleNamespace(db=database))
        try:
            settings = await cog._settings(123)
            assert settings["enabled"] == 0
            assert settings["xp_min"] == 15
            async with database.execute("SELECT COUNT(*) FROM leveling_settings") as cursor:
                assert await cursor.fetchone() == (0,)
        finally:
            await database.close()

    asyncio.run(verify_read_only_defaults())


def test_leveling_voice_worker_survives_database_errors(caplog) -> None:
    import leveling_features

    async def verify_worker_error_handling() -> None:
        cog = object.__new__(leveling_features.LevelingFeatures)
        cog._process_voice_worker_iteration = AsyncMock(
            side_effect=aiosqlite.OperationalError("attempt to write a readonly database")
        )
        await leveling_features.LevelingFeatures.voice_worker.coro(cog)
        cog._process_voice_worker_iteration.assert_awaited_once()

    asyncio.run(verify_worker_error_handling())
    assert "retrying next interval" in caplog.text


def test_ticket_close_defers_button_interaction_and_uses_private_followup() -> None:
    import denycord_interaction_features

    async def verify_deferred_close() -> None:
        cog = object.__new__(denycord_interaction_features.DenycordInteractionFeatures)
        state = {"done": False}

        async def defer(**_kwargs):
            state["done"] = True

        response = SimpleNamespace(
            is_done=lambda: state["done"],
            defer=AsyncMock(side_effect=defer),
            send_message=AsyncMock(),
        )
        followup = SimpleNamespace(send=AsyncMock())
        interaction = SimpleNamespace(
            response=response,
            followup=followup,
            guild=SimpleNamespace(id=1),
            channel=SimpleNamespace(id=2),
            user=SimpleNamespace(id=3),
        )

        async def close_after_deferring(_guild, _channel, _actor, respond):
            assert state["done"]
            await respond("Ticket closed")

        cog._close_ticket_for_actor = AsyncMock(side_effect=close_after_deferring)
        await cog.close_ticket(interaction)

        response.defer.assert_awaited_once_with(ephemeral=True, thinking=True)
        response.send_message.assert_not_awaited()
        followup.send.assert_awaited_once_with("Ticket closed", ephemeral=True)

    asyncio.run(verify_deferred_close())


def test_ticket_delete_refuses_to_delete_open_ticket() -> None:
    import denycord_interaction_features

    async def verify_open_ticket_is_preserved() -> None:
        cog = object.__new__(denycord_interaction_features.DenycordInteractionFeatures)
        cog._ticket_record = AsyncMock(return_value=(2, "open"))
        channel = SimpleNamespace(id=10, delete=AsyncMock())
        ctx = SimpleNamespace(
            guild=SimpleNamespace(id=1),
            channel=channel,
            author=SimpleNamespace(id=9),
            interaction=None,
            send=AsyncMock(),
        )

        await denycord_interaction_features.DenycordInteractionFeatures.delete_ticket_command.callback(
            cog, ctx
        )

        channel.delete.assert_not_awaited()
        assert "Close the ticket first" in ctx.send.await_args.args[0]

    asyncio.run(verify_open_ticket_is_preserved())


def test_general_channel_lock_and_visibility_preserve_other_overwrites() -> None:
    import main as bot_module

    class FakeChannel:
        def __init__(self, channel_id, channel_type, overwrite):
            self.id = channel_id
            self.type = channel_type
            self.mention = f"<#${channel_id}>"
            self.overwrite = overwrite
            self.guild = SimpleNamespace(id=1)
            self.edits = []

        def overwrites_for(self, _target):
            return self.overwrite

        async def set_permissions(self, target, *, overwrite, reason):
            self.edits.append((target, overwrite, reason))
            self.overwrite = overwrite or discord.PermissionOverwrite()

    async def verify_overwrites() -> None:
        default_role = object()
        ctx = SimpleNamespace(
            guild=SimpleNamespace(id=1, default_role=default_role),
            author=SimpleNamespace(id=7),
            send=AsyncMock(),
        )
        text_channel = FakeChannel(
            10,
            discord.ChannelType.text,
            discord.PermissionOverwrite(view_channel=True, connect=True),
        )
        await bot_module._set_channel_access_state(ctx, text_channel, "lock")
        assert text_channel.overwrite.send_messages is False
        assert text_channel.overwrite.connect is True
        assert text_channel.overwrite.view_channel is True

        await bot_module._set_channel_access_state(ctx, text_channel, "unlock")
        assert text_channel.overwrite.send_messages is None
        assert text_channel.overwrite.connect is True
        await bot_module._set_channel_access_state(ctx, text_channel, "hide")
        assert text_channel.overwrite.view_channel is False
        assert text_channel.overwrite.connect is True
        await bot_module._set_channel_access_state(ctx, text_channel, "unhide")
        assert text_channel.overwrite.view_channel is None
        assert text_channel.overwrite.connect is True

        voice_channel = FakeChannel(
            20,
            discord.ChannelType.voice,
            discord.PermissionOverwrite(view_channel=True, send_messages=True),
        )
        await bot_module._set_channel_access_state(ctx, voice_channel, "lock")
        assert voice_channel.overwrite.connect is False
        assert voice_channel.overwrite.send_messages is True
        assert voice_channel.overwrite.view_channel is True

    asyncio.run(verify_overwrites())


def test_saved_item_lists_use_pagination_controls() -> None:
    from community_features import CommunityFeatures

    async def verify_pagination() -> None:
        cog = CommunityFeatures(SimpleNamespace())
        ctx = SimpleNamespace(
            author=SimpleNamespace(id=1),
            interaction=None,
            send=AsyncMock(),
        )
        await cog._send_paged_list(ctx, "Saved Items", [f"Item {index}" for index in range(11)])
        sent_embed = ctx.send.await_args.kwargs["embed"]
        view = ctx.send.await_args.kwargs["view"]
        buttons = {button.label: button for button in view.children}
        assert sent_embed.footer.text == "Page 1/2"
        assert set(buttons) == {"Previous", "Next", "Close"}
        assert buttons["Previous"].disabled
        assert not buttons["Next"].disabled

    asyncio.run(verify_pagination())


def test_tempvoice_slash_groups_and_panel_cover_supported_controls() -> None:
    import denycord_voice_backup

    voice_commands = {command.name for command in denycord_voice_backup.DenycordVoiceBackup.voice.commands}
    settings_commands = {
        command.name for command in denycord_voice_backup.DenycordVoiceBackup.voice_settings.commands
    }
    admin_commands = {
        command.name for command in denycord_voice_backup.DenycordVoiceBackup.tempvoice.commands
    }
    assert voice_commands == {
        "settings", "name", "limit", "lock", "unlock", "hide", "unhide", "status",
        "delete", "reset", "interface", "permit", "reject", "trust", "untrust",
        "block", "unblock", "kick", "mute", "unmute", "deafen", "undeafen",
        "transfer", "claim", "invite",
    }
    assert settings_commands == {"bitrate", "region", "textchat"}
    assert admin_commands == {
        "setup", "set-generator", "set-category", "set-panel", "set-staff",
        "config", "stats", "cleanup", "backup", "restore", "disable", "enable",
    }

    cog = denycord_voice_backup.DenycordVoiceBackup(SimpleNamespace(user=None))
    view = cog.room_panel
    buttons = [
        child for child in view.walk_children()
        if isinstance(child, discord.ui.Button)
    ]
    button_actions = {
        button.custom_id.removeprefix("denycord:room:").partition(":")[0]
        for button in buttons
    }
    assert button_actions >= {
        "lock", "unlock", "hide", "unhide", "rename", "limit", "permit",
        "unblock", "trust", "untrust", "transfer", "claim", "kick", "delete",
        "refresh", "openchat", "closechat", "status", "reset", "invite",
    }
    assert len(buttons) == len(denycord_voice_backup.ROOM_PANEL_BUTTONS)
    assert all(button.label is None and button.emoji.id for button in buttons)
    assert len({button.emoji.id for button in buttons}) == len(buttons)
    for emoji_key, _name, _action, _style, _needs_modal in denycord_voice_backup.ROOM_PANEL_BUTTONS:
        button = next(
            button for button in buttons
            if button.custom_id.endswith(f":{emoji_key}")
        )
        assert button.style is discord.ButtonStyle.secondary
    assert not any(
        isinstance(child, discord.ui.Select)
        for child in view.walk_children()
    )
    assert len(list(view.walk_children())) <= 40
    assert all(
        len(row.children) <= denycord_voice_backup.ROOM_PANEL_BUTTONS_PER_ROW
        for row in view.children[0].children
        if isinstance(row, discord.ui.ActionRow)
    )
    assert isinstance(view.children[0], discord.ui.Container)
    assert len(view.children) >= 2
    assert all(
        isinstance(child, discord.ui.ActionRow)
        for child in view.children[1:]
    )
    assert {button.style for button in buttons} == {discord.ButtonStyle.secondary}


def test_tempvoice_button_emoji_manifest_contains_all_supplied_icons() -> None:
    import denycord_voice_backup

    assert set(denycord_voice_backup.VOICE_BUTTON_EMOJIS) == {
        "lock", "unlock", "secure", "private", "hide", "unhide", "unban",
        "mute", "unmute", "block", "permit", "claim", "transfer", "rename",
        "ban",
        "limit", "delete", "setting", "invite", "kick", "chat", "announce",
        "info", "premium", "fast", "active", "voice_support", "unlimited",
        "love", "start",
    }
    assert all(emoji.id is not None for emoji in denycord_voice_backup.VOICE_BUTTON_EMOJIS.values())


def test_tempvoice_placeholder_emoji_assets_are_valid_pngs() -> None:
    import denycord_voice_backup

    fallback = denycord_voice_backup._placeholder_emoji_bytes("L")
    with Image.open(io.BytesIO(fallback)) as image:
        image.load()
    assert image.size == (64, 64)


def test_tempvoice_custom_emoji_buttons_dispatch_actions() -> None:
    import denycord_voice_backup

    async def verify_callbacks() -> None:
        cog = denycord_voice_backup.DenycordVoiceBackup(SimpleNamespace(user=None))
        cog._handle_room_interaction = AsyncMock()
        response = SimpleNamespace(
            send_modal=AsyncMock(),
        )
        interaction = SimpleNamespace(response=response)
        buttons_by_key = {
            emoji_key: button
            for button in cog.room_panel.walk_children()
            if isinstance(button, discord.ui.Button)
            for emoji_key, _name, _action, _style, _needs_modal
            in denycord_voice_backup.ROOM_PANEL_BUTTONS
            if button.custom_id.endswith(f":{emoji_key}")
        }

        for emoji_key, _name, action, _style, needs_modal in denycord_voice_backup.ROOM_PANEL_BUTTONS:
            cog._handle_room_interaction.reset_mock()
            response.send_modal.reset_mock()
            await buttons_by_key[emoji_key].callback(interaction)
            if needs_modal:
                response.send_modal.assert_awaited_once()
                assert response.send_modal.await_args.args[0].action == action
                cog._handle_room_interaction.assert_not_awaited()
            else:
                cog._handle_room_interaction.assert_awaited_once_with(interaction, action)
                response.send_modal.assert_not_awaited()

    asyncio.run(verify_callbacks())


def test_tempvoice_config_rejects_invalid_values_without_crashing(tmp_path) -> None:
    import denycord_voice_backup

    config_path = tmp_path / "config.yml"
    config_path.write_text(
        "tempvoice:\n"
        "  default_user_limit: invalid\n"
        "  default_bitrate_kbps: 1000\n"
        "  default_region: moon\n"
        "  creation_cooldown_seconds: never\n"
        "  max_temp_channels_per_guild: 0\n"
        "  claim_timeout_seconds: forever\n"
        "  auto_delete_empty: yes\n"
        "  allowed_controls: [slowmode, lock]\n"
        "  theme: broken\n",
        encoding="utf-8",
    )
    settings = denycord_voice_backup.load_tempvoice_config(config_path)["tempvoice"]
    assert settings["default_user_limit"] == 0
    assert settings["default_bitrate_kbps"] == 384
    assert settings["default_region"] == "auto"
    assert settings["creation_cooldown_seconds"] == 5
    assert settings["max_temp_channels_per_guild"] == 1
    assert settings["claim_timeout_seconds"] == 0
    assert settings["auto_delete_empty"] is True
    assert settings["allowed_controls"] == ["lock"]
    assert settings["theme"]["embed_color"] == 0xFFDD00


def test_tempvoice_delete_confirmation_view_is_sent_ephemerally() -> None:
    import denycord_voice_backup

    async def verify_delete_confirmation() -> None:
        user = Mock(spec=discord.Member)
        user.id = 24
        user.voice = None
        guild = SimpleNamespace(id=10)
        response = SimpleNamespace(
            is_done=lambda: False,
            send_message=AsyncMock(),
        )
        interaction = SimpleNamespace(
            guild=guild,
            user=user,
            response=response,
            followup=SimpleNamespace(send=AsyncMock()),
        )
        cog = denycord_voice_backup.DenycordVoiceBackup(SimpleNamespace())
        confirmation = discord.ui.View(timeout=10)
        cog._perform_room_action = AsyncMock(return_value=confirmation)
        cog._audit_room_action = AsyncMock()

        await cog._handle_room_interaction(interaction, "delete")

        response.send_message.assert_awaited_once()
        kwargs = response.send_message.await_args.kwargs
        assert kwargs["ephemeral"] is True
        assert kwargs["view"] is confirmation
        assert "Confirm deleting" in kwargs["content"]

    asyncio.run(verify_delete_confirmation())


def test_tempvoice_restore_validates_and_replaces_only_current_guild_data() -> None:
    import json
    import denycord_voice_backup

    async def verify_restore() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE denycord_voice_settings (
                guild_id INTEGER PRIMARY KEY, hub_channel_id INTEGER NOT NULL,
                panel_channel_id INTEGER NOT NULL, category_id INTEGER,
                interface_message_id INTEGER, enabled INTEGER NOT NULL DEFAULT 1
            );
            CREATE TABLE denycord_voice_generators (
                guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL, category_id INTEGER,
                created_by INTEGER, created_at TEXT NOT NULL,
                PRIMARY KEY(guild_id, channel_id)
            );
            CREATE TABLE denycord_voice_staff_roles (
                guild_id INTEGER NOT NULL, role_id INTEGER NOT NULL, created_by INTEGER NOT NULL,
                created_at TEXT NOT NULL, PRIMARY KEY(guild_id, role_id)
            );
            CREATE TABLE denycord_voice_rooms (
                guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL, owner_id INTEGER NOT NULL,
                created_at TEXT NOT NULL, locked INTEGER NOT NULL DEFAULT 1,
                user_limit INTEGER NOT NULL DEFAULT 0, rtc_region TEXT,
                chat_open INTEGER NOT NULL DEFAULT 1, hidden INTEGER NOT NULL DEFAULT 0,
                panel_message_id INTEGER, PRIMARY KEY(guild_id, channel_id)
            );
            CREATE TABLE denycord_voice_overrides (
                guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
                allow_connect INTEGER, allow_chat INTEGER,
                PRIMARY KEY(guild_id, channel_id, user_id)
            );
            INSERT INTO denycord_voice_settings VALUES (5, 1, 2, NULL, NULL, 0);
            INSERT INTO denycord_voice_settings VALUES (6, 11, 12, NULL, NULL, 1);
            """
        )
        generator = Mock(spec=discord.VoiceChannel)
        panel = Mock(spec=discord.TextChannel)
        room = Mock(spec=discord.VoiceChannel)
        generator.id = 10
        panel.id = 20
        room.id = 30
        channels = {10: generator, 20: panel, 30: room}
        role = SimpleNamespace(id=40)
        guild = SimpleNamespace(
            id=5,
            get_channel=lambda channel_id: channels.get(channel_id),
            get_role=lambda role_id: role if role_id == 40 else None,
        )
        user = Mock(spec=discord.Member)
        user.guild_permissions = SimpleNamespace(manage_guild=True)
        response = SimpleNamespace(send_message=AsyncMock())
        interaction = SimpleNamespace(
            guild=guild,
            user=user,
            response=response,
        )
        payload = {
            "format": "falcon-tempvoice-v1",
            "guild_id": 5,
            "settings": [10, 20, None, 700, 1],
            "generators": [[10, None, 9, "2026-01-01T00:00:00+00:00"]],
            "staff_roles": [[40, 9, "2026-01-01T00:00:00+00:00"]],
            "rooms": [[30, 11, "2026-01-01T00:00:00+00:00", 0, 0, None, 1, 0, None]],
            "overrides": [[30, 12, 0, 0]],
        }
        attachment = SimpleNamespace(
            size=len(json.dumps(payload).encode("utf-8")),
            read=AsyncMock(return_value=json.dumps(payload).encode("utf-8")),
        )
        cog = denycord_voice_backup.DenycordVoiceBackup(SimpleNamespace(db=database))
        try:
            await denycord_voice_backup.DenycordVoiceBackup.tempvoice_restore.callback(
                cog,
                interaction,
                attachment,
            )
            async with database.execute(
                "SELECT hub_channel_id, panel_channel_id, enabled "
                "FROM denycord_voice_settings WHERE guild_id=5"
            ) as cursor:
                assert await cursor.fetchone() == (10, 20, 1)
            async with database.execute(
                "SELECT hub_channel_id FROM denycord_voice_settings WHERE guild_id=6"
            ) as cursor:
                assert await cursor.fetchone() == (11,)
            async with database.execute(
                "SELECT owner_id FROM denycord_voice_rooms WHERE guild_id=5 AND channel_id=30"
            ) as cursor:
                assert await cursor.fetchone() == (11,)
            async with database.execute(
                "SELECT allow_connect, allow_chat FROM denycord_voice_overrides "
                "WHERE guild_id=5 AND channel_id=30 AND user_id=12"
            ) as cursor:
                assert await cursor.fetchone() == (0, 0)
            response.send_message.assert_awaited_once()
            assert response.send_message.await_args.kwargs["ephemeral"] is True
        finally:
            await database.close()

    asyncio.run(verify_restore())


def test_tempvoice_setup_persists_generator_panel_and_category() -> None:
    import denycord_voice_backup

    async def verify_setup() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE denycord_voice_settings (
                guild_id INTEGER PRIMARY KEY, hub_channel_id INTEGER NOT NULL,
                panel_channel_id INTEGER NOT NULL, category_id INTEGER,
                interface_message_id INTEGER, enabled INTEGER NOT NULL DEFAULT 1
            );
            CREATE TABLE denycord_voice_generators (
                guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL, category_id INTEGER,
                created_by INTEGER, created_at TEXT NOT NULL,
                PRIMARY KEY(guild_id, channel_id)
            );
            """
        )
        category = SimpleNamespace(id=30, name="Voice")
        generator = Mock(spec=discord.VoiceChannel)
        generator.id = 10
        generator.category = category
        generator.mention = "<#10>"
        generator.permissions_for = Mock(
            return_value=SimpleNamespace(
                view_channel=True,
                connect=True,
                move_members=True,
            )
        )
        panel = Mock(spec=discord.TextChannel)
        panel.id = 20
        panel.mention = "<#20>"
        panel.permissions_for = Mock(
            return_value=SimpleNamespace(
                view_channel=True,
                send_messages=True,
                embed_links=True,
                attach_files=True,
            )
        )
        bot_member = SimpleNamespace(
            guild_permissions=discord.Permissions(manage_channels=True, move_members=True)
        )
        guild = SimpleNamespace(id=5, me=bot_member)
        category.guild = guild
        member = Mock(spec=discord.Member)
        member.id = 7
        member.guild_permissions = SimpleNamespace(manage_guild=True)
        interaction = SimpleNamespace(
            guild=guild,
            user=member,
            response=SimpleNamespace(send_message=AsyncMock()),
        )
        cog = denycord_voice_backup.DenycordVoiceBackup(SimpleNamespace(db=database))
        cog._ensure_voice_interface = AsyncMock(return_value=500)
        try:
            await denycord_voice_backup.DenycordVoiceBackup.tempvoice_setup.callback(
                cog,
                interaction,
                generator,
                panel,
            )
            async with database.execute(
                "SELECT hub_channel_id, panel_channel_id, category_id, interface_message_id, enabled "
                "FROM denycord_voice_settings WHERE guild_id=5"
            ) as cursor:
                assert await cursor.fetchone() == (10, 20, 30, 500, 1)
            async with database.execute(
                "SELECT channel_id, category_id, created_by FROM denycord_voice_generators "
                "WHERE guild_id=5"
            ) as cursor:
                assert await cursor.fetchone() == (10, 30, 7)
            cog._ensure_voice_interface.assert_awaited_once()
            interaction.response.send_message.assert_awaited_once()
            assert interaction.response.send_message.await_args.kwargs["ephemeral"] is True
        finally:
            await database.close()

    asyncio.run(verify_setup())


def test_tempvoice_claim_transfer_and_oldest_member_auto_transfer(monkeypatch) -> None:
    import datetime
    import denycord_voice_backup

    async def verify_ownership() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE denycord_voice_rooms (
                guild_id INTEGER, channel_id INTEGER, owner_id INTEGER, created_at TEXT,
                locked INTEGER, user_limit INTEGER, rtc_region TEXT, chat_open INTEGER,
                hidden INTEGER, panel_message_id INTEGER,
                PRIMARY KEY(guild_id, channel_id)
            );
            CREATE TABLE denycord_voice_staff_roles (
                guild_id INTEGER, role_id INTEGER, created_by INTEGER, created_at TEXT,
                PRIMARY KEY(guild_id, role_id)
            );
            INSERT INTO denycord_voice_rooms VALUES
                (5, 30, 2, '2026-01-01T00:00:00+00:00', 0, 0, NULL, 1, 0, NULL);
            """
        )
        old_owner = SimpleNamespace(id=2, bot=False, roles=[], guild_permissions=discord.Permissions.none())
        claimant = SimpleNamespace(id=3, bot=False, roles=[], guild_permissions=discord.Permissions.none())
        recipient = SimpleNamespace(id=4, bot=False, roles=[], guild_permissions=discord.Permissions.none())
        oldest = SimpleNamespace(
            id=5,
            bot=False,
            joined_at=datetime.datetime(2020, 1, 1, tzinfo=datetime.timezone.utc),
        )
        newer = SimpleNamespace(
            id=6,
            bot=False,
            joined_at=datetime.datetime(2022, 1, 1, tzinfo=datetime.timezone.utc),
        )
        bot_member = SimpleNamespace(
            id=99,
            guild_permissions=discord.Permissions(manage_channels=True),
        )
        permissions = SimpleNamespace(manage_channels=True)
        channel = SimpleNamespace(
            id=30,
            name="Room",
            mention="<#30>",
            members=[old_owner, claimant, recipient],
            overwrites={},
            permissions_for=lambda _member: permissions,
            set_permissions=AsyncMock(),
        )
        guild = SimpleNamespace(
            id=5,
            owner_id=1,
            me=bot_member,
            default_role=object(),
            get_member=lambda user_id: {
                2: old_owner,
                3: claimant,
                4: recipient,
                5: oldest,
                6: newer,
            }.get(user_id),
        )
        channel.guild = guild
        for member in (old_owner, claimant, recipient):
            member.voice = SimpleNamespace(channel=channel)
            member.mention = f"<@{member.id}>"
            member.guild = guild
        bot = SimpleNamespace(db=database)
        cog = denycord_voice_backup.DenycordVoiceBackup(bot)
        cog._audit_room_action = AsyncMock()
        monkeypatch.setitem(
            denycord_voice_backup.TEMPVOICE_CONFIG,
            "ownership_transfer_policy",
            "claim_after_owner_leaves",
        )
        try:
            blocked_claim = await cog._perform_room_action(guild, claimant, "claim")
            assert "still in the room" in blocked_claim
            channel.members.remove(old_owner)
            claimed = await cog._perform_room_action(guild, claimant, "claim")
            assert "now own" in claimed
            async with database.execute(
                "SELECT owner_id FROM denycord_voice_rooms WHERE guild_id=5 AND channel_id=30"
            ) as cursor:
                assert await cursor.fetchone() == (3,)

            transferred = await cog._perform_room_action(guild, claimant, "transfer", recipient.id)
            assert "transferred" in transferred
            async with database.execute(
                "SELECT owner_id FROM denycord_voice_rooms WHERE guild_id=5 AND channel_id=30"
            ) as cursor:
                assert await cursor.fetchone() == (4,)

            channel.members = [recipient, oldest, newer]
            await cog._transfer_owner_after_leave(recipient, channel)
            async with database.execute(
                "SELECT owner_id FROM denycord_voice_rooms WHERE guild_id=5 AND channel_id=30"
            ) as cursor:
                assert await cursor.fetchone() == (5,)
            channel.set_permissions.assert_awaited()
        finally:
            await database.close()

    asyncio.run(verify_ownership())


def test_tempvoice_duplicate_generator_events_are_serialized_per_guild() -> None:
    import denycord_voice_backup

    async def verify_duplicate_events() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE denycord_voice_settings (
                guild_id INTEGER PRIMARY KEY, hub_channel_id INTEGER NOT NULL,
                panel_channel_id INTEGER NOT NULL, category_id INTEGER,
                interface_message_id INTEGER, enabled INTEGER NOT NULL DEFAULT 1
            );
            CREATE TABLE denycord_voice_generators (
                guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL, category_id INTEGER,
                created_by INTEGER, created_at TEXT NOT NULL,
                PRIMARY KEY(guild_id, channel_id)
            );
            CREATE TABLE denycord_voice_rooms (
                guild_id INTEGER, channel_id INTEGER, owner_id INTEGER, created_at TEXT,
                locked INTEGER, user_limit INTEGER, rtc_region TEXT, chat_open INTEGER,
                hidden INTEGER, panel_message_id INTEGER,
                PRIMARY KEY(guild_id, channel_id)
            );
            INSERT INTO denycord_voice_settings VALUES (5, 20, 30, NULL, NULL, 1);
            INSERT INTO denycord_voice_generators VALUES
                (5, 20, NULL, 7, '2026-01-01T00:00:00+00:00');
            """
        )
        generator = SimpleNamespace(id=20)
        guild = SimpleNamespace(id=5)
        member = SimpleNamespace(
            id=7,
            bot=False,
            guild=guild,
            voice=SimpleNamespace(channel=generator),
        )
        cog = denycord_voice_backup.DenycordVoiceBackup(SimpleNamespace(db=database))

        async def create_room(*_args, **_kwargs):
            await asyncio.sleep(0.01)

        cog._create_temp_room = AsyncMock(side_effect=create_room)
        before = SimpleNamespace(channel=None)
        after = SimpleNamespace(channel=generator)
        try:
            await asyncio.gather(
                cog._voice_state_changed(member, before, after),
                cog._voice_state_changed(member, before, after),
            )
            cog._create_temp_room.assert_awaited_once_with(member, None, 20)
        finally:
            await database.close()

    asyncio.run(verify_duplicate_events())


def test_tempvoice_cleanup_removes_empty_rooms_and_stale_records() -> None:
    import denycord_voice_backup

    async def verify_cleanup() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE denycord_voice_rooms (
                guild_id INTEGER, channel_id INTEGER, owner_id INTEGER, created_at TEXT,
                locked INTEGER, user_limit INTEGER, rtc_region TEXT, chat_open INTEGER,
                hidden INTEGER, panel_message_id INTEGER,
                PRIMARY KEY(guild_id, channel_id)
            );
            CREATE TABLE denycord_voice_overrides (
                guild_id INTEGER, channel_id INTEGER, user_id INTEGER,
                allow_connect INTEGER, allow_chat INTEGER,
                PRIMARY KEY(guild_id, channel_id, user_id)
            );
            INSERT INTO denycord_voice_rooms VALUES
                (5, 30, 7, '2026-01-01T00:00:00+00:00', 0, 0, NULL, 1, 0, NULL),
                (5, 31, 8, '2026-01-01T00:00:00+00:00', 0, 0, NULL, 1, 0, NULL),
                (6, 60, 9, '2026-01-01T00:00:00+00:00', 0, 0, NULL, 1, 0, NULL);
            INSERT INTO denycord_voice_overrides VALUES (5, 30, 9, 1, 1);
            INSERT INTO denycord_voice_overrides VALUES (5, 31, 10, 0, 0);
            """
        )
        channel = Mock(spec=discord.VoiceChannel)
        channel.id = 30
        channel.members = []
        channel.delete = AsyncMock()
        guild = SimpleNamespace(
            id=5,
            get_channel=lambda channel_id: channel if channel_id == 30 else None,
        )
        other_channel = Mock(spec=discord.VoiceChannel)
        other_channel.id = 60
        other_channel.members = []
        other_channel.delete = AsyncMock()
        other_guild = SimpleNamespace(
            id=6,
            get_channel=lambda channel_id: other_channel if channel_id == 60 else None,
        )
        other_channel.guild = other_guild
        channel.guild = guild
        cog = denycord_voice_backup.DenycordVoiceBackup(
            SimpleNamespace(
                db=database,
                get_guild=lambda guild_id: {5: guild, 6: other_guild}.get(guild_id),
            )
        )
        try:
            await cog._cleanup_empty_rooms(5)
            channel.delete.assert_awaited_once()
            other_channel.delete.assert_not_awaited()
            async with database.execute(
                "SELECT COUNT(*) FROM denycord_voice_rooms WHERE guild_id=5"
            ) as cursor:
                assert await cursor.fetchone() == (0,)
            async with database.execute(
                "SELECT COUNT(*) FROM denycord_voice_overrides WHERE guild_id=5"
            ) as cursor:
                assert await cursor.fetchone() == (0,)
            async with database.execute(
                "SELECT COUNT(*) FROM denycord_voice_rooms WHERE guild_id=6"
            ) as cursor:
                assert await cursor.fetchone() == (1,)
            await cog._cleanup_empty_rooms()
            other_channel.delete.assert_awaited_once()
            async with database.execute(
                "SELECT COUNT(*) FROM denycord_voice_rooms WHERE guild_id=6"
            ) as cursor:
                assert await cursor.fetchone() == (0,)
        finally:
            await database.close()

    asyncio.run(verify_cleanup())


def test_accage_shows_calendar_duration_and_user_avatar() -> None:
    import datetime
    from dateutil.relativedelta import relativedelta
    import main as bot_module

    async def verify_accage() -> None:
        now = datetime.datetime.now(datetime.timezone.utc)
        user = SimpleNamespace(
            name="shivay001991",
            id=42,
            created_at=now - relativedelta(
                years=1, months=6, weeks=2, days=5, hours=6, minutes=7
            ),
            display_avatar=SimpleNamespace(url="https://example.test/avatar.png"),
        )
        ctx = SimpleNamespace(author=user, send=AsyncMock())

        await bot_module.accage.callback(ctx, user)

        embed = ctx.send.await_args.kwargs["embed"]
        assert embed.title == "shivay001991's account age"
        assert embed.thumbnail.url == user.display_avatar.url
        assert "1 years, 6 months, 2 weeks, 5 days" in embed.description
        assert "hours, " in embed.description
        assert "minutes and " in embed.description
        assert embed.description.endswith(" seconds")

    asyncio.run(verify_accage())


def test_tempvoice_channel_move_failure_cleans_up_created_channel() -> None:
    import denycord_voice_backup

    class FakeMember:
        def __init__(self, member_id, permissions=None):
            self.id = member_id
            self.display_name = "Test"
            self.name = "Test"
            self.guild_permissions = permissions or discord.Permissions.none()
            error_response = SimpleNamespace(
                status=403,
                reason="Forbidden",
                headers={},
            )
            self.move_to = AsyncMock(
                side_effect=discord.Forbidden(error_response, "move denied")
            )

    async def verify_failure_cleanup() -> None:
        database = await aiosqlite.connect(":memory:")
        await database.executescript(
            """
            CREATE TABLE denycord_voice_settings (
                guild_id INTEGER PRIMARY KEY, hub_channel_id INTEGER NOT NULL,
                panel_channel_id INTEGER NOT NULL, category_id INTEGER,
                interface_message_id INTEGER, enabled INTEGER NOT NULL DEFAULT 1
            );
            CREATE TABLE denycord_voice_rooms (
                guild_id INTEGER, channel_id INTEGER, owner_id INTEGER, created_at TEXT,
                locked INTEGER, user_limit INTEGER, rtc_region TEXT, chat_open INTEGER,
                hidden INTEGER, panel_message_id INTEGER,
                PRIMARY KEY(guild_id, channel_id)
            );
            CREATE TABLE denycord_voice_overrides (
                guild_id INTEGER, channel_id INTEGER, user_id INTEGER,
                allow_connect INTEGER, allow_chat INTEGER,
                PRIMARY KEY(guild_id, channel_id, user_id)
            );
            INSERT INTO denycord_voice_settings VALUES (5, 20, 30, NULL, NULL, 1);
            """
        )
        bot_member = FakeMember(
            99,
            discord.Permissions(manage_channels=True, move_members=True),
        )
        everyone = FakeMember(1)
        hub = SimpleNamespace(
            id=20,
            permissions_for=lambda _member: SimpleNamespace(
                view_channel=True,
                connect=True,
                move_members=True,
            ),
        )
        guild = SimpleNamespace(
            id=5,
            me=bot_member,
            default_role=everyone,
            premium_tier=0,
            get_channel=lambda channel_id: hub if channel_id == 20 else None,
        )
        room = SimpleNamespace(
            id=40,
            guild=guild,
            delete=AsyncMock(),
        )
        guild.create_voice_channel = AsyncMock(return_value=room)
        member = FakeMember(7)
        member.guild = guild
        cog = denycord_voice_backup.DenycordVoiceBackup(SimpleNamespace(db=database, user=None))
        try:
            await cog._create_temp_room(member, None, 20)
            room.delete.assert_awaited_once()
            async with database.execute(
                "SELECT COUNT(*) FROM denycord_voice_rooms WHERE guild_id=5 AND channel_id=40"
            ) as cursor:
                assert await cursor.fetchone() == (0,)
        finally:
            await database.close()

    asyncio.run(verify_failure_cleanup())
