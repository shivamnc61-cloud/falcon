# Falcon Premium Bot

Falcon is an asynchronous Discord bot built with discord.py, aiosqlite, and SQLite.

## Run locally

1. Install dependencies with `python -m pip install -r requirements.txt`.
2. Copy `.env.example` to `.env` and set `DISCORD_TOKEN`.
3. Run `python main.py`.

Keep the real `.env` file private. The bot database path is configured with `DATABASE_PATH`.

## TempVoice

Falcon includes Join-to-Create voice rooms, persistent owner controls, slash commands, staff overrides, multi-generator configuration, and JSON backup/restore.

See [TEMPVOICE_GUIDE.md](./TEMPVOICE_GUIDE.md) for Hindi setup, permissions, supported commands, and local, Railway, and Termux deployment notes.
