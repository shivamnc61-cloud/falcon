import asyncio
import datetime
import hashlib
import io
import json
import os
import re
import shlex
from typing import Literal
from urllib.parse import urlsplit
from pathlib import Path

import aiohttp
import discord
from discord.ext import commands
from PIL import Image, ImageDraw, ImageFont, ImageOps

from components_v2 import edit_interaction_v2, edit_message_v2, send_interaction_v2, send_v2
from premium_features import utc_now
from time_parser import parse_duration


ALIAS_PATTERN = re.compile(r"^[a-z][a-z0-9_-]{0,31}$")
VARIABLE_PATTERN = re.compile(r"\{([a-z_][a-z0-9_.]*)\}", re.IGNORECASE)
AUTORESPONDER_ACTION_PATTERN = re.compile(r"\{(delete|sendto:[^}]+|embed:[^}]+)\}", re.IGNORECASE)
CUSTOM_COMMAND_PATTERN = re.compile(r"^[a-z][a-z0-9_-]{0,31}$")
AUTORESPONDER_MATCH_MODES = ("contains", "exact", "startswith", "endswith")
GREETING_MESSAGE_COLUMNS = {
    "join": "join_message",
    "leave": "leave_message",
    "vanity": "vanity_message",
}
GREETING_CHANNEL_COLUMNS = {"join": "join_channel_id", "leave": "leave_channel_id"}
DEFAULT_BOOST_MESSAGE = "Thanks {user.mention} for boosting {server.name}! Boost #{boost_count}."
SUCCESS_TICK = "<:fp_tick:1556945922137661514>"
DETAIL_ARROW = "<:fp_arrow:1551870150204985354>"
try:
    COMMUNITY_EMOJI_MANIFEST = json.loads(
        (Path(__file__).resolve().parent / "emojis.json").read_text(encoding="utf-8")
    )
except (OSError, json.JSONDecodeError):
    COMMUNITY_EMOJI_MANIFEST = {}
SUCCESS_TICK = COMMUNITY_EMOJI_MANIFEST.get("fp_tick", SUCCESS_TICK)
DETAIL_ARROW = COMMUNITY_EMOJI_MANIFEST.get("fp_arrow", DETAIL_ARROW)
DEFAULT_EMBED_CONFIG = {
    "title": "{username}",
    "description": "",
    "color": "#FFDD00",
    "url": "",
    "timestamp": False,
    "thumbnail": "{avatar}",
    "image": "",
    "author": {"name": "", "url": "", "icon_url": ""},
    "footer": {"text": "", "icon_url": ""},
    "fields": [],
}


def _matches_autoresponder_trigger(content, trigger, mode, *, case_sensitive=False):
    if not case_sensitive:
        content = content.casefold()
        trigger = trigger.casefold()
    trigger = trigger.strip()
    if not trigger:
        return False
    if mode == "exact":
        return content.strip() == trigger
    if mode in {"contains", "includes"}:
        return trigger in content
    if mode in {"startswith", "starts_with", "starts"}:
        candidate = content.lstrip()
        return candidate.startswith(trigger) and (
            len(candidate) == len(trigger) or candidate[len(trigger)].isspace()
        )
    if mode in {"endswith", "ends_with", "ends"}:
        candidate = content.rstrip()
        start = len(candidate) - len(trigger)
        return start >= 0 and candidate.endswith(trigger) and (
            start == 0 or candidate[start - 1].isspace()
        )
    return False


def _autoresponder_arguments(content, trigger, mode, *, case_sensitive=False):
    if mode == "exact":
        return []
    search_content = content if case_sensitive else content.casefold()
    search_trigger = trigger if case_sensitive else trigger.casefold()
    if mode in {"startswith", "starts_with", "starts"}:
        remainder = content.lstrip()[len(trigger.strip()):]
    elif mode in {"endswith", "ends_with", "ends"}:
        remainder = content.rstrip()[:-len(trigger.strip())]
    else:
        match_at = search_content.find(search_trigger)
        if match_at < 0:
            return []
        remainder = f"{content[:match_at]} {content[match_at + len(trigger):]}"
    return remainder.split()


def render_member_event_card(
    avatar_bytes,
    username,
    guild_name,
    event_kind,
    detail,
    *,
    guild_icon_bytes=None,
):
    themes = {
        "boost": ((23, 20, 38), (54, 37, 79), "#B58CFF", "#F0D8FF"),
        "join": ((17, 30, 35), (27, 58, 60), "#6FE0C2", "#D5FFF3"),
        "leave": ((25, 28, 39), (47, 53, 69), "#B6C2D9", "#E8EDF7"),
    }
    start, end, accent, text_color = themes.get(event_kind, themes["join"])
    width, height = 1100, 360
    image = Image.new("RGB", (width, height), start)
    draw = ImageDraw.Draw(image)
    for line_y in range(height):
        blend = line_y / max(1, height - 1)
        color = tuple(int(start[index] + (end[index] - start[index]) * blend) for index in range(3))
        draw.line((0, line_y, width, line_y), fill=color)
    draw.rounded_rectangle(
        (18, 18, width - 18, height - 18),
        radius=26,
        fill="#191B29",
        outline=accent,
        width=2,
    )
    draw.ellipse((820, -240, 1230, 160), fill=end)
    draw.ellipse((885, 240, 1150, 505), fill=end)

    try:
        title_font = ImageFont.truetype("DejaVuSans-Bold.ttf", 37)
        name_font = ImageFont.truetype("DejaVuSans-Bold.ttf", 48)
        detail_font = ImageFont.truetype("DejaVuSans.ttf", 23)
        small_font = ImageFont.truetype("DejaVuSans.ttf", 16)
    except OSError:
        title_font = ImageFont.load_default()
        name_font = title_font
        detail_font = title_font
        small_font = title_font

    avatar = Image.open(io.BytesIO(avatar_bytes)).convert("RGBA")
    avatar = ImageOps.fit(avatar, (192, 192))
    avatar_mask = Image.new("L", (192, 192), 0)
    ImageDraw.Draw(avatar_mask).ellipse((0, 0, 191, 191), fill=255)
    image.paste(avatar, (74, 81), avatar_mask)
    draw.ellipse((66, 73, 274, 281), outline=accent, width=4)

    if guild_icon_bytes:
        try:
            server_icon = Image.open(io.BytesIO(guild_icon_bytes)).convert("RGBA")
            server_icon = ImageOps.fit(server_icon, (56, 56))
            server_mask = Image.new("L", (56, 56), 0)
            ImageDraw.Draw(server_mask).ellipse((0, 0, 55, 55), fill=255)
            image.paste(server_icon, (313, 43), server_mask)
        except (OSError, ValueError):
            pass

    headline = {
        "boost": "BOOSTER CARD",
        "join": "WELCOME TO THE SERVER",
        "leave": "WE'LL MISS YOU",
    }.get(event_kind, "FALCON COMMUNITY")
    draw.text((313, 112), headline, font=title_font, fill=accent)

    def draw_fitted(text, position, font, fill, max_width):
        safe_text = str(text or "").strip() or "Member"
        while safe_text and draw.textbbox((0, 0), safe_text, font=font)[2] > max_width:
            safe_text = safe_text[:-2].rstrip() + "…"
        draw.text(position, safe_text, font=font, fill=fill)

    draw_fitted(username, (313, 163), name_font, text_color, 690)
    draw_fitted(guild_name, (315, 229), detail_font, "#D0D7E5", 690)
    draw_fitted(detail, (315, 278), small_font, accent, 690)
    draw.rounded_rectangle((315, 319, 1015, 326), radius=4, fill="#34384A")
    draw.rounded_rectangle((315, 319, 485, 326), radius=4, fill=accent)

    output = io.BytesIO()
    image.save(output, format="PNG", optimize=True)
    return output.getvalue()


FUN_ACTIONS = {
    "slap": "gave a playful slap to",
    "hug": "hugged",
    "kiss": "sent a kiss to",
    "pat": "gave a head pat to",
    "punch": "challenged",
    "superpunch": "landed a cartoon super-punch on",
    "kick": "gave a playful kick to",
    "kill": "dramatically defeated",
    "yeet": "cartoonishly yeeted",
    "beat": "gave a playful bonk to",
    "highfive": "high-fived",
    "wave": "waved to",
    "dance": "danced with",
    "love": "sent love to",
    "cuddle": "cuddled",
    "bite": "playfully bit",
    "bonk": "bonked",
    "poke": "poked",
    "tickle": "tickled",
    "comfort": "comforted",
    "cheer": "cheered for",
    "roast": "gave a lighthearted roast to",
    "scare": "playfully scared",
    "cry": "cried with",
    "laugh": "laughed with",
    "smile": "shared a smile with",
    "blush": "blushed at",
    "facepalm": "facepalmed at",
    "shrug": "shrugged with",
    "think": "pondered with",
    "wink": "winked at",
    "dab": "did a dab with",
    "handhold": "held hands with",
    "noseboop": "booped on the nose",
    "sleep": "took a nap beside",
    "pillowfight": "had a pillow fight with",
    "marry": "pretended to marry",
    "divorce": "dramatically divorced",
    "propose": "made a playful proposal to",
    "cheekkiss": "gave a cheek kiss to",
    "foreheadkiss": "gave a forehead kiss to",
    "handkiss": "gave a hand kiss to",
    "carry": "gave a playful carry to",
    "bridalcarry": "swept up in a bridal carry",
    "clap": "clapped for",
    "salute": "saluted",
    "bow": "bowed to",
    "thumbsup": "gave a thumbs-up to",
    "celebrate": "celebrated with",
    "party": "partied with",
    "congratulate": "congratulated",
    "thank": "thanked",
    "welcome": "welcomed",
    "forgive": "forgave",
    "miss": "said they missed",
    "admire": "admired",
    "stare": "stared at",
    "glare": "playfully glared at",
    "pout": "pouted at",
    "surprised": "surprised",
    "confused": "confused",
    "angry": "got playfully angry at",
    "excited": "got excited with",
    "nervous": "got nervous around",
    "yawn": "yawned with",
    "sneeze": "sneezed near",
    "run": "ran with",
    "hide": "hid from",
    "chase": "playfully chased",
    "peek": "peeked at",
    "sing": "sang with",
    "eat": "shared a snack with",
    "firstnight": "shared a sweet newlywed moment with",
    "weddingnight": "shared a romantic wedding-night moment with",
    "date": "went on a cute date with",
    "slowdance": "shared a slow dance with",
    "flirt": "flirted with",
    "confess": "confessed their feelings to",
    "serenade": "serenaded",
    "backhug": "gave a warm back hug to",
    "fistbump": "shared a fist bump with",
    "handshake": "shook hands with",
    "cheerup": "tried to cheer up",
    "support": "showed support for",
    "motivate": "motivated",
    "encourage": "encouraged",
    "apologize": "apologized to",
    "sorry": "said sorry to",
    "gift": "gave a gift to",
    "share": "shared something with",
    "feed": "shared a bite with",
    "cook": "cooked a meal with",
    "study": "studied with",
    "read": "read a book with",
    "watch": "watched a show with",
    "travel": "went on an adventure with",
    "teamup": "teamed up with",
    "victory": "celebrated a victory with",
    "protect": "playfully protected",
    "rescue": "came to the rescue of",
    "snowball": "had a snowball fight with",
    "splash": "had a playful splash fight with",
}
FUN_GIF_SEARCH_FALLBACKS = {
    "superpunch": "punch", "kill": "punch", "beat": "bonk", "comfort": "hug",
    "cheer": "happy", "roast": "baka", "scare": "shocked", "noseboop": "poke",
    "dab": "happy", "bow": "salute", "celebrate": "happy", "party": "happy",
    "pillowfight": "lappillow", "marry": "happy", "divorce": "cry",
    "propose": "blowkiss", "cheekkiss": "blowkiss", "foreheadkiss": "kiss",
    "handkiss": "kiss", "love": "blowkiss", "bridalcarry": "carry", "congratulate": "happy",
    "thank": "happy", "welcome": "wave", "forgive": "hug", "miss": "cry",
    "admire": "smug", "glare": "angry", "surprised": "shocked", "excited": "happy",
    "nervous": "shocked", "sneeze": "yawn", "hide": "lurk", "chase": "run",
    "peek": "lurk", "sing": "happy", "eat": "nom", "firstnight": "cuddle",
    "weddingnight": "cuddle", "date": "dance", "slowdance": "dance",
    "flirt": "blowkiss", "confess": "blowkiss", "serenade": "happy",
    "backhug": "hug", "fistbump": "highfive", "cheerup": "hug", "support": "hug",
    "motivate": "happy", "encourage": "happy", "apologize": "salute", "sorry": "salute",
    "gift": "happy", "share": "feed", "cook": "feed", "study": "think",
    "read": "think", "watch": "happy", "travel": "run", "teamup": "highfive",
    "victory": "happy", "protect": "hug", "rescue": "hug", "snowball": "yeet",
    "splash": "dance",
}


def render_variables(value, member, guild, channel=None, bot_user=None, extra_values=None):
    owner = guild.get_member(guild.owner_id)
    joined_at = getattr(member, "joined_at", None)
    created_at = getattr(member, "created_at", None)
    channel_name = getattr(channel, "name", "")
    channel_id = str(getattr(channel, "id", ""))
    user_id = str(member.id)
    username = member.display_name
    avatar_url = member.display_avatar.url
    server_id = str(guild.id)
    member_count = str(guild.member_count or 0)
    owner_mention = owner.mention if owner else f"<@{guild.owner_id}>"
    bot_name = bot_user.name if bot_user else "Falcon"
    bot_id = str(getattr(bot_user, "id", ""))
    values = {
        "user": str(member),
        "username": username,
        "userid": user_id,
        "mention": member.mention,
        "server": guild.name,
        "guild": guild.name,
        "serverid": server_id,
        "guildid": server_id,
        "membercount": member_count,
        "member_count": member_count,
        "channel": channel_name,
        "channelid": channel_id,
        "owner": owner_mention,
        "ownerid": str(guild.owner_id),
        "created": f"<t:{int(created_at.timestamp())}:F>" if created_at else "Unknown",
        "joined": f"<t:{int(joined_at.timestamp())}:F>" if joined_at else "Unknown",
        "avatar": avatar_url,
        "boostcount": str(getattr(guild, "premium_subscription_count", 0) or 0),
        "boost_count": str(getattr(guild, "premium_subscription_count", 0) or 0),
        "boostlevel": str(getattr(guild, "premium_tier", 0) or 0),
        "boost_level": str(getattr(guild, "premium_tier", 0) or 0),
        "user_name": username,
        "user_id": user_id,
        "user_mention": member.mention,
        "user_avatar": avatar_url,
        "user_created": f"<t:{int(created_at.timestamp())}:F>" if created_at else "Unknown",
        "server_name": guild.name,
        "server_id": server_id,
        "server_icon": guild.icon.url if getattr(guild, "icon", None) else "",
        "server_owner": owner_mention,
        "channel_name": channel_name,
        "channel_id": channel_id,
        "message": "",
        "message_content": "",
        "date": utc_now().strftime("%Y-%m-%d"),
        "time": utc_now().strftime("%H:%M UTC"),
        "timestamp": str(int(utc_now().timestamp())),
        "newline": "\n",
        "user.name": getattr(member, "name", username),
        "user.display_name": username,
        "user.id": user_id,
        "user.mention": member.mention,
        "user.avatar": avatar_url,
        "user.avatar_url": avatar_url,
        "user.created_at": f"<t:{int(created_at.timestamp())}:F>" if created_at else "Unknown",
        "user.joined_at": f"<t:{int(joined_at.timestamp())}:F>" if joined_at else "Unknown",
        "server.name": guild.name,
        "server.id": server_id,
        "server.member_count": member_count,
        "server.owner": owner_mention,
        "server.owner_id": str(guild.owner_id),
        "server.boost_count": str(getattr(guild, "premium_subscription_count", 0) or 0),
        "server.boost_level": str(getattr(guild, "premium_tier", 0) or 0),
        "guild.name": guild.name,
        "guild.id": server_id,
        "guild.member_count": member_count,
        "channel.name": channel_name,
        "channel.id": channel_id,
        "channel.mention": getattr(channel, "mention", ""),
        "bot": bot_name,
        "bot.name": bot_name,
        "bot.id": bot_id,
    }
    if extra_values:
        values.update({key.lower(): str(value) for key, value in extra_values.items()})
    return VARIABLE_PATTERN.sub(lambda match: values.get(match.group(1).lower(), match.group(0)), value)


def _render_config_value(value, member, guild, channel, bot_user, extra_values=None):
    if isinstance(value, str):
        return render_variables(value, member, guild, channel, bot_user, extra_values)
    if isinstance(value, list):
        return [_render_config_value(item, member, guild, channel, bot_user, extra_values) for item in value]
    if isinstance(value, dict):
        return {key: _render_config_value(item, member, guild, channel, bot_user, extra_values) for key, item in value.items()}
    return value


def build_custom_embed(config, member, guild, channel, bot_user, extra_values=None):
    if not isinstance(config, dict):
        raise ValueError("Embed configuration must be a JSON object.")
    rendered = _render_config_value(config, member, guild, channel, bot_user, extra_values)
    color = rendered.get("color", "#FFDD00")
    if isinstance(color, str):
        color_names = {
            "red": "FF0000",
            "blue": "0000FF",
            "green": "00FF00",
            "yellow": "FFFF00",
            "gold": "FFDD00",
            "purple": "800080",
        }
        color_text = color.strip().casefold()
        color = int(color_names.get(color_text, color_text.lstrip("#")), 16)
    if not isinstance(color, int) or not 0 <= color <= 0xFFFFFF:
        raise ValueError("Color must be an RGB hex string such as #FFDD00 or an integer.")

    embed = discord.Embed(
        title=rendered.get("title") or None,
        description=rendered.get("description") or None,
        url=rendered.get("url") or None,
        color=color,
    )
    if rendered.get("timestamp"):
        timestamp_value = rendered["timestamp"]
        if timestamp_value is True:
            embed.timestamp = utc_now()
        else:
            try:
                embed.timestamp = datetime.datetime.fromisoformat(timestamp_value)
            except (TypeError, ValueError) as error:
                raise ValueError("Timestamp must be true or an ISO-8601 datetime.") from error

    author = rendered.get("author") or {}
    if author.get("name"):
        embed.set_author(
            name=author["name"],
            url=author.get("url") or None,
            icon_url=author.get("icon_url") or None,
        )
    footer = rendered.get("footer") or {}
    if footer.get("text"):
        embed.set_footer(text=footer["text"], icon_url=footer.get("icon_url") or None)
    if rendered.get("thumbnail"):
        _validate_embed_url(rendered["thumbnail"], "Thumbnail")
        embed.set_thumbnail(url=rendered["thumbnail"])
    if rendered.get("image"):
        _validate_embed_url(rendered["image"], "Image")
        embed.set_image(url=rendered["image"])

    fields = rendered.get("fields") or []
    if not isinstance(fields, list) or len(fields) > 25:
        raise ValueError("Fields must be a list with no more than 25 entries.")
    for field in fields:
        if not isinstance(field, dict) or not field.get("name") or "value" not in field:
            raise ValueError("Each field needs a non-empty name and a value.")
        if len(str(field["name"])) > 256 or len(str(field["value"])) > 1024:
            raise ValueError("Field names are limited to 256 characters and values to 1024 characters.")
        embed.add_field(name=str(field["name"]), value=str(field["value"]), inline=bool(field.get("inline", False)))
    if embed.title and len(embed.title) > 256:
        raise ValueError("Embed titles are limited to 256 characters.")
    if embed.description and len(embed.description) > 4096:
        raise ValueError("Embed descriptions are limited to 4096 characters.")
    if embed.footer.text and len(embed.footer.text) > 2048:
        raise ValueError("Embed footers are limited to 2048 characters.")
    if embed.author.name and len(embed.author.name) > 256:
        raise ValueError("Embed author names are limited to 256 characters.")
    if len(embed) > 6000:
        raise ValueError("The total embed text cannot exceed 6000 characters.")
    return embed


def _validate_embed_url(value, label):
    parsed = urlsplit(str(value))
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError(f"{label} URL must start with http:// or https://.")


def validate_embed_config(config_text):
    try:
        config = json.loads(config_text)
    except json.JSONDecodeError as error:
        raise ValueError(f"Invalid JSON at line {error.lineno}, column {error.colno}.") from error
    if not isinstance(config, dict):
        raise ValueError("Embed configuration must be a JSON object.")
    build_custom_embed(config, _SampleMember(), _SampleGuild(), None, None)
    return config


class _SampleAsset:
    url = "https://example.com/avatar.png"


class _SampleMember:
    id = 123456789012345678
    name = "Sample"
    display_name = "Sample"
    mention = "<@123456789012345678>"
    created_at = datetime.datetime(2020, 1, 1, tzinfo=datetime.timezone.utc)
    joined_at = created_at
    display_avatar = _SampleAsset()

    def __str__(self):
        return self.name


class _SampleGuild:
    id = 123456789012345678
    name = "Sample Guild"
    member_count = 1
    owner_id = 123456789012345678

    @staticmethod
    def get_member(_user_id):
        return _SampleMember()


class EmbedConfigModal(discord.ui.Modal):
    def __init__(self, cog, guild_id, name, config=None):
        super().__init__(title=f"Configure embed: {name[:35]}", timeout=300)
        self.cog = cog
        self.guild_id = guild_id
        self.embed_name = name
        initial = json.dumps(config or DEFAULT_EMBED_CONFIG, indent=2)
        self.configuration = discord.ui.TextInput(
            label="Embed configuration (JSON)",
            style=discord.TextStyle.paragraph,
            required=True,
            max_length=4000,
            default=initial[:4000],
        )
        self.add_item(self.configuration)

    async def on_submit(self, interaction):
        try:
            config = validate_embed_config(self.configuration.value)
        except ValueError as error:
            return await send_interaction_v2(interaction, str(error), ephemeral=True)
        await self.cog.save_embed(self.guild_id, self.embed_name, config, interaction.user.id)
        await send_interaction_v2(interaction, f"Embed `{self.embed_name}` saved.", ephemeral=True)


class EmbedValueModal(discord.ui.Modal):
    def __init__(self, title, field_name, current_value=None, *, description="", callback=None):
        super().__init__(title=title, timeout=300)
        self.field_name = field_name
        self.callback = callback
        current = "" if current_value is None else str(current_value)
        self.value_input = discord.ui.TextInput(
            label=field_name.replace("_", " ").title(),
            style=discord.TextStyle.short if len(current) < 120 else discord.TextStyle.paragraph,
            required=False,
            default=current[:4000],
            placeholder=description or "Enter value",
        )
        self.add_item(self.value_input)

    async def on_submit(self, interaction):
        value = self.value_input.value.strip()
        if self.callback is not None:
            await self.callback(interaction, value)


class AdvancedEmbedBuilderView(discord.ui.View):
    def __init__(self, cog, guild_id, name, config=None, owner_id=None, save_callback=None, extra_values=None):
        super().__init__(timeout=600)
        self.cog = cog
        self.guild_id = guild_id
        self.name = name
        self.owner_id = owner_id
        self.save_callback = save_callback
        self.extra_values = extra_values or {}
        self.message = None
        self.config = dict(json.loads(json.dumps(config or DEFAULT_EMBED_CONFIG)))
        if not isinstance(self.config.get("fields"), list):
            self.config["fields"] = []

    async def interaction_check(self, interaction):
        if interaction.user.id == self.owner_id:
            return True
        await send_interaction_v2(interaction, "This embed builder is not yours.", ephemeral=True, allow_ephemeral=True)
        return False

    async def _refresh_preview(self, interaction):
        try:
            embed = build_custom_embed(
                self.config,
                interaction.user,
                interaction.guild,
                interaction.channel,
                self.cog.bot.user,
                self.extra_values,
            )
        except ValueError as error:
            await send_interaction_v2(
                interaction,
                f"Preview error: {error}",
                ephemeral=True,
                allow_ephemeral=True,
            )
            return

        if interaction.message is not None:
            await edit_interaction_v2(interaction, embed=embed, view=self)
            return

        if self.message is None:
            return await send_interaction_v2(
                interaction,
                "The embed editor expired. Reopen it to continue.",
                ephemeral=True,
                allow_ephemeral=True,
            )
        await interaction.response.defer(ephemeral=True)
        await edit_message_v2(self.message, embed=embed, view=self)
        await interaction.delete_original_response()

    @discord.ui.button(label="Title", emoji="🏷️", style=discord.ButtonStyle.primary)
    async def set_title(self, interaction, button):
        async def set_value(interaction, value):
            self.config["title"] = value
            await self._refresh_preview(interaction)
        modal = EmbedValueModal("Edit Title", "title", self.config.get("title"), description="Use plain text or variables like {username}", callback=set_value)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Description", emoji="📝", style=discord.ButtonStyle.primary)
    async def set_description(self, interaction, button):
        async def set_value(interaction, value):
            self.config["description"] = value
            await self._refresh_preview(interaction)
        modal = EmbedValueModal("Edit Description", "description", self.config.get("description"), description="Use markdown or variables like {server}", callback=set_value)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Color", emoji="🎨", style=discord.ButtonStyle.secondary)
    async def set_color(self, interaction, button):
        async def set_value(interaction, value):
            self.config["color"] = value
            await self._refresh_preview(interaction)
        modal = EmbedValueModal("Edit Color", "color", self.config.get("color"), description="Hex like #FFDD00 or 0xFFDD00", callback=set_value)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Add Field", emoji="➕", style=discord.ButtonStyle.secondary)
    async def add_field(self, interaction, button):
        async def set_value(interaction, value):
            raw = value
            parts = [part.strip() for part in raw.split("|", 2)]
            if len(parts) < 2:
                return await send_interaction_v2(
                    interaction,
                    "Use: name | value | inline (optional)",
                    ephemeral=True,
                    allow_ephemeral=True,
                )
            field = {"name": parts[0], "value": parts[1], "inline": len(parts) > 2 and parts[2].lower() in {"true", "yes", "1"}}
            self.config.setdefault("fields", []).append(field)
            await self._refresh_preview(interaction)
        modal = EmbedValueModal("Add Field", "field", description="Format: name | value | inline", callback=set_value)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Thumbnail", emoji="🌄", style=discord.ButtonStyle.secondary)
    async def set_thumbnail(self, interaction, button):
        async def set_value(interaction, value):
            self.config["thumbnail"] = value
            await self._refresh_preview(interaction)
        modal = EmbedValueModal("Edit Thumbnail", "thumbnail", self.config.get("thumbnail"), description="URL only", callback=set_value)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Image", emoji="🖼️", style=discord.ButtonStyle.secondary)
    async def set_image(self, interaction, button):
        async def set_value(interaction, value):
            self.config["image"] = value
            await self._refresh_preview(interaction)
        modal = EmbedValueModal("Edit Image", "image", self.config.get("image"), description="URL only", callback=set_value)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Footer", emoji="🔻", style=discord.ButtonStyle.secondary)
    async def set_footer(self, interaction, button):
        async def set_value(interaction, value):
            footer = dict(self.config.get("footer") or {})
            footer["text"] = value
            self.config["footer"] = footer
            await self._refresh_preview(interaction)
        modal = EmbedValueModal("Edit Footer", "footer", self.config.get("footer", {}).get("text"), description="Footer text", callback=set_value)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Author", emoji="👤", style=discord.ButtonStyle.secondary)
    async def set_author(self, interaction, button):
        async def set_value(interaction, value):
            author = dict(self.config.get("author") or {})
            author["name"] = value
            self.config["author"] = author
            await self._refresh_preview(interaction)
        modal = EmbedValueModal("Edit Author", "author", self.config.get("author", {}).get("name"), description="Author name", callback=set_value)
        await interaction.response.send_modal(modal)

    @discord.ui.button(label="Timestamp", emoji="🕒", style=discord.ButtonStyle.secondary)
    async def toggle_timestamp(self, interaction, button):
        self.config["timestamp"] = not bool(self.config.get("timestamp"))
        await self._refresh_preview(interaction)

    @discord.ui.button(label="Preview", emoji="👁️", style=discord.ButtonStyle.success)
    async def preview(self, interaction, button):
        await self._refresh_preview(interaction)

    @discord.ui.button(label="Save", emoji="💾", style=discord.ButtonStyle.primary)
    async def save(self, interaction, button):
        try:
            validate_embed_config(json.dumps(self.config))
            if self.save_callback is not None:
                await self.save_callback(self.config)
            else:
                await self.cog.save_embed(self.guild_id, self.name, self.config, self.owner_id)
        except ValueError as error:
            return await send_interaction_v2(interaction, str(error), ephemeral=True, allow_ephemeral=True)
        await self._refresh_preview(interaction)
        self.stop()


class GreetingConfigModal(discord.ui.Modal):
    def __init__(self, cog, guild_id, greeting_type):
        super().__init__(title=f"Configure {greeting_type} greeting", timeout=300)
        self.cog = cog
        self.guild_id = guild_id
        self.greeting_type = greeting_type
        initial = json.dumps(DEFAULT_EMBED_CONFIG, indent=2)
        self.configuration = discord.ui.TextInput(
            label="Greeting embed configuration (JSON)",
            style=discord.TextStyle.paragraph,
            required=True,
            max_length=4000,
            default=initial[:4000],
        )
        self.add_item(self.configuration)

    async def on_submit(self, interaction):
        try:
            config = validate_embed_config(self.configuration.value)
        except ValueError as error:
            return await send_interaction_v2(interaction, str(error), ephemeral=True)
        await self.cog.save_greeting(self.guild_id, self.greeting_type, config, interaction.user.id)
        await send_interaction_v2(interaction, f"{self.greeting_type.title()} greeting saved.", ephemeral=True)


class GreetingConfigView(discord.ui.View):
    def __init__(self, cog, guild_id, owner_id):
        super().__init__(timeout=180)
        self.cog = cog
        self.guild_id = guild_id
        self.owner_id = owner_id

    async def interaction_check(self, interaction):
        if interaction.user.id == self.owner_id:
            return True
        await send_interaction_v2(interaction, "Only the administrator who opened this setup can use it.", ephemeral=True)
        return False

    @discord.ui.button(label="Edit Join Embed", style=discord.ButtonStyle.primary)
    async def edit_join(self, interaction, _button):
        await self.cog.open_greeting_embed_editor(interaction, "join")

    @discord.ui.button(label="Edit Leave Embed", style=discord.ButtonStyle.primary)
    async def edit_leave(self, interaction, _button):
        await self.cog.open_greeting_embed_editor(interaction, "leave")


class TagDurationModal(discord.ui.Modal):
    def __init__(self, cog, setup_view, setup_message):
        super().__init__(title="Set Tag Delete Duration", timeout=300)
        self.cog = cog
        self.setup_view = setup_view
        self.setup_message = setup_message
        self.duration_input = discord.ui.TextInput(
            label="Duration (e.g. 30s, 5min, 1h)",
            placeholder="30s",
            required=True,
            max_length=80,
        )
        self.add_item(self.duration_input)

    async def on_submit(self, interaction):
        try:
            duration = parse_duration(self.duration_input.value)
        except (OverflowError, ValueError) as error:
            return await interaction.response.send_message(str(error), ephemeral=False)
        if duration is None:
            return await interaction.response.send_message(
                "Tag pings need an auto-delete duration; permanent is not supported.",
                ephemeral=False,
            )

        seconds = int(duration.total_seconds())
        await self.cog.bot.db.execute(
            "INSERT INTO tag_settings (guild_id, delete_after_seconds) VALUES (?, ?) "
            "ON CONFLICT(guild_id) DO UPDATE SET delete_after_seconds=excluded.delete_after_seconds",
            (self.setup_view.guild_id, seconds),
        )
        await self.cog.bot.db.commit()
        await interaction.response.defer(ephemeral=False)
        try:
            embed = await self.cog._build_tag_setup_embed(interaction.guild)
            await edit_message_v2(self.setup_message, embed=embed, view=self.setup_view)
        except discord.HTTPException:
            pass
        await interaction.followup.send("Tag delete duration updated.", ephemeral=False)


class TagSetupView(discord.ui.View):
    def __init__(self, cog, guild_id, owner_id):
        super().__init__(timeout=600)
        self.cog = cog
        self.guild_id = guild_id
        self.owner_id = owner_id

    async def interaction_check(self, interaction):
        if interaction.user.id == self.owner_id:
            return True
        await interaction.response.send_message("Only the admin who opened this setup can change it.", ephemeral=False)
        return False

    @discord.ui.select(
        cls=discord.ui.ChannelSelect,
        channel_types=[discord.ChannelType.text, discord.ChannelType.news],
        placeholder="Add one or more tag channels",
        min_values=1,
        max_values=25,
    )
    async def add_channels(self, interaction, select):
        for channel in select.values:
            await self.cog.bot.db.execute(
                "INSERT OR IGNORE INTO tag_channels (guild_id, channel_id) VALUES (?, ?)",
                (self.guild_id, channel.id),
            )
        await self.cog.bot.db.execute(
            "INSERT OR IGNORE INTO tag_settings (guild_id, delete_after_seconds) VALUES (?, NULL)",
            (self.guild_id,),
        )
        await self.cog.bot.db.commit()
        embed = await self.cog._build_tag_setup_embed(interaction.guild)
        await edit_interaction_v2(interaction, embed=embed, view=self)

    @discord.ui.button(label="Set Delete Duration", style=discord.ButtonStyle.primary)
    async def set_duration(self, interaction, _button):
        await interaction.response.send_modal(TagDurationModal(self.cog, self, interaction.message))


class DestructiveConfirmationView(discord.ui.View):
    def __init__(self, user_id, action, success_message):
        super().__init__(timeout=60)
        self.user_id = user_id
        self.action = action
        self.success_message = success_message

    async def interaction_check(self, interaction):
        if interaction.user.id == self.user_id:
            return True
        await send_interaction_v2(interaction, "This confirmation is not yours.", ephemeral=True)
        return False

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction, _button):
        await self.action()
        await edit_interaction_v2(interaction, content=self.success_message, view=None)
        self.stop()

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction, _button):
        await edit_interaction_v2(interaction, content="Action cancelled.", view=None)
        self.stop()


class CommunityFeatures(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._fun_gif_cache = {}
        self._fun_gif_indexes = {}
        self._fun_gif_retry_after = 0.0
        self._response_cooldowns = {}
        self._cooldown_checks = 0

    async def _confirm_destructive_action(self, ctx, prompt, success_message, action):
        view = DestructiveConfirmationView(ctx.author.id, action, success_message)
        if ctx.interaction is not None:
            await send_interaction_v2(ctx.interaction, prompt, view=view, ephemeral=True)
        else:
            await ctx.send(prompt, view=view)

    async def cog_load(self):
        await self.bot.db.execute(
            "CREATE TABLE IF NOT EXISTS role_mappings ("
            "guild_id INTEGER NOT NULL, alias TEXT NOT NULL, role_id INTEGER NOT NULL, "
            "created_by INTEGER NOT NULL, created_at TEXT NOT NULL, PRIMARY KEY(guild_id, alias))"
        )
        await self.bot.db.execute(
            "CREATE TABLE IF NOT EXISTS custom_embeds ("
            "guild_id INTEGER NOT NULL, name TEXT NOT NULL, config TEXT NOT NULL, "
            "created_by INTEGER NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY(guild_id, name))"
        )
        await self.bot.db.execute(
            "CREATE TABLE IF NOT EXISTS greeting_settings ("
            "guild_id INTEGER PRIMARY KEY, channel_id INTEGER NOT NULL, join_config TEXT, "
            "leave_config TEXT, join_enabled INTEGER NOT NULL DEFAULT 1, leave_enabled INTEGER NOT NULL DEFAULT 1, "
            "updated_by INTEGER NOT NULL, updated_at TEXT NOT NULL)"
        )
        async with self.bot.db.execute("PRAGMA table_info(greeting_settings)") as cursor:
            greeting_columns = {row[1] for row in await cursor.fetchall()}
        for column, default in (
            ("join_enabled", 1),
            ("leave_enabled", 1),
            ("join_card_enabled", 0),
            ("leave_card_enabled", 0),
        ):
            if column not in greeting_columns:
                await self.bot.db.execute(
                    f"ALTER TABLE greeting_settings ADD COLUMN {column} INTEGER NOT NULL DEFAULT {default}"
                )
        await self.bot.db.execute(
            "CREATE TABLE IF NOT EXISTS autoresponders ("
            "guild_id INTEGER NOT NULL, trigger TEXT NOT NULL, response TEXT NOT NULL, "
            "updated_by INTEGER NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY(guild_id, trigger))"
        )
        async with self.bot.db.execute("PRAGMA table_info(autoresponders)") as cursor:
            autoresponder_columns = {row[1] for row in await cursor.fetchall()}
        for column, definition in (
            ("mode", "TEXT NOT NULL DEFAULT 'contains'"),
            ("channel_id", "INTEGER"),
            ("role_id", "INTEGER"),
            ("cooldown", "INTEGER NOT NULL DEFAULT 0"),
            ("enabled", "INTEGER NOT NULL DEFAULT 1"),
            ("excluded_channel_ids", "TEXT NOT NULL DEFAULT '[]'"),
            ("allowed_role_ids", "TEXT NOT NULL DEFAULT '[]'"),
            ("excluded_role_ids", "TEXT NOT NULL DEFAULT '[]'"),
            ("cooldown_scope", "TEXT NOT NULL DEFAULT 'user'"),
            ("case_sensitive", "INTEGER NOT NULL DEFAULT 0"),
        ):
            if column not in autoresponder_columns:
                await self.bot.db.execute(f"ALTER TABLE autoresponders ADD COLUMN {column} {definition}")
        await self.bot.db.execute(
            "CREATE TABLE IF NOT EXISTS custom_commands ("
            "guild_id INTEGER NOT NULL, name TEXT NOT NULL, response TEXT NOT NULL, "
            "role_id INTEGER, channel_id INTEGER, cooldown INTEGER NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 1, "
            "updated_by INTEGER NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY(guild_id, name))"
        )
        async with self.bot.db.execute("PRAGMA table_info(custom_commands)") as cursor:
            custom_command_columns = {row[1] for row in await cursor.fetchall()}
        if "enabled" not in custom_command_columns:
            await self.bot.db.execute(
                "ALTER TABLE custom_commands ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1"
            )
        await self.bot.db.execute(
            "CREATE TABLE IF NOT EXISTS boost_settings ("
            "guild_id INTEGER PRIMARY KEY, channel_id INTEGER NOT NULL, message TEXT NOT NULL, "
            "enabled INTEGER NOT NULL DEFAULT 1, card_enabled INTEGER NOT NULL DEFAULT 0, "
            "updated_by INTEGER NOT NULL, updated_at TEXT NOT NULL)"
        )
        async with self.bot.db.execute("PRAGMA table_info(boost_settings)") as cursor:
            boost_columns = {row[1] for row in await cursor.fetchall()}
        if "enabled" not in boost_columns:
            await self.bot.db.execute(
                "ALTER TABLE boost_settings ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1"
            )
        if "embed_name" not in boost_columns:
            await self.bot.db.execute(
                "ALTER TABLE boost_settings ADD COLUMN embed_name TEXT"
            )
        if "card_enabled" not in boost_columns:
            await self.bot.db.execute(
                "ALTER TABLE boost_settings ADD COLUMN card_enabled INTEGER NOT NULL DEFAULT 0"
            )
        await self.bot.db.execute(
            "CREATE TABLE IF NOT EXISTS tag_settings ("
            "guild_id INTEGER PRIMARY KEY, delete_after_seconds INTEGER, "
            "enabled INTEGER NOT NULL DEFAULT 1)"
        )
        async with self.bot.db.execute("PRAGMA table_info(tag_settings)") as cursor:
            tag_columns = {row[1] for row in await cursor.fetchall()}
        if "enabled" not in tag_columns:
            await self.bot.db.execute(
                "ALTER TABLE tag_settings ADD COLUMN enabled INTEGER NOT NULL DEFAULT 1"
            )
        await self.bot.db.execute(
            "CREATE TABLE IF NOT EXISTS tag_channels ("
            "guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL, "
            "PRIMARY KEY(guild_id, channel_id))"
        )
        await self.bot.db.commit()
        await self._register_role_aliases()

    async def _register_role_aliases(self):
        async with self.bot.db.execute("SELECT DISTINCT alias FROM role_mappings") as cursor:
            aliases = [row[0] for row in await cursor.fetchall()]
        for alias in aliases:
            self._add_role_command(alias)

    def _add_role_command(self, alias):
        if self.bot.get_command(alias):
            return

        async def callback(ctx, member: discord.Member = None):
            await self.toggle_member_role(ctx, alias, member)

        command = commands.hybrid_command(name=alias, description=f"Toggle the configured {alias} role")(callback)
        self.bot.add_command(command)

    async def _check_role_hierarchy(self, ctx, role, *, check_actor=True):
        guild = ctx.guild
        bot_member = guild.me
        if bot_member is None or not bot_member.guild_permissions.manage_roles:
            raise PermissionError("I need the Manage Roles permission to change roles.")
        if role.is_default():
            raise PermissionError("The @everyone role cannot be assigned or removed.")
        if role >= bot_member.top_role:
            raise PermissionError("That role must be below my highest role.")
        if check_actor and not ctx.author.guild_permissions.administrator and ctx.author.top_role <= role:
            raise PermissionError("That role must be below your highest role.")

    async def _resolve_member_from_context(self, ctx, member=None, query=None):
        if member is not None:
            return member
        if getattr(ctx, "message", None) is not None:
            if ctx.message.mentions:
                return ctx.message.mentions[0]
            ref = ctx.message.reference
            if ref:
                resolved = ref.resolved
                if isinstance(resolved, discord.Member):
                    return resolved
                if isinstance(resolved, discord.Message):
                    if isinstance(resolved.author, discord.Member):
                        return resolved.author
                    for mention in resolved.mentions:
                        if isinstance(mention, discord.Member):
                            return mention
                if ref.message_id:
                    try:
                        replied_message = await ctx.channel.fetch_message(ref.message_id)
                        if isinstance(replied_message.author, discord.Member):
                            return replied_message.author
                    except (discord.Forbidden, discord.HTTPException):
                        pass
        query_text = str(query or "").strip()
        if query_text and ctx.guild is not None:
            id_match = re.fullmatch(r"<@!?(\d+)>|\d+", query_text)
            if id_match:
                user_id = int(id_match.group(1) or query_text)
                resolved = ctx.guild.get_member(user_id)
                if resolved is None:
                    try:
                        resolved = await ctx.guild.fetch_member(user_id)
                    except (discord.NotFound, discord.Forbidden, discord.HTTPException):
                        return None
                return resolved
            return ctx.guild.get_member_named(query_text)
        return None

    async def toggle_member_role(self, ctx, alias, member):
        member = await self._resolve_member_from_context(ctx, member)
        if member is None:
            return await ctx.send(f"Please mention a user or reply to a message to use `{alias}`.", ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "SELECT role_id FROM role_mappings WHERE guild_id=? AND alias=?",
            (ctx.guild.id, alias),
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return await ctx.send(f"No role is configured for `{alias}`.", ephemeral=ctx.interaction is not None)
        role = ctx.guild.get_role(row[0])
        if role is None:
            return await ctx.send("The configured role no longer exists. Reconfigure it with `/role create`.", ephemeral=ctx.interaction is not None)
        try:
            if member.id != ctx.author.id and not ctx.author.guild_permissions.manage_roles:
                raise PermissionError("You can only toggle this role for yourself.")
            await self._check_role_hierarchy(ctx, role, check_actor=member.id != ctx.author.id)
            if member.id != ctx.author.id and not ctx.author.guild_permissions.administrator and member.top_role >= ctx.author.top_role:
                raise PermissionError("You cannot modify a member with an equal or higher role.")
            if role in member.roles:
                await member.remove_roles(role, reason=f"{alias} role toggle by {ctx.author}")
                title = "Role Removed"
            else:
                await member.add_roles(role, reason=f"{alias} role toggle by {ctx.author}")
                title = "Role Added"
        except PermissionError as error:
            return await ctx.send(str(error), ephemeral=ctx.interaction is not None)
        except discord.Forbidden:
            return await ctx.send("Discord denied that role change. Check role hierarchy and permissions.", ephemeral=ctx.interaction is not None)
        except discord.HTTPException:
            return await ctx.send("Discord could not complete that role change. Try again shortly.", ephemeral=ctx.interaction is not None)

        action = "added to" if title == "Role Added" else "removed from"
        await ctx.send(
            f"{SUCCESS_TICK} **{title}**\n\n"
            f"{DETAIL_ARROW} {role.mention} {action} {member.mention}.",
            ephemeral=ctx.interaction is not None,
        )

    @commands.hybrid_group(name="role", invoke_without_command=True, case_insensitive=True)
    async def role_group(self, ctx):
        await ctx.send(
            "Use `,role add @member @role`, `,role remove @member @role`, "
            "`,role all bot|humans @role`, `,role create <name>`, or `,role list`. "
            "Configure role aliases with `,setup create <alias> @role`.",
            ephemeral=ctx.interaction is not None,
        )

    @role_group.command(name="create", description="Create a server role")
    @commands.has_guild_permissions(manage_roles=True)
    async def role_create(self, ctx, *, name: str):
        role_name = name.strip()
        if not role_name or len(role_name) > 100:
            return await ctx.send("Role names must contain between 1 and 100 characters.", ephemeral=ctx.interaction is not None)
        try:
            role = await ctx.guild.create_role(
                name=role_name,
                permissions=discord.Permissions.none(),
                reason=f"Role created by {ctx.author}",
            )
        except discord.Forbidden:
            return await ctx.send("Discord denied role creation. Check Manage Roles and the bot's role hierarchy.", ephemeral=ctx.interaction is not None)
        except discord.HTTPException:
            return await ctx.send("Discord could not create that role. Try again shortly.", ephemeral=ctx.interaction is not None)
        await ctx.send(
            f"{SUCCESS_TICK} Created role {role.mention} with no permissions.",
            ephemeral=ctx.interaction is not None,
        )

    async def _configure_role_alias(self, ctx, name, role):
        alias = name.strip().lower()
        if not ALIAS_PATTERN.fullmatch(alias):
            return await ctx.send("Use a short alias beginning with a letter; letters, digits, `_` and `-` are allowed.", ephemeral=ctx.interaction is not None)
        existing = self.bot.get_command(alias)
        if existing and existing.name != alias:
            return await ctx.send("That alias conflicts with an existing command.", ephemeral=ctx.interaction is not None)
        if existing and not await self._alias_is_configured(ctx.guild.id, alias):
            return await ctx.send("That alias is already used by another command.", ephemeral=ctx.interaction is not None)
        try:
            await self._check_role_hierarchy(ctx, role)
        except PermissionError as error:
            return await ctx.send(str(error), ephemeral=ctx.interaction is not None)
        await self.bot.db.execute(
            "INSERT INTO role_mappings (guild_id, alias, role_id, created_by, created_at) "
            "VALUES (?, ?, ?, ?, ?) ON CONFLICT(guild_id, alias) DO UPDATE SET "
            "role_id=excluded.role_id, created_by=excluded.created_by, created_at=excluded.created_at",
            (ctx.guild.id, alias, role.id, ctx.author.id, utc_now().isoformat()),
        )
        await self.bot.db.commit()
        self._add_role_command(alias)
        success = discord.Embed(
            title=f"{SUCCESS_TICK} Role Setup Successful",
            description=f"`{alias} @user` now toggles {role.mention}.",
            color=0xFFDD00,
        )
        success.add_field(name="Alias", value=f"`{alias}`", inline=True)
        success.add_field(name="Role", value=f"{role.mention}", inline=True)
        success.add_field(name="Command", value=f"`{alias} @user`", inline=False)
        await ctx.send(embed=success, ephemeral=ctx.interaction is not None)

    async def _alias_is_configured(self, guild_id, alias):
        async with self.bot.db.execute(
            "SELECT 1 FROM role_mappings WHERE guild_id=? AND alias=?", (guild_id, alias)
        ) as cursor:
            return await cursor.fetchone() is not None

    @role_group.command(name="setup", description="Show role alias setup usage")
    @commands.has_guild_permissions(manage_roles=True)
    async def role_setup(self, ctx):
        embed = discord.Embed(
            title="Role Alias Setup",
            description="Create aliases with `,setup create <name> <role>`, then run `name @user` to toggle that role. Use `,setup list` to view configured roles.",
            color=0xFFDD00,
        )
        await ctx.send(embed=embed, ephemeral=ctx.interaction is not None)

    @role_group.command(name="list", description="List this server's role aliases")
    async def role_list(self, ctx):
        await self._send_role_list(ctx)

    async def _change_member_role(self, ctx, member, role, *, add):
        try:
            await self._check_role_hierarchy(ctx, role)
            if member.id != ctx.author.id and not ctx.author.guild_permissions.administrator and member.top_role >= ctx.author.top_role:
                raise PermissionError("You cannot modify a member with an equal or higher role.")
            if add:
                if role in member.roles:
                    return await ctx.send(f"{DETAIL_ARROW} {member.mention} already has {role.mention}.", ephemeral=ctx.interaction is not None)
                await member.add_roles(role, reason=f"Role added by {ctx.author}")
                title, action = "Role Added", "added to"
            else:
                if role not in member.roles:
                    return await ctx.send(f"{DETAIL_ARROW} {member.mention} does not have {role.mention}.", ephemeral=ctx.interaction is not None)
                await member.remove_roles(role, reason=f"Role removed by {ctx.author}")
                title, action = "Role Removed", "removed from"
        except PermissionError as error:
            return await ctx.send(f"{DETAIL_ARROW} {error}", ephemeral=ctx.interaction is not None)
        except discord.Forbidden:
            return await ctx.send(f"{DETAIL_ARROW} Discord denied that role change. Check role hierarchy and permissions.", ephemeral=ctx.interaction is not None)
        except discord.HTTPException:
            return await ctx.send(f"{DETAIL_ARROW} Discord could not complete that role change. Try again shortly.", ephemeral=ctx.interaction is not None)
        await ctx.send(
            f"{SUCCESS_TICK} **{title}**\n\n{DETAIL_ARROW} {role.mention} {action} {member.mention}.",
            ephemeral=ctx.interaction is not None,
        )

    async def _bulk_assign_role(self, ctx, role, *, bots=None):
        try:
            await self._check_role_hierarchy(ctx, role)
            if not ctx.guild.chunked:
                await ctx.guild.chunk(cache=True)
        except PermissionError as error:
            return await ctx.send(f"{DETAIL_ARROW} {error}", ephemeral=ctx.interaction is not None)
        except discord.HTTPException as error:
            return await ctx.send(f"{DETAIL_ARROW} Could not load the server member list: {error}", ephemeral=ctx.interaction is not None)

        targets = [
            member for member in ctx.guild.members
            if role not in member.roles and (bots is None or member.bot is bots)
        ]
        status = await ctx.send(f"{DETAIL_ARROW} Assigning {role.mention} to **{len(targets)}** member(s)...", ephemeral=ctx.interaction is not None)
        added = failed = 0
        for index, member in enumerate(targets, start=1):
            try:
                await member.add_roles(role, reason=f"Bulk role assignment by {ctx.author}")
                added += 1
            except (discord.Forbidden, discord.HTTPException):
                failed += 1
            if index % 25 == 0:
                await asyncio.sleep(0)
        await status.edit(
            content=(
                f"{SUCCESS_TICK} **Role Assignment Complete**\n\n"
                f"{DETAIL_ARROW} Added {role.mention} to **{added}** member(s); **{failed}** failed."
            )
        )

    @role_group.command(name="add", description="Add a role to a member")
    @commands.has_guild_permissions(manage_roles=True)
    async def role_add(self, ctx, member: discord.Member, role: discord.Role):
        await self._change_member_role(ctx, member, role, add=True)

    @role_group.command(name="remove", description="Remove a role from a member")
    @commands.has_guild_permissions(manage_roles=True)
    async def role_remove(self, ctx, member: discord.Member, role: discord.Role):
        await self._change_member_role(ctx, member, role, add=False)

    @role_group.group(name="all", invoke_without_command=True, case_insensitive=True)
    @commands.has_guild_permissions(manage_roles=True)
    async def role_all(self, ctx):
        await ctx.send(f"{DETAIL_ARROW} Choose `bot` or `humans`, then mention a role.", ephemeral=ctx.interaction is not None)

    @role_all.command(name="bot", aliases=["bots"], description="Assign a role to all bots")
    async def role_all_bots(self, ctx, role: discord.Role):
        await self._bulk_assign_role(ctx, role, bots=True)

    @role_all.command(name="humans", aliases=["human"], description="Assign a role to all humans")
    async def role_all_humans(self, ctx, role: discord.Role):
        await self._bulk_assign_role(ctx, role, bots=False)

    @commands.hybrid_command(name="roleall", description="Assign a role to everyone in this server")
    @commands.has_guild_permissions(manage_roles=True)
    async def roleall(self, ctx, role: discord.Role):
        await self._bulk_assign_role(ctx, role)

    async def _send_role_list(self, ctx):
        async with self.bot.db.execute(
            "SELECT alias, role_id FROM role_mappings WHERE guild_id=? ORDER BY alias",
            (ctx.guild.id,),
        ) as cursor:
            rows = await cursor.fetchall()
        if not rows:
            return await ctx.send("No role aliases are configured.", ephemeral=ctx.interaction is not None)
        pages = [rows[index:index + 10] for index in range(0, len(rows), 10)]
        page = [0]
        view = self._role_list_view(ctx, pages, page) if len(pages) > 1 else None
        await ctx.send(embed=self._role_list_embed(ctx.guild, pages[0], page[0], len(pages)), view=view)

    @commands.hybrid_group(name="setup", invoke_without_command=True, case_insensitive=True)
    async def setup_group(self, ctx):
        await ctx.send("Use `/setup role` to configure a role alias or `/setup list` to view configured roles.", ephemeral=ctx.interaction is not None)

    @setup_group.command(name="role", description="Configure a role alias command")
    @commands.has_guild_permissions(manage_roles=True)
    async def setup_role(self, ctx, name: str, role: discord.Role):
        await self._configure_role_alias(ctx, name, role)

    @setup_group.command(name="create", description="Configure a role alias command")
    @commands.has_guild_permissions(manage_roles=True)
    async def setup_create(self, ctx, name: str, role: discord.Role):
        await self._configure_role_alias(ctx, name, role)

    @setup_group.command(name="list", description="List all configured role aliases")
    async def setup_list(self, ctx):
        await self._send_role_list(ctx)

    def _role_list_embed(self, guild, rows, page, total_pages):
        lines = []
        for alias, role_id in rows:
            role = guild.get_role(role_id)
            lines.append(f"`{alias} @user` → {role.mention if role else f'Unavailable role ({role_id})'}")
        embed = discord.Embed(title="Configured Role Aliases", description="\n".join(lines), color=0xFFDD00)
        embed.set_footer(text=f"Page {page + 1}/{total_pages}")
        return embed

    def _role_list_view(self, ctx, pages, page):
        cog = self

        class RolePages(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=120)
                self.previous.disabled = True
                self.next.disabled = len(pages) < 2

            async def interaction_check(self, interaction):
                if interaction.user.id == ctx.author.id:
                    return True
                await send_interaction_v2(interaction, "This list is not yours.", ephemeral=True)
                return False

            @discord.ui.button(label="Previous", style=discord.ButtonStyle.secondary)
            async def previous(self, interaction, _button):
                page[0] = max(page[0] - 1, 0)
                self.previous.disabled = page[0] == 0
                self.next.disabled = page[0] == len(pages) - 1
                await edit_interaction_v2(interaction, embed=cog._role_list_embed(ctx.guild, pages[page[0]], page[0], len(pages)), view=self)

            @discord.ui.button(label="Next", style=discord.ButtonStyle.secondary)
            async def next(self, interaction, _button):
                page[0] = min(page[0] + 1, len(pages) - 1)
                self.previous.disabled = page[0] == 0
                self.next.disabled = page[0] == len(pages) - 1
                await edit_interaction_v2(interaction, embed=cog._role_list_embed(ctx.guild, pages[page[0]], page[0], len(pages)), view=self)

        return RolePages()

    async def _send_paged_list(self, ctx, title, lines, *, page_size=10):
        pages = [lines[index:index + page_size] for index in range(0, len(lines), page_size)]
        current_page = [0]

        def page_embed(index):
            embed = discord.Embed(
                title=title,
                description="\n".join(pages[index]),
                color=0xFFDD00,
            )
            embed.set_footer(text=f"Page {index + 1}/{len(pages)}")
            return embed

        class ListPages(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=120)
                self.previous.disabled = True
                self.next.disabled = len(pages) < 2

            async def interaction_check(self, interaction):
                if interaction.user.id == ctx.author.id:
                    return True
                await send_interaction_v2(interaction, "This list is not yours.", ephemeral=True)
                return False

            @discord.ui.button(label="Previous", style=discord.ButtonStyle.secondary)
            async def previous(self, interaction, _button):
                current_page[0] = max(current_page[0] - 1, 0)
                self.previous.disabled = current_page[0] == 0
                self.next.disabled = current_page[0] == len(pages) - 1
                await edit_interaction_v2(interaction, embed=page_embed(current_page[0]), view=self)

            @discord.ui.button(label="Next", style=discord.ButtonStyle.secondary)
            async def next(self, interaction, _button):
                current_page[0] = min(current_page[0] + 1, len(pages) - 1)
                self.previous.disabled = current_page[0] == 0
                self.next.disabled = current_page[0] == len(pages) - 1
                await edit_interaction_v2(interaction, embed=page_embed(current_page[0]), view=self)

            @discord.ui.button(label="Close", style=discord.ButtonStyle.danger)
            async def close(self, interaction, _button):
                await edit_interaction_v2(interaction, content="List closed.", embed=None, view=None)
                self.stop()

        await ctx.send(
            embed=page_embed(0),
            view=ListPages(),
            ephemeral=ctx.interaction is not None,
        )

    @commands.hybrid_group(name="embed", invoke_without_command=True, case_insensitive=True)
    async def embed_group(self, ctx):
        await ctx.send(
            "Use `/embed create`, `/embed import`, `/embed show`, `/embed list`, "
            "`/embed edit`, or `/embed delete`.",
            ephemeral=ctx.interaction is not None,
        )

    async def save_embed(self, guild_id, name, config, user_id):
        serialized = json.dumps(config, separators=(",", ":"))
        await self.bot.db.execute(
            "INSERT INTO custom_embeds (guild_id, name, config, created_by, updated_at) "
            "VALUES (?, ?, ?, ?, ?) ON CONFLICT(guild_id, name) DO UPDATE SET "
            "config=excluded.config, updated_at=excluded.updated_at",
            (guild_id, name.lower(), serialized, user_id, utc_now().isoformat()),
        )
        await self.bot.db.commit()

    async def _open_embed_modal(self, ctx, name, config=None):
        if ctx.interaction is None:
            return await ctx.send("Open this command as a slash command to use the embed editor, or pass a JSON config.")
        await self._open_embed_editor(
            ctx.interaction,
            name,
            config,
            owner_id=ctx.author.id,
        )

    async def _open_embed_editor(
        self,
        interaction,
        name,
        config=None,
        *,
        owner_id,
        save_callback=None,
        extra_values=None,
    ):
        builder = AdvancedEmbedBuilderView(
            self,
            interaction.guild.id,
            name,
            config,
            owner_id=owner_id,
            save_callback=save_callback,
            extra_values=extra_values,
        )
        preview = build_custom_embed(
            config or DEFAULT_EMBED_CONFIG,
            interaction.user,
            interaction.guild,
            interaction.channel,
            self.bot.user,
            extra_values,
        )
        await send_interaction_v2(
            interaction,
            embed=preview,
            view=builder,
            ephemeral=True,
            allow_ephemeral=True,
        )
        builder.message = getattr(getattr(builder, "_v2_layout", None), "_v2_message", None)

    @embed_group.command(name="create", description="Create a reusable custom embed")
    @commands.has_guild_permissions(manage_guild=True)
    async def embed_create(self, ctx, name: str, config: str = ""):
        name = name.strip().lower()
        if not name or len(name) > 50:
            return await ctx.send("Embed names must contain 1 to 50 characters.", ephemeral=ctx.interaction is not None)
        if config:
            try:
                parsed = validate_embed_config(config)
            except ValueError as error:
                return await ctx.send(str(error), ephemeral=ctx.interaction is not None)
            await self.save_embed(ctx.guild.id, name, parsed, ctx.author.id)
            return await ctx.send(f"Embed `{name}` created.", ephemeral=ctx.interaction is not None)
        await self._open_embed_modal(ctx, name)

    @embed_group.command(name="edit", description="Edit a reusable custom embed")
    @commands.has_guild_permissions(manage_guild=True)
    async def embed_edit(self, ctx, name: str, config: str = ""):
        name = name.strip().lower()
        async with self.bot.db.execute(
            "SELECT config FROM custom_embeds WHERE guild_id=? AND name=?", (ctx.guild.id, name)
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return await ctx.send(f"Embed `{name}` was not found.", ephemeral=ctx.interaction is not None)
        parsed = json.loads(row[0])
        if config:
            try:
                parsed = validate_embed_config(config)
            except ValueError as error:
                return await ctx.send(str(error), ephemeral=ctx.interaction is not None)
            await self.save_embed(ctx.guild.id, name, parsed, ctx.author.id)
            return await ctx.send(f"Embed `{name}` updated.", ephemeral=ctx.interaction is not None)
        await self._open_embed_modal(ctx, name, parsed)

    @embed_group.command(name="import", description="Create or replace a reusable embed from JSON")
    @commands.has_guild_permissions(manage_guild=True)
    async def embed_import(self, ctx, name: str, *, config: str):
        name = name.strip().casefold()
        if not name or len(name) > 50:
            return await ctx.send("Embed names must contain 1 to 50 characters.", ephemeral=ctx.interaction is not None)
        try:
            parsed = validate_embed_config(config)
        except ValueError as error:
            return await ctx.send(str(error), ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "SELECT 1 FROM custom_embeds WHERE guild_id=? AND name=?",
            (ctx.guild.id, name),
        ) as cursor:
            existed = await cursor.fetchone() is not None
        await self.save_embed(ctx.guild.id, name, parsed, ctx.author.id)
        result = "replaced" if existed else "imported"
        await ctx.send(
            f"Embed `{name}` {result} from JSON.",
            ephemeral=ctx.interaction is not None,
        )

    @embed_group.command(name="show", description="Send a saved custom embed")
    async def embed_show(self, ctx, name: str):
        async with self.bot.db.execute(
            "SELECT config FROM custom_embeds WHERE guild_id=? AND name=?", (ctx.guild.id, name.lower())
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return await ctx.send(f"Embed `{name}` was not found.", ephemeral=ctx.interaction is not None)
        try:
            embed = build_custom_embed(json.loads(row[0]), ctx.author, ctx.guild, ctx.channel, self.bot.user)
        except (ValueError, TypeError, discord.DiscordException) as error:
            return await ctx.send(f"Saved embed is invalid: {error}", ephemeral=ctx.interaction is not None)
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())

    @embed_group.command(name="preview", description="Preview a saved custom embed")
    async def embed_preview(self, ctx, name: str):
        await self.embed_show.callback(self, ctx, name)

    @embed_group.command(name="test", description="Test a saved custom embed without changing it")
    async def embed_test(self, ctx, name: str):
        await self.embed_show.callback(self, ctx, name)

    @embed_group.command(name="send", description="Send a saved custom embed to a channel")
    @commands.has_guild_permissions(manage_guild=True)
    async def embed_send(self, ctx, name: str, channel: discord.TextChannel):
        async with self.bot.db.execute(
            "SELECT config FROM custom_embeds WHERE guild_id=? AND name=?",
            (ctx.guild.id, name.strip().casefold()),
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return await ctx.send(f"Embed `{name}` was not found.", ephemeral=ctx.interaction is not None)
        bot_member = ctx.guild.me
        permissions = channel.permissions_for(bot_member) if bot_member else None
        if permissions is None or not permissions.view_channel or not permissions.send_messages or not permissions.embed_links:
            return await ctx.send(f"I cannot send embeds in {channel.mention}; check View Channel, Send Messages, and Embed Links.")
        try:
            embed = build_custom_embed(json.loads(row[0]), ctx.author, ctx.guild, channel, self.bot.user)
        except (ValueError, TypeError, discord.DiscordException) as error:
            return await ctx.send(f"Saved embed is invalid: {error}")
        await send_v2(channel, embed=embed, allowed_mentions=discord.AllowedMentions.none())
        await ctx.send(f"Embed `{name}` sent to {channel.mention}.", ephemeral=ctx.interaction is not None)

    @embed_group.command(name="clone", description="Clone a saved embed under a new name")
    @commands.has_guild_permissions(manage_guild=True)
    async def embed_clone(self, ctx, source: str, new_name: str):
        source = source.strip().casefold()
        new_name = new_name.strip().casefold()
        if not new_name or len(new_name) > 50:
            return await ctx.send("Embed names must contain 1 to 50 characters.", ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "SELECT config FROM custom_embeds WHERE guild_id=? AND name=?",
            (ctx.guild.id, source),
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return await ctx.send(f"Embed `{source}` was not found.", ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "SELECT 1 FROM custom_embeds WHERE guild_id=? AND name=?",
            (ctx.guild.id, new_name),
        ) as cursor:
            if await cursor.fetchone():
                return await ctx.send(f"Embed `{new_name}` already exists.", ephemeral=ctx.interaction is not None)
        await self.save_embed(ctx.guild.id, new_name, json.loads(row[0]), ctx.author.id)
        await ctx.send(f"Embed `{source}` cloned as `{new_name}`.", ephemeral=ctx.interaction is not None)

    @embed_group.command(name="list", description="List saved custom embeds")
    async def embed_list(self, ctx):
        async with self.bot.db.execute(
            "SELECT name, updated_at FROM custom_embeds WHERE guild_id=? ORDER BY name",
            (ctx.guild.id,),
        ) as cursor:
            rows = await cursor.fetchall()
        if not rows:
            return await ctx.send("No custom embeds are saved.", ephemeral=ctx.interaction is not None)
        lines = [
            f"`{name}` • updated <t:{int(datetime.datetime.fromisoformat(updated).timestamp())}:R>"
            for name, updated in rows
        ]
        await self._send_paged_list(ctx, "Saved Embeds", lines)

    @embed_group.command(name="delete", description="Delete a saved custom embed")
    @commands.has_guild_permissions(manage_guild=True)
    async def embed_delete(self, ctx, name: str):
        normalized_name = name.lower()

        async def delete_embed():
            await self.bot.db.execute(
                "DELETE FROM custom_embeds WHERE guild_id=? AND name=?",
                (ctx.guild.id, normalized_name),
            )
            await self.bot.db.commit()

        await self._confirm_destructive_action(
            ctx,
            f"Delete saved embed `{normalized_name}`?",
            f"Embed `{normalized_name}` deleted if it existed.",
            delete_embed,
        )

    @embed_group.command(name="remove", description="Remove a saved custom embed")
    @commands.has_guild_permissions(manage_guild=True)
    async def embed_remove(self, ctx, name: str):
        await self.embed_delete.callback(self, ctx, name)

    @embed_group.group(name="field", invoke_without_command=True, case_insensitive=True)
    async def embed_field_group(self, ctx):
        await ctx.send("Use `/embed field add|edit|delete|list`.", ephemeral=ctx.interaction is not None)

    async def _get_saved_embed_config(self, ctx, name):
        async with self.bot.db.execute(
            "SELECT config FROM custom_embeds WHERE guild_id=? AND name=?",
            (ctx.guild.id, name.strip().casefold()),
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return None
        return json.loads(row[0])

    @embed_field_group.command(name="add", description="Add a field to a saved embed")
    @commands.has_guild_permissions(manage_guild=True)
    async def embed_field_add(self, ctx, name: str, field_name: str, value: str, inline: bool = False):
        try:
            config = await self._get_saved_embed_config(ctx, name)
            if config is None:
                return await ctx.send(f"Embed `{name}` was not found.", ephemeral=ctx.interaction is not None)
            fields = config.setdefault("fields", [])
            if len(fields) >= 25:
                return await ctx.send("Embeds can have at most 25 fields.", ephemeral=ctx.interaction is not None)
            fields.append({"name": field_name, "value": value, "inline": inline})
            build_custom_embed(config, ctx.author, ctx.guild, ctx.channel, self.bot.user)
        except (ValueError, TypeError, discord.DiscordException) as error:
            return await ctx.send(str(error), ephemeral=ctx.interaction is not None)
        await self.save_embed(ctx.guild.id, name, config, ctx.author.id)
        await ctx.send(f"Field added to embed `{name}`.", ephemeral=ctx.interaction is not None)

    @embed_field_group.command(name="edit", description="Edit a field in a saved embed")
    @commands.has_guild_permissions(manage_guild=True)
    async def embed_field_edit(self, ctx, name: str, index: int, field_name: str, value: str, inline: bool | None = None):
        try:
            config = await self._get_saved_embed_config(ctx, name)
            if config is None:
                return await ctx.send(f"Embed `{name}` was not found.", ephemeral=ctx.interaction is not None)
            fields = config.get("fields", [])
            if not 1 <= index <= len(fields):
                return await ctx.send("Choose an existing field number.", ephemeral=ctx.interaction is not None)
            fields[index - 1].update(name=field_name, value=value)
            if inline is not None:
                fields[index - 1]["inline"] = inline
            build_custom_embed(config, ctx.author, ctx.guild, ctx.channel, self.bot.user)
        except (ValueError, TypeError, discord.DiscordException) as error:
            return await ctx.send(str(error), ephemeral=ctx.interaction is not None)
        await self.save_embed(ctx.guild.id, name, config, ctx.author.id)
        await ctx.send(f"Field {index} updated in embed `{name}`.", ephemeral=ctx.interaction is not None)

    @embed_field_group.command(name="delete", description="Delete a field from a saved embed")
    @commands.has_guild_permissions(manage_guild=True)
    async def embed_field_delete(self, ctx, name: str, index: int):
        config = await self._get_saved_embed_config(ctx, name)
        if config is None:
            return await ctx.send(f"Embed `{name}` was not found.", ephemeral=ctx.interaction is not None)
        fields = config.get("fields", [])
        if not 1 <= index <= len(fields):
            return await ctx.send("Choose an existing field number.", ephemeral=ctx.interaction is not None)
        fields.pop(index - 1)
        await self.save_embed(ctx.guild.id, name, config, ctx.author.id)
        await ctx.send(f"Field {index} deleted from embed `{name}`.", ephemeral=ctx.interaction is not None)

    @embed_field_group.command(name="list", description="List fields in a saved embed")
    async def embed_field_list(self, ctx, name: str):
        config = await self._get_saved_embed_config(ctx, name)
        if config is None:
            return await ctx.send(f"Embed `{name}` was not found.", ephemeral=ctx.interaction is not None)
        fields = config.get("fields", [])
        lines = [f"{index}. **{field['name']}**: {field['value']}" for index, field in enumerate(fields, 1)]
        await ctx.send("\n".join(lines) if lines else f"Embed `{name}` has no fields.", ephemeral=ctx.interaction is not None)

    @commands.hybrid_group(name="autoresponder", aliases=["ar"], invoke_without_command=True, case_insensitive=True)
    async def autoresponder_group(self, ctx):
        await ctx.send(
            "Use `/autoresponder add`, `/autoresponder edit`, `/autoresponder matchmode`, "
            "`/autoresponder design`, `/autoresponder remove`, `/autoresponder list`, or `/autoresponder show`.",
            ephemeral=ctx.interaction is not None,
        )

    @autoresponder_group.command(name="add", description="Add a keyword autoresponder")
    @commands.has_guild_permissions(manage_guild=True)
    async def autoresponder_add(self, ctx, trigger: str, *, response: str):
        trigger = trigger.strip().casefold()
        response = response.strip()
        if not trigger or len(trigger) > 100:
            return await ctx.send("Triggers must contain 1 to 100 characters.", ephemeral=ctx.interaction is not None)
        if not response or len(response) > 2000:
            return await ctx.send("Responses must contain 1 to 2000 characters.", ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "SELECT 1 FROM autoresponders WHERE guild_id=? AND trigger=?", (ctx.guild.id, trigger)
        ) as cursor:
            exists = await cursor.fetchone()
        if exists:
            return await ctx.send("That trigger already exists. Use `/autoresponder edit`.", ephemeral=ctx.interaction is not None)
        await self.bot.db.execute(
            "INSERT INTO autoresponders (guild_id, trigger, response, updated_by, updated_at) VALUES (?, ?, ?, ?, ?)",
            (ctx.guild.id, trigger, response, ctx.author.id, utc_now().isoformat()),
        )
        await self.bot.db.commit()
        await ctx.send(f"Autoresponder added for `{trigger}`.", ephemeral=ctx.interaction is not None)

    @autoresponder_group.command(name="edit", description="Edit a keyword autoresponder")
    @commands.has_guild_permissions(manage_guild=True)
    async def autoresponder_edit(self, ctx, trigger: str, *, response: str):
        trigger = trigger.strip().casefold()
        response = response.strip()
        if not response or len(response) > 2000:
            return await ctx.send("Responses must contain 1 to 2000 characters.", ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "UPDATE autoresponders SET response=?, updated_by=?, updated_at=? WHERE guild_id=? AND trigger=?",
            (response, ctx.author.id, utc_now().isoformat(), ctx.guild.id, trigger),
        ) as cursor:
            updated = cursor.rowcount
        await self.bot.db.commit()
        if not updated:
            return await ctx.send(f"No autoresponder exists for `{trigger}`.", ephemeral=ctx.interaction is not None)
        await ctx.send(f"Autoresponder `{trigger}` updated.", ephemeral=ctx.interaction is not None)

    @autoresponder_group.command(name="matchmode", description="Change how an autoresponder matches messages")
    @commands.has_guild_permissions(manage_guild=True)
    async def autoresponder_matchmode(
        self,
        ctx,
        trigger: str,
        mode: Literal["exact", "contains", "startswith", "endswith"],
    ):
        trigger = trigger.strip().casefold()
        if not trigger:
            return await ctx.send("Trigger cannot be empty.", ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "UPDATE autoresponders SET mode=?, updated_by=?, updated_at=? "
            "WHERE guild_id=? AND trigger=?",
            (mode, ctx.author.id, utc_now().isoformat(), ctx.guild.id, trigger),
        ) as cursor:
            updated = cursor.rowcount
        await self.bot.db.commit()
        if not updated:
            return await ctx.send(f"No autoresponder exists for `{trigger}`.", ephemeral=ctx.interaction is not None)
        await ctx.send(
            f"Autoresponder `{trigger}` now matches `{mode}`.",
            ephemeral=ctx.interaction is not None,
        )

    @autoresponder_group.command(name="design", description="Create or edit an autoresponder embed")
    @commands.has_guild_permissions(manage_guild=True)
    async def autoresponder_design(self, ctx, trigger: str, name: str):
        trigger = trigger.strip().casefold()
        name = name.strip().casefold()
        if not trigger or len(trigger) > 100:
            return await ctx.send("Triggers must contain 1 to 100 characters.", ephemeral=ctx.interaction is not None)
        if not name or len(name) > 50:
            return await ctx.send("Embed names must contain 1 to 50 characters.", ephemeral=ctx.interaction is not None)
        if ctx.interaction is None:
            return await ctx.send("Use `/autoresponder design` as a slash command to open the live embed editor.")

        async with self.bot.db.execute(
            "SELECT config FROM custom_embeds WHERE guild_id=? AND name=?",
            (ctx.guild.id, name),
        ) as cursor:
            saved = await cursor.fetchone()
        config = json.loads(saved[0]) if saved else DEFAULT_EMBED_CONFIG
        extra_values = {
            "message": trigger,
            "message.content": trigger,
        }

        async def save_autoresponder_embed(updated_config):
            async with self.bot.db.execute(
                "SELECT response FROM autoresponders WHERE guild_id=? AND trigger=?",
                (ctx.guild.id, trigger),
            ) as cursor:
                existing = await cursor.fetchone()
            response = existing[0] if existing else ""
            response = re.sub(r"\{embed:[^}]+\}", "", response, flags=re.IGNORECASE).strip()
            response = f"{response} {{embed:{name}}}" if response else f"{{embed:{name}}}"
            if len(response) > 2000:
                raise ValueError("The existing autoresponder text is too long to add an embed action.")

            await self.save_embed(ctx.guild.id, name, updated_config, ctx.author.id)
            await self.bot.db.execute(
                "INSERT INTO autoresponders (guild_id, trigger, response, updated_by, updated_at) "
                "VALUES (?, ?, ?, ?, ?) ON CONFLICT(guild_id, trigger) DO UPDATE SET "
                "response=excluded.response, updated_by=excluded.updated_by, updated_at=excluded.updated_at",
                (ctx.guild.id, trigger, response, ctx.author.id, utc_now().isoformat()),
            )
            await self.bot.db.commit()

        await self._open_embed_editor(
            ctx.interaction,
            f"autoresponder: {trigger}",
            config,
            owner_id=ctx.author.id,
            save_callback=save_autoresponder_embed,
            extra_values=extra_values,
        )

    @autoresponder_group.command(name="remove", description="Remove a keyword autoresponder")
    @commands.has_guild_permissions(manage_guild=True)
    async def autoresponder_remove(self, ctx, trigger: str):
        trigger = trigger.strip().casefold()

        async def delete_autoresponder():
            await self.bot.db.execute(
                "DELETE FROM autoresponders WHERE guild_id=? AND trigger=?",
                (ctx.guild.id, trigger),
            )
            await self.bot.db.commit()

        await self._confirm_destructive_action(
            ctx,
            f"Remove autoresponder `{trigger}`?",
            f"Autoresponder `{trigger}` removed if it existed.",
            delete_autoresponder,
        )

    @autoresponder_group.command(name="delete", description="Delete a keyword autoresponder")
    @commands.has_guild_permissions(manage_guild=True)
    async def autoresponder_delete(self, ctx, trigger: str):
        await self.autoresponder_remove.callback(self, ctx, trigger)

    @autoresponder_group.command(name="list", description="List this server's autoresponders")
    async def autoresponder_list(self, ctx):
        async with self.bot.db.execute(
            "SELECT trigger, mode, channel_id, role_id, cooldown, enabled FROM autoresponders "
            "WHERE guild_id=? ORDER BY trigger",
            (ctx.guild.id,),
        ) as cursor:
            rows = await cursor.fetchall()
        if not rows:
            return await ctx.send("No autoresponders are configured.", ephemeral=ctx.interaction is not None)
        lines = []
        for trigger, mode, channel_id, role_id, cooldown, enabled in rows:
            restrictions = []
            if channel_id:
                channel = ctx.guild.get_channel(channel_id)
                restrictions.append(channel.mention if channel else f"missing channel `{channel_id}`")
            if role_id:
                role = ctx.guild.get_role(role_id)
                restrictions.append(role.mention if role else f"missing role `{role_id}`")
            restrictions.append(f"{cooldown}s cooldown")
            restrictions.append("enabled" if enabled else "disabled")
            lines.append(f"`{trigger}` — {mode}; {', '.join(restrictions)}")
        await self._send_paged_list(ctx, "Autoresponders", lines)

    async def _set_autoresponder_enabled(self, ctx, trigger, enabled):
        trigger = trigger.strip().casefold()
        async with self.bot.db.execute(
            "UPDATE autoresponders SET enabled=?, updated_by=?, updated_at=? "
            "WHERE guild_id=? AND trigger=?",
            (int(enabled), ctx.author.id, utc_now().isoformat(), ctx.guild.id, trigger),
        ) as cursor:
            changed = cursor.rowcount
        await self.bot.db.commit()
        if not changed:
            return await ctx.send(f"No autoresponder exists for `{trigger}`.", ephemeral=ctx.interaction is not None)
        state = "enabled" if enabled else "disabled"
        await ctx.send(f"Autoresponder `{trigger}` {state}.", ephemeral=ctx.interaction is not None)

    @autoresponder_group.command(name="show", description="Show one autoresponder's configuration")
    async def autoresponder_show(self, ctx, trigger: str):
        trigger = trigger.strip().casefold()
        async with self.bot.db.execute(
            "SELECT response, mode, channel_id, role_id, cooldown, enabled, excluded_channel_ids, "
            "allowed_role_ids, excluded_role_ids, cooldown_scope, case_sensitive "
            "FROM autoresponders WHERE guild_id=? AND trigger=?",
            (ctx.guild.id, trigger),
        ) as cursor:
            row = await cursor.fetchone()
        if row is None:
            return await ctx.send(f"No autoresponder exists for `{trigger}`.", ephemeral=ctx.interaction is not None)
        response, mode, channel_id, role_id, cooldown, enabled, excluded_channels, allowed_roles, excluded_roles, scope, case_sensitive = row
        embed = discord.Embed(title=f"Autoresponder: {trigger}", color=0xFFDD00)
        embed.add_field(name="Status", value="Enabled" if enabled else "Disabled", inline=True)
        embed.add_field(name="Match", value=f"{mode}; {'case-sensitive' if case_sensitive else 'case-insensitive'}", inline=True)
        embed.add_field(name="Cooldown", value=f"{cooldown}s ({scope})", inline=True)
        embed.add_field(name="Response", value=response[:1024], inline=False)
        channel_ids = set(json.loads(excluded_channels or "[]"))
        if channel_id:
            channel_ids.add(channel_id)
        role_ids = set(json.loads(allowed_roles or "[]"))
        role_ids.update(json.loads(excluded_roles or "[]"))
        if role_id:
            role_ids.add(role_id)
        embed.add_field(
            name="Restrictions",
            value=(
                f"Channels: {', '.join(f'<#{item}>' for item in sorted(channel_ids)) or 'All'}\n"
                f"Roles: {', '.join(f'<@&{item}>' for item in sorted(role_ids)) or 'Everyone'}"
            ),
            inline=False,
        )
        await ctx.send(embed=embed, ephemeral=ctx.interaction is not None)

    @autoresponder_group.command(name="enable", description="Enable an autoresponder")
    @commands.has_guild_permissions(manage_guild=True)
    async def autoresponder_enable(self, ctx, trigger: str):
        await self._set_autoresponder_enabled(ctx, trigger, True)

    @autoresponder_group.command(name="disable", description="Disable an autoresponder")
    @commands.has_guild_permissions(manage_guild=True)
    async def autoresponder_disable(self, ctx, trigger: str):
        await self._set_autoresponder_enabled(ctx, trigger, False)

    @autoresponder_group.command(name="toggle", description="Toggle an autoresponder")
    @commands.has_guild_permissions(manage_guild=True)
    async def autoresponder_toggle(self, ctx, trigger: str):
        normalized = trigger.strip().casefold()
        async with self.bot.db.execute(
            "SELECT enabled FROM autoresponders WHERE guild_id=? AND trigger=?",
            (ctx.guild.id, normalized),
        ) as cursor:
            row = await cursor.fetchone()
        if row is None:
            return await ctx.send(f"No autoresponder exists for `{normalized}`.", ephemeral=ctx.interaction is not None)
        await self._set_autoresponder_enabled(ctx, normalized, not bool(row[0]))

    @autoresponder_group.command(name="clear", description="Remove all autoresponders from this server")
    @commands.has_guild_permissions(manage_guild=True)
    async def autoresponder_clear(self, ctx):
        async def clear_autoresponders():
            await self.bot.db.execute("DELETE FROM autoresponders WHERE guild_id=?", (ctx.guild.id,))
            await self.bot.db.commit()

        await self._confirm_destructive_action(
            ctx,
            "Remove every autoresponder configured for this server?",
            "All server autoresponders were removed.",
            clear_autoresponders,
        )

    @autoresponder_group.command(name="options", description="Configure matching, restrictions, and cooldown for a trigger")
    @commands.has_guild_permissions(manage_guild=True)
    async def autoresponder_options(
        self,
        ctx,
        trigger: str,
        mode: Literal["contains", "exact", "starts", "starts_with", "ends", "ends_with"] | None = None,
        channel: discord.TextChannel | None = None,
        role: discord.Role | None = None,
        cooldown: int | None = None,
        enabled: bool | None = None,
        clear_restrictions: bool = False,
    ):
        trigger = trigger.strip().casefold()
        if not trigger or len(trigger) > 100:
            return await ctx.send("Triggers must contain 1 to 100 characters.", ephemeral=ctx.interaction is not None)
        if cooldown is not None and not 0 <= cooldown <= 86400:
            return await ctx.send("Cooldown must be between 0 and 86400 seconds.", ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "SELECT mode, channel_id, role_id, cooldown, enabled FROM autoresponders "
            "WHERE guild_id=? AND trigger=?",
            (ctx.guild.id, trigger),
        ) as cursor:
            current = await cursor.fetchone()
        if not current:
            return await ctx.send(f"No autoresponder exists for `{trigger}`.", ephemeral=ctx.interaction is not None)
        current_mode, current_channel, current_role, current_cooldown, current_enabled = current
        channel_id = None if clear_restrictions else (channel.id if channel else current_channel)
        role_id = None if clear_restrictions else (role.id if role else current_role)
        async with self.bot.db.execute(
            "UPDATE autoresponders SET mode=?, channel_id=?, role_id=?, cooldown=?, enabled=?, "
            "updated_by=?, updated_at=? WHERE guild_id=? AND trigger=?",
            (
                mode or current_mode,
                channel_id,
                role_id,
                current_cooldown if cooldown is None else cooldown,
                current_enabled if enabled is None else int(enabled),
                ctx.author.id,
                utc_now().isoformat(),
                ctx.guild.id,
                trigger,
            ),
        ) as cursor:
            updated = cursor.rowcount
        await self.bot.db.commit()
        if not updated:
            return await ctx.send(f"No autoresponder exists for `{trigger}`.", ephemeral=ctx.interaction is not None)
        await ctx.send(f"Options updated for autoresponder `{trigger}`.", ephemeral=ctx.interaction is not None)

    @autoresponder_group.command(name="restrictions", description="Set multi-role and channel exclusions")
    @commands.has_guild_permissions(manage_guild=True)
    async def autoresponder_restrictions(
        self,
        ctx,
        trigger: str,
        roles: str = "",
        excluded_roles: str = "",
        excluded_channels: str = "",
        cooldown_scope: Literal["user", "channel", "global"] | None = None,
        case_sensitive: bool | None = None,
    ):
        trigger = trigger.strip().casefold()

        def resolve_ids(raw_value, resolver):
            ids = set()
            for token in raw_value.split():
                match = re.fullmatch(r"<@&?(\d+)>|<#(\d+)>|(\d{15,22})", token.strip(","))
                if not match:
                    raise ValueError(f"Invalid target: `{token}`.")
                target_id = int(next(group for group in match.groups() if group))
                target = resolver(target_id)
                if target is None:
                    raise ValueError(f"Target `{token}` is not part of this server.")
                ids.add(target_id)
            return sorted(ids)

        try:
            allowed_role_ids = resolve_ids(roles, ctx.guild.get_role)
            excluded_role_ids = resolve_ids(excluded_roles, ctx.guild.get_role)
            excluded_channel_ids = resolve_ids(
                excluded_channels,
                lambda channel_id: ctx.guild.get_channel(channel_id)
                if isinstance(ctx.guild.get_channel(channel_id), (discord.TextChannel, discord.Thread))
                else None,
            )
        except (ValueError, StopIteration) as error:
            return await ctx.send(str(error), ephemeral=ctx.interaction is not None)
        if cooldown_scope not in {None, "user", "channel", "global"}:
            return await ctx.send("Cooldown scope must be user, channel, or global.", ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "UPDATE autoresponders SET allowed_role_ids=?, excluded_role_ids=?, excluded_channel_ids=?, "
            "cooldown_scope=COALESCE(?, cooldown_scope), case_sensitive=COALESCE(?, case_sensitive), "
            "updated_by=?, updated_at=? WHERE guild_id=? AND trigger=?",
            (
                json.dumps(allowed_role_ids),
                json.dumps(excluded_role_ids),
                json.dumps(excluded_channel_ids),
                cooldown_scope,
                int(case_sensitive) if case_sensitive is not None else None,
                ctx.author.id,
                utc_now().isoformat(),
                ctx.guild.id,
                trigger,
            ),
        ) as cursor:
            updated = cursor.rowcount
        await self.bot.db.commit()
        if not updated:
            return await ctx.send(f"No autoresponder exists for `{trigger}`.", ephemeral=ctx.interaction is not None)
        await ctx.send(f"Restrictions updated for autoresponder `{trigger}`.", ephemeral=ctx.interaction is not None)

    @autoresponder_group.command(name="test", description="Preview the response for a configured trigger")
    @commands.has_guild_permissions(manage_guild=True)
    async def autoresponder_test(self, ctx, trigger: str):
        async with self.bot.db.execute(
            "SELECT response FROM autoresponders WHERE guild_id=? AND trigger=?",
            (ctx.guild.id, trigger.strip().casefold()),
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return await ctx.send(f"No autoresponder exists for `{trigger}`.", ephemeral=ctx.interaction is not None)
        await self._send_automated_response(
            ctx.message,
            row[0],
            allow_delete=False,
            channel=ctx.channel,
            user=ctx.author,
            guild=ctx.guild,
            extra_values={
                "message": f"Preview for {trigger}",
                "message.content": f"Preview for {trigger}",
            },
        )

    @commands.hybrid_group(name="customcommand", aliases=["customcmd"], invoke_without_command=True, case_insensitive=True)
    async def customcommand_group(self, ctx):
        await ctx.send(
            "Use `/customcommand add`, `/customcommand remove`, or `/customcommand list`.",
            ephemeral=ctx.interaction is not None,
        )

    @customcommand_group.command(name="add", description="Create a per-server prefix command")
    @commands.has_guild_permissions(manage_guild=True)
    async def customcommand_add(
        self,
        ctx,
        name: str,
        response: str,
        cooldown: int = 0,
        role: discord.Role = None,
        channel: discord.TextChannel = None,
    ):
        name = name.strip().casefold()
        response = response.strip()
        if not CUSTOM_COMMAND_PATTERN.fullmatch(name):
            return await ctx.send("Names must start with a letter and contain only letters, numbers, `_` or `-` (max 32).", ephemeral=ctx.interaction is not None)
        if self.bot.get_command(name):
            return await ctx.send("That name is already used by a built-in command.", ephemeral=ctx.interaction is not None)
        if not response or len(response) > 2000:
            return await ctx.send("Responses must contain 1 to 2000 characters.", ephemeral=ctx.interaction is not None)
        if not 0 <= cooldown <= 86400:
            return await ctx.send("Cooldown must be between 0 and 86400 seconds.", ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "INSERT INTO custom_commands "
            "(guild_id, name, response, role_id, channel_id, cooldown, updated_by, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT(guild_id, name) DO NOTHING",
            (
                ctx.guild.id,
                name,
                response,
                role.id if role else None,
                channel.id if channel else None,
                cooldown,
                ctx.author.id,
                utc_now().isoformat(),
            ),
        ) as cursor:
            inserted = cursor.rowcount
        await self.bot.db.commit()
        if not inserted:
            return await ctx.send(f"Custom command `{name}` already exists.", ephemeral=ctx.interaction is not None)
        await ctx.send(f"Custom command `{name}` created.", ephemeral=ctx.interaction is not None)

    @customcommand_group.command(name="create", description="Create a per-server prefix command")
    @commands.has_guild_permissions(manage_guild=True)
    async def customcommand_create(
        self,
        ctx,
        name: str,
        response: str,
        cooldown: int = 0,
        role: discord.Role = None,
        channel: discord.TextChannel = None,
    ):
        await self.customcommand_add.callback(self, ctx, name, response, cooldown, role, channel)

    @customcommand_group.command(name="edit", description="Edit a per-server prefix command")
    @commands.has_guild_permissions(manage_guild=True)
    async def customcommand_edit(self, ctx, name: str, response: str):
        name = name.strip().casefold()
        response = response.strip()
        if not response or len(response) > 2000:
            return await ctx.send("Responses must contain 1 to 2000 characters.", ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "UPDATE custom_commands SET response=?, updated_by=?, updated_at=? WHERE guild_id=? AND name=?",
            (response, ctx.author.id, utc_now().isoformat(), ctx.guild.id, name),
        ) as cursor:
            updated = cursor.rowcount
        await self.bot.db.commit()
        if not updated:
            return await ctx.send(f"Custom command `{name}` was not found.", ephemeral=ctx.interaction is not None)
        await ctx.send(f"Custom command `{name}` updated.", ephemeral=ctx.interaction is not None)

    async def _set_custom_command_enabled(self, ctx, name, enabled):
        name = name.strip().casefold()
        async with self.bot.db.execute(
            "UPDATE custom_commands SET enabled=?, updated_by=?, updated_at=? WHERE guild_id=? AND name=?",
            (int(enabled), ctx.author.id, utc_now().isoformat(), ctx.guild.id, name),
        ) as cursor:
            updated = cursor.rowcount
        await self.bot.db.commit()
        if not updated:
            return await ctx.send(f"Custom command `{name}` was not found.", ephemeral=ctx.interaction is not None)
        await ctx.send(
            f"Custom command `{name}` {'enabled' if enabled else 'disabled'}.",
            ephemeral=ctx.interaction is not None,
        )

    @customcommand_group.command(name="enable", description="Enable a per-server prefix command")
    @commands.has_guild_permissions(manage_guild=True)
    async def customcommand_enable(self, ctx, name: str):
        await self._set_custom_command_enabled(ctx, name, True)

    @customcommand_group.command(name="disable", description="Disable a per-server prefix command")
    @commands.has_guild_permissions(manage_guild=True)
    async def customcommand_disable(self, ctx, name: str):
        await self._set_custom_command_enabled(ctx, name, False)

    @customcommand_group.command(name="show", description="Show a per-server prefix command")
    async def customcommand_show(self, ctx, name: str):
        name = name.strip().casefold()
        async with self.bot.db.execute(
            "SELECT response, role_id, channel_id, cooldown, enabled FROM custom_commands "
            "WHERE guild_id=? AND name=?",
            (ctx.guild.id, name),
        ) as cursor:
            row = await cursor.fetchone()
        if row is None:
            return await ctx.send(f"Custom command `{name}` was not found.", ephemeral=ctx.interaction is not None)
        response, role_id, channel_id, cooldown, enabled = row
        role = ctx.guild.get_role(role_id) if role_id else None
        channel = ctx.guild.get_channel(channel_id) if channel_id else None
        embed = discord.Embed(title=f"Custom command: {name}", color=0xFFDD00)
        embed.description = response[:3500]
        embed.add_field(name="Status", value="Enabled" if enabled else "Disabled", inline=True)
        embed.add_field(name="Cooldown", value=f"{cooldown}s", inline=True)
        embed.add_field(name="Role", value=role.mention if role else "Everyone", inline=True)
        embed.add_field(name="Channel", value=channel.mention if channel else "All channels", inline=True)
        await ctx.send(embed=embed, ephemeral=ctx.interaction is not None)

    @customcommand_group.command(name="remove", description="Remove a per-server prefix command")
    @commands.has_guild_permissions(manage_guild=True)
    async def customcommand_remove(self, ctx, name: str):
        name = name.strip().casefold()
        async with self.bot.db.execute(
            "SELECT 1 FROM custom_commands WHERE guild_id=? AND name=?",
            (ctx.guild.id, name),
        ) as cursor:
            exists = await cursor.fetchone()
        if not exists:
            return await ctx.send(f"Custom command `{name}` was not found.", ephemeral=ctx.interaction is not None)

        async def delete_custom_command():
            await self.bot.db.execute(
                "DELETE FROM custom_commands WHERE guild_id=? AND name=?",
                (ctx.guild.id, name),
            )
            await self.bot.db.commit()

        await self._confirm_destructive_action(
            ctx,
            f"Remove custom command `{name}`?",
            f"Custom command `{name}` removed.",
            delete_custom_command,
        )

    @customcommand_group.command(name="delete", description="Delete a per-server prefix command")
    @commands.has_guild_permissions(manage_guild=True)
    async def customcommand_delete(self, ctx, name: str):
        await self.customcommand_remove.callback(self, ctx, name)

    @customcommand_group.command(name="list", description="List this server's custom prefix commands")
    async def customcommand_list(self, ctx):
        async with self.bot.db.execute(
            "SELECT name, role_id, channel_id, cooldown, enabled FROM custom_commands WHERE guild_id=? ORDER BY name",
            (ctx.guild.id,),
        ) as cursor:
            rows = await cursor.fetchall()
        if not rows:
            return await ctx.send("No custom commands are configured.", ephemeral=ctx.interaction is not None)
        lines = []
        for name, role_id, channel_id, cooldown, enabled in rows:
            restrictions = [f"{cooldown}s cooldown"]
            restrictions.append("enabled" if enabled else "disabled")
            if role_id:
                role = ctx.guild.get_role(role_id)
                restrictions.append(role.mention if role else f"missing role `{role_id}`")
            if channel_id:
                channel = ctx.guild.get_channel(channel_id)
                restrictions.append(channel.mention if channel else f"missing channel `{channel_id}`")
            lines.append(f"`{name}` — {', '.join(restrictions)}")
        await self._send_paged_list(ctx, "Custom Commands", lines)

    @customcommand_group.command(name="test", description="Preview a custom command response")
    @commands.has_guild_permissions(manage_guild=True)
    async def customcommand_test(self, ctx, name: str, *, args: str = ""):
        async with self.bot.db.execute(
            "SELECT response FROM custom_commands WHERE guild_id=? AND name=?",
            (ctx.guild.id, name.strip().casefold()),
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return await ctx.send(f"Custom command `{name}` was not found.", ephemeral=ctx.interaction is not None)
        await self._send_automated_response(
            ctx.message,
            row[0],
            allow_delete=False,
            channel=ctx.channel,
            user=ctx.author,
            guild=ctx.guild,
            extra_values={"args": args},
        )

    @commands.hybrid_group(name="boost", invoke_without_command=True, case_insensitive=True)
    async def boost_group(self, ctx):
        await ctx.send(
            "Use `/boost setup`, `/boost channel`, `/boost message`, `/boost embed`, `/boost design`, `/boost card enable|disable`, `/boost preview`, or `/boost reset`.",
            ephemeral=ctx.interaction is not None,
        )

    async def save_boost_setting(self, guild_id, channel_id, message, user_id, embed_name=None):
        await self.bot.db.execute(
            "INSERT INTO boost_settings (guild_id, channel_id, message, embed_name, updated_by, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(guild_id) DO UPDATE SET "
            "channel_id=excluded.channel_id, message=excluded.message, embed_name=excluded.embed_name, "
            "updated_by=excluded.updated_by, updated_at=excluded.updated_at",
            (guild_id, channel_id, message, embed_name, user_id, utc_now().isoformat()),
        )
        await self.bot.db.commit()

    @boost_group.command(name="setup", description="Set up boost notifications in a channel")
    @commands.has_guild_permissions(manage_guild=True)
    async def boost_setup(self, ctx, channel: discord.TextChannel):
        async with self.bot.db.execute(
            "SELECT message FROM boost_settings WHERE guild_id=?", (ctx.guild.id,)
        ) as cursor:
            row = await cursor.fetchone()
        await self.save_boost_setting(
            ctx.guild.id,
            channel.id,
            row[0] if row else DEFAULT_BOOST_MESSAGE,
            ctx.author.id,
        )
        await ctx.send(f"Boost notifications are set up in {channel.mention}.", ephemeral=ctx.interaction is not None)

    @boost_group.command(name="set", description="Set the server boost message and channel")
    @commands.has_guild_permissions(manage_guild=True)
    async def boost_set(self, ctx, channel: discord.TextChannel, *, message: str):
        message = message.strip()
        if not message or len(message) > 2000:
            return await ctx.send("Boost messages must contain 1 to 2000 characters.", ephemeral=ctx.interaction is not None)
        await self.save_boost_setting(ctx.guild.id, channel.id, message, ctx.author.id)
        await ctx.send(f"Boost messages will be sent to {channel.mention}.", ephemeral=ctx.interaction is not None)

    @boost_group.command(name="channel", description="Change the server boost message channel")
    @commands.has_guild_permissions(manage_guild=True)
    async def boost_channel(self, ctx, channel: discord.TextChannel):
        async with self.bot.db.execute(
            "SELECT message, embed_name FROM boost_settings WHERE guild_id=?", (ctx.guild.id,)
        ) as cursor:
            row = await cursor.fetchone()
        await self.save_boost_setting(
            ctx.guild.id,
            channel.id,
            row[0] if row else DEFAULT_BOOST_MESSAGE,
            ctx.author.id,
            row[1] if row else None,
        )
        await ctx.send(f"Boost messages will be sent to {channel.mention}.", ephemeral=ctx.interaction is not None)

    @boost_group.command(name="message", description="Change the server boost message")
    @commands.has_guild_permissions(manage_guild=True)
    async def boost_message(self, ctx, *, message: str):
        message = message.strip()
        if not message or len(message) > 2000:
            return await ctx.send("Boost messages must contain 1 to 2000 characters.", ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "SELECT channel_id FROM boost_settings WHERE guild_id=?", (ctx.guild.id,)
        ) as cursor:
            row = await cursor.fetchone()
        channel_id = row[0] if row else (ctx.guild.system_channel or ctx.channel).id
        await self.save_boost_setting(ctx.guild.id, channel_id, message, ctx.author.id)
        await ctx.send("Boost message updated.", ephemeral=ctx.interaction is not None)

    @boost_group.command(name="embed", description="Use a saved embed for boost notifications")
    @commands.has_guild_permissions(manage_guild=True)
    async def boost_embed(self, ctx, name: str):
        name = name.strip().casefold()
        async with self.bot.db.execute(
            "SELECT 1 FROM custom_embeds WHERE guild_id=? AND name=?",
            (ctx.guild.id, name),
        ) as cursor:
            if await cursor.fetchone() is None:
                return await ctx.send(f"Saved embed `{name}` was not found.", ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "SELECT channel_id, message FROM boost_settings WHERE guild_id=?",
            (ctx.guild.id,),
        ) as cursor:
            row = await cursor.fetchone()
        channel_id = row[0] if row else (ctx.guild.system_channel or ctx.channel).id
        message = row[1] if row else DEFAULT_BOOST_MESSAGE
        await self.save_boost_setting(ctx.guild.id, channel_id, message, ctx.author.id, name)
        await ctx.send(f"Boost notifications will use saved embed `{name}`.", ephemeral=ctx.interaction is not None)

    @boost_group.command(name="design", description="Create or edit a boost notification embed")
    @commands.has_guild_permissions(manage_guild=True)
    async def boost_design(self, ctx, name: str):
        name = name.strip().casefold()
        if not name or len(name) > 50:
            return await ctx.send("Embed names must contain 1 to 50 characters.", ephemeral=ctx.interaction is not None)
        if ctx.interaction is None:
            return await ctx.send("Use `/boost design` as a slash command to open the live embed editor.")

        async with self.bot.db.execute(
            "SELECT channel_id, message FROM boost_settings WHERE guild_id=?",
            (ctx.guild.id,),
        ) as cursor:
            settings = await cursor.fetchone()
        channel = ctx.guild.get_channel(settings[0]) if settings else None
        channel = channel or ctx.guild.system_channel or ctx.channel
        message = settings[1] if settings else DEFAULT_BOOST_MESSAGE
        async with self.bot.db.execute(
            "SELECT config FROM custom_embeds WHERE guild_id=? AND name=?",
            (ctx.guild.id, name),
        ) as cursor:
            saved = await cursor.fetchone()
        config = json.loads(saved[0]) if saved else DEFAULT_EMBED_CONFIG
        boost_count = getattr(ctx.guild, "premium_subscription_count", 0) or 0
        boost_level = getattr(ctx.guild, "premium_tier", 0) or 0
        extra_values = {
            "booster": ctx.author.mention,
            "boost.user": ctx.author.mention,
            "boost.count": boost_count,
            "boost_count": boost_count,
            "boost.level": boost_level,
        }

        async def save_boost_embed(updated_config):
            await self.save_embed(ctx.guild.id, name, updated_config, ctx.author.id)
            await self.save_boost_setting(ctx.guild.id, channel.id, message, ctx.author.id, name)

        await self._open_embed_editor(
            ctx.interaction,
            f"boost: {name}",
            config,
            owner_id=ctx.author.id,
            save_callback=save_boost_embed,
            extra_values=extra_values,
        )

    @boost_group.command(name="card", description="Enable or disable booster cards")
    @commands.has_guild_permissions(manage_guild=True)
    async def boost_card(self, ctx, action: Literal["enable", "disable"]):
        async with self.bot.db.execute(
            "UPDATE boost_settings SET card_enabled=? WHERE guild_id=?",
            (int(action == "enable"), ctx.guild.id),
        ) as cursor:
            changed = cursor.rowcount
        await self.bot.db.commit()
        if not changed:
            return await ctx.send("Set up boost notifications first with `/boost setup`.", ephemeral=ctx.interaction is not None)
        await ctx.send(
            f"Booster cards {action}d.",
            ephemeral=ctx.interaction is not None,
        )

    @boost_group.command(name="show", description="Show the configured server boost message")
    async def boost_show(self, ctx):
        async with self.bot.db.execute(
            "SELECT channel_id, message, enabled, embed_name, card_enabled "
            "FROM boost_settings WHERE guild_id=?", (ctx.guild.id,)
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return await ctx.send("No boost message is configured.", ephemeral=ctx.interaction is not None)
        channel = ctx.guild.get_channel(row[0])
        response = f"Response: saved embed `{row[3]}`" if row[3] else f"Message: {row[1]}"
        await ctx.send(
            f"Status: {'Enabled' if row[2] else 'Disabled'}\n"
            f"Booster card: {'Enabled' if row[4] else 'Disabled'}\n"
            f"Channel: {channel.mention if channel else 'Unavailable'}\n"
            f"{response}",
            ephemeral=ctx.interaction is not None,
        )

    @boost_group.command(name="config", description="Show boost notification settings")
    async def boost_config(self, ctx):
        await self.boost_show.callback(self, ctx)

    async def _set_boost_enabled(self, ctx, enabled):
        async with self.bot.db.execute(
            "UPDATE boost_settings SET enabled=?, updated_by=?, updated_at=? WHERE guild_id=?",
            (int(enabled), ctx.author.id, utc_now().isoformat(), ctx.guild.id),
        ) as cursor:
            changed = cursor.rowcount
        await self.bot.db.commit()
        if not changed:
            return await ctx.send("Set up a boost channel and message first with `/boost set`.", ephemeral=ctx.interaction is not None)
        await ctx.send(f"Boost notifications {'enabled' if enabled else 'disabled'}.", ephemeral=ctx.interaction is not None)

    @boost_group.command(name="enable", description="Enable boost notifications")
    @commands.has_guild_permissions(manage_guild=True)
    async def boost_enable(self, ctx):
        await self._set_boost_enabled(ctx, True)

    @boost_group.command(name="disable", description="Disable boost notifications")
    @commands.has_guild_permissions(manage_guild=True)
    async def boost_disable(self, ctx):
        await self._set_boost_enabled(ctx, False)

    @boost_group.command(name="reset", description="Remove the server boost message")
    @commands.has_guild_permissions(manage_guild=True)
    async def boost_reset(self, ctx):
        async def reset_boost():
            await self.bot.db.execute("DELETE FROM boost_settings WHERE guild_id=?", (ctx.guild.id,))
            await self.bot.db.commit()

        await self._confirm_destructive_action(
            ctx,
            "Remove this server's boost message configuration?",
            "Boost message configuration removed.",
            reset_boost,
        )

    @boost_group.command(name="test", description="Preview the configured boost message")
    async def boost_test(self, ctx):
        async with self.bot.db.execute(
            "SELECT channel_id, message, embed_name FROM boost_settings WHERE guild_id=?", (ctx.guild.id,)
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return await ctx.send("No boost message is configured.", ephemeral=ctx.interaction is not None)
        channel = ctx.guild.get_channel(row[0])
        if row[2]:
            async with self.bot.db.execute(
                "SELECT config FROM custom_embeds WHERE guild_id=? AND name=?",
                (ctx.guild.id, row[2]),
            ) as cursor:
                embed_row = await cursor.fetchone()
            if embed_row:
                try:
                    preview = build_custom_embed(
                        json.loads(embed_row[0]),
                        ctx.author,
                        ctx.guild,
                        channel or ctx.channel,
                        self.bot.user,
                        {
                            "booster": ctx.author.mention,
                            "boost.user": ctx.author.mention,
                            "boost.count": getattr(ctx.guild, "premium_subscription_count", 0) or 0,
                            "boost.level": getattr(ctx.guild, "premium_tier", 0) or 0,
                        },
                    )
                except (ValueError, TypeError, discord.DiscordException) as error:
                    return await ctx.send(f"Saved boost embed is invalid: {error}", ephemeral=ctx.interaction is not None)
                return await ctx.send(embed=preview, ephemeral=ctx.interaction is not None)
        preview = render_variables(
            row[1],
            ctx.author,
            ctx.guild,
            channel,
            self.bot.user,
            {
                "booster": ctx.author.mention,
                "boost.user": ctx.author.mention,
                "boost.count": getattr(ctx.guild, "premium_subscription_count", 0) or 0,
                "boost.level": getattr(ctx.guild, "premium_tier", 0) or 0,
            },
        )
        await ctx.send(f"Boost message preview:\n{preview}", ephemeral=ctx.interaction is not None)

    @boost_group.command(name="preview", description="Preview the configured boost message")
    async def boost_preview(self, ctx):
        await self.boost_test(ctx)

    @boost_group.command(name="variables", description="List variables available in boost messages")
    async def boost_variables(self, ctx):
        await ctx.send(
            "Available: `{user}`, `{user.mention}`, `{user.name}`, `{user.id}`, `{server}`, "
            "`{server.name}`, `{server.id}`, `{server.member_count}`, `{boost_count}`, "
            "`{boost_level}`, `{booster}`, `{boost.user}`, `{boost.count}`, `{boost.level}`, "
            "`{channel.name}`, `{bot.name}`.",
            ephemeral=ctx.interaction is not None,
        )

    @commands.hybrid_group(name="greet", invoke_without_command=True, case_insensitive=True)
    async def greet_group(self, ctx):
        await ctx.send("Use `/greet setup` to configure join and leave embeds, `/greet card enable|disable`, or `/greet reset`.", ephemeral=ctx.interaction is not None)

    async def save_greeting(self, guild_id, greeting_type, config, user_id):
        column = "join_config" if greeting_type == "join" else "leave_config"
        enabled_column = "join_enabled" if greeting_type == "join" else "leave_enabled"
        serialized_config = json.dumps(config, separators=(",", ":")) if config is not None else None
        await self.bot.db.execute(
            "INSERT INTO greeting_settings "
            "(guild_id, channel_id, updated_by, updated_at, join_config, leave_config, join_enabled, leave_enabled) "
            "VALUES (?, 0, ?, ?, ?, ?, 1, 1) ON CONFLICT(guild_id) DO UPDATE SET "
            f"{column}=excluded.{column}, {enabled_column}=1, "
            "updated_by=excluded.updated_by, updated_at=excluded.updated_at",
            (
                guild_id,
                user_id,
                utc_now().isoformat(),
                serialized_config if greeting_type == "join" else None,
                serialized_config if greeting_type == "leave" else None,
            ),
        )
        await self.bot.db.commit()

    async def open_greeting_embed_editor(self, interaction, greeting_type):
        async with self.bot.db.execute(
            "SELECT join_config, leave_config FROM greeting_settings WHERE guild_id=?",
            (interaction.guild.id,),
        ) as cursor:
            row = await cursor.fetchone()
        config_text = row[0 if greeting_type == "join" else 1] if row else None
        try:
            config = json.loads(config_text) if config_text else DEFAULT_EMBED_CONFIG
        except (TypeError, json.JSONDecodeError):
            config = DEFAULT_EMBED_CONFIG

        async def save_greeting_config(updated_config):
            await self.save_greeting(
                interaction.guild.id,
                greeting_type,
                updated_config,
                interaction.user.id,
            )

        await self._open_embed_editor(
            interaction,
            f"{greeting_type} greeting",
            config,
            owner_id=interaction.user.id,
            save_callback=save_greeting_config,
        )

    @greet_group.command(name="setup", description="Set a greeting channel and configure join/leave embeds")
    @commands.has_guild_permissions(manage_guild=True)
    async def greet_setup(self, ctx, channel: discord.TextChannel):
        await self.bot.db.execute(
            "INSERT INTO greeting_settings (guild_id, channel_id, updated_by, updated_at) "
            "VALUES (?, ?, ?, ?) ON CONFLICT(guild_id) DO UPDATE SET "
            "channel_id=excluded.channel_id, updated_by=excluded.updated_by, updated_at=excluded.updated_at",
            (ctx.guild.id, channel.id, ctx.author.id, utc_now().isoformat()),
        )
        await self.bot.db.commit()
        view = GreetingConfigView(self, ctx.guild.id, ctx.author.id)
        await ctx.send(f"Greeting channel set to {channel.mention}. Configure the join and leave embeds below.", view=view, ephemeral=ctx.interaction is not None)

    @greet_group.command(name="embed", description="Open the join and leave embed builder")
    @commands.has_guild_permissions(manage_guild=True)
    async def greet_embed(self, ctx, channel: discord.TextChannel | None = None):
        if channel is None:
            async with self.bot.db.execute(
                "SELECT channel_id FROM greeting_settings WHERE guild_id=?", (ctx.guild.id,)
            ) as cursor:
                row = await cursor.fetchone()
            channel = ctx.guild.get_channel(row[0]) if row else None
        if channel is None:
            return await ctx.send("Set a greeting channel first with `/greet setup`.", ephemeral=ctx.interaction is not None)
        await self.greet_setup.callback(self, ctx, channel)

    @greet_group.command(name="card", description="Enable or disable join/leave image cards")
    @commands.has_guild_permissions(manage_guild=True)
    async def greet_card(
        self,
        ctx,
        action: Literal["enable", "disable"],
        event: Literal["join", "leave", "both"] = "both",
    ):
        async with self.bot.db.execute(
            "SELECT channel_id FROM greeting_settings WHERE guild_id=?",
            (ctx.guild.id,),
        ) as cursor:
            settings = await cursor.fetchone()
        if action == "enable" and (not settings or not settings[0]):
            return await ctx.send("Set up a greeting channel first with `/greet setup`.", ephemeral=ctx.interaction is not None)
        events = ("join", "leave") if event == "both" else (event,)
        for event_name in events:
            await self.bot.db.execute(
                f"UPDATE greeting_settings SET {event_name}_card_enabled=? WHERE guild_id=?",
                (int(action == "enable"), ctx.guild.id),
            )
        await self.bot.db.commit()
        await ctx.send(
            f"{event.title()} greeting card(s) {action}d.",
            ephemeral=ctx.interaction is not None,
        )

    @greet_group.command(name="reset", description="Remove custom greeting configuration")
    @commands.has_guild_permissions(manage_guild=True)
    async def greet_reset(self, ctx):
        async def reset_greetings():
            await self.bot.db.execute("DELETE FROM greeting_settings WHERE guild_id=?", (ctx.guild.id,))
            await self.bot.db.execute("DELETE FROM greet_channels WHERE guild_id=?", (ctx.guild.id,))
            await self.bot.db.execute(
                "UPDATE guild_settings SET join_channel_id=NULL, leave_channel_id=NULL, "
                "join_message=NULL, leave_message=NULL, vanity_message=NULL WHERE guild_id=?",
                (ctx.guild.id,),
            )
            await self.bot.db.commit()

        await self._confirm_destructive_action(
            ctx,
            "Remove all join, leave, and vanity greeting configuration for this server?",
            "All greeting configuration removed.",
            reset_greetings,
        )

    @greet_group.command(name="channel", description="Set the text greeting channel for join or leave events")
    @commands.has_guild_permissions(manage_guild=True)
    async def greet_channel(self, ctx, event: str, channel: discord.TextChannel):
        event = event.casefold().strip()
        column = GREETING_CHANNEL_COLUMNS.get(event)
        if column is None:
            return await ctx.send("Event must be `join` or `leave`.", ephemeral=ctx.interaction is not None)
        await self.bot.db.execute(
            f"INSERT INTO guild_settings (guild_id, {column}, {event}_enabled) VALUES (?, ?, 1) "
            f"ON CONFLICT(guild_id) DO UPDATE SET {column}=excluded.{column}, {event}_enabled=1",
            (ctx.guild.id, channel.id),
        )
        await self.bot.db.commit()
        await ctx.send(f"{event.title()} messages will be sent to {channel.mention}.", ephemeral=ctx.interaction is not None)

    @greet_group.command(name="message", description="Set a text greeting message")
    @commands.has_guild_permissions(manage_guild=True)
    async def greet_message(self, ctx, event: str, *, message: str):
        event = event.casefold().strip()
        column = GREETING_MESSAGE_COLUMNS.get(event)
        if column is None:
            return await ctx.send("Event must be `join`, `leave`, or `vanity`.", ephemeral=ctx.interaction is not None)
        enabled_event = "join" if event == "vanity" else event
        message = message.strip()
        if not message or len(message) > 2000:
            return await ctx.send("Greeting messages must contain 1 to 2000 characters.", ephemeral=ctx.interaction is not None)
        await self.bot.db.execute(
            f"INSERT INTO guild_settings (guild_id, {column}, {enabled_event}_enabled) VALUES (?, ?, 1) "
            f"ON CONFLICT(guild_id) DO UPDATE SET {column}=excluded.{column}, {enabled_event}_enabled=1",
            (ctx.guild.id, message),
        )
        await self.bot.db.commit()
        await ctx.send(f"{event.title()} message updated.", ephemeral=ctx.interaction is not None)

    @greet_group.command(name="clear", description="Clear a text greeting message")
    @commands.has_guild_permissions(manage_guild=True)
    async def greet_clear(self, ctx, event: str):
        event = event.casefold().strip()
        column = GREETING_MESSAGE_COLUMNS.get(event)
        if column is None:
            return await ctx.send("Event must be `join`, `leave`, or `vanity`.", ephemeral=ctx.interaction is not None)
        await self.bot.db.execute(
            f"UPDATE guild_settings SET {column}=NULL WHERE guild_id=?", (ctx.guild.id,)
        )
        await self.bot.db.commit()
        await ctx.send(f"{event.title()} message cleared.", ephemeral=ctx.interaction is not None)

    @greet_group.command(name="disable", description="Disable join, leave, or all greetings")
    @commands.has_guild_permissions(manage_guild=True)
    async def greet_disable(self, ctx, event: Literal["join", "leave", "both"] = "both"):
        events = ("join", "leave") if event == "both" else (event,)
        for item in events:
            await self.bot.db.execute(
                f"INSERT INTO guild_settings (guild_id, {item}_enabled) VALUES (?, 0) "
                f"ON CONFLICT(guild_id) DO UPDATE SET {item}_enabled=0",
                (ctx.guild.id,),
            )
            await self.bot.db.execute(
                f"UPDATE greeting_settings SET {item}_enabled=0 WHERE guild_id=?",
                (ctx.guild.id,),
            )
        await self.bot.db.commit()
        await ctx.send(f"{event.title()} greeting(s) disabled.", ephemeral=ctx.interaction is not None)

    @greet_group.command(name="enable", description="Enable join, leave, or all greetings")
    @commands.has_guild_permissions(manage_guild=True)
    async def greet_enable(self, ctx, event: Literal["join", "leave", "both"] = "both"):
        events = ("join", "leave") if event == "both" else (event,)
        for item in events:
            await self.bot.db.execute(
                f"INSERT INTO guild_settings (guild_id, {item}_enabled) VALUES (?, 1) "
                f"ON CONFLICT(guild_id) DO UPDATE SET {item}_enabled=1",
                (ctx.guild.id,),
            )
            await self.bot.db.execute(
                f"UPDATE greeting_settings SET {item}_enabled=1 WHERE guild_id=?",
                (ctx.guild.id,),
            )
        await self.bot.db.commit()
        await ctx.send(f"{event.title()} greeting(s) enabled.", ephemeral=ctx.interaction is not None)

    @greet_group.command(name="test", description="Preview a text greeting message")
    async def greet_test(self, ctx, event: str):
        event = event.casefold().strip()
        if event not in GREETING_MESSAGE_COLUMNS:
            return await ctx.send("Event must be `join`, `leave`, or `vanity`.", ephemeral=ctx.interaction is not None)
        async with self.bot.db.execute(
            "SELECT join_message, leave_message, vanity_message FROM guild_settings WHERE guild_id=?",
            (ctx.guild.id,),
        ) as cursor:
            row = await cursor.fetchone()
        columns = {"join": 0, "leave": 1, "vanity": 2}
        message = row[columns[event]] if row else None
        if event == "vanity" and not message and row:
            message = row[0]
        if not message:
            async with self.bot.db.execute(
                "SELECT channel_id, join_config, leave_config FROM greeting_settings WHERE guild_id=?",
                (ctx.guild.id,),
            ) as cursor:
                embed_row = await cursor.fetchone()
            config_text = embed_row[2] if event == "leave" and embed_row else (embed_row[1] if embed_row else None)
            if not config_text:
                return await ctx.send(f"No {event} message or embed is configured.", ephemeral=ctx.interaction is not None)
            channel = ctx.guild.get_channel(embed_row[0]) or ctx.channel
            try:
                preview_embed = build_custom_embed(
                    json.loads(config_text),
                    ctx.author,
                    ctx.guild,
                    channel,
                    self.bot.user,
                    {"inviter": "Unknown", "inviter.name": "Unknown", "inviter.id": ""},
                )
            except (ValueError, TypeError, discord.DiscordException) as error:
                return await ctx.send(f"Saved {event} embed is invalid: {error}", ephemeral=ctx.interaction is not None)
            return await ctx.send(embed=preview_embed, allowed_mentions=discord.AllowedMentions.none())
        preview = render_variables(
            message,
            ctx.author,
            ctx.guild,
            ctx.channel,
            self.bot.user,
            {"inviter": "Unknown", "inviter.name": "Unknown", "inviter.id": ""},
        )
        await ctx.send(preview[:2000], ephemeral=ctx.interaction is not None, allowed_mentions=discord.AllowedMentions.none())

    @greet_group.command(name="variables", description="List variables available in greetings")
    async def greet_variables(self, ctx):
        await ctx.send(
            "Available: `{user}`, `{user.mention}`, `{user.name}`, `{user.id}`, `{user.avatar}`, "
            "`{server}`, `{server.name}`, `{server.id}`, `{server.member_count}`, `{channel.name}`, "
            "`{inviter}`, `{inviter.name}`, `{boost_count}`.",
            ephemeral=ctx.interaction is not None,
        )

    @greet_group.command(name="show", description="Show this server's greeting configuration")
    async def greet_show(self, ctx):
        async with self.bot.db.execute(
            "SELECT channel_id, join_config, leave_config, join_enabled, leave_enabled, "
            "join_card_enabled, leave_card_enabled "
            "FROM greeting_settings WHERE guild_id=?",
            (ctx.guild.id,),
        ) as cursor:
            row = await cursor.fetchone()
        async with self.bot.db.execute(
            "SELECT join_channel_id, leave_channel_id, join_message, leave_message, vanity_message "
            "FROM guild_settings WHERE guild_id=?",
            (ctx.guild.id,),
        ) as cursor:
            text_settings = await cursor.fetchone()
        async with self.bot.db.execute(
            "SELECT channel_id, greet_type FROM greet_channels WHERE guild_id=? ORDER BY channel_id",
            (ctx.guild.id,),
        ) as cursor:
            channel_settings = await cursor.fetchall()
        if not row and not text_settings and not channel_settings:
            return await ctx.send("No custom greetings are configured.", ephemeral=ctx.interaction is not None)
        embed = discord.Embed(title="Greeting Configuration", color=0xFFDD00)
        if row:
            channel = ctx.guild.get_channel(row[0])
            embed.add_field(name="Embed channel", value=channel.mention if channel else "Unavailable", inline=False)
            embed.add_field(name="Join embed", value="Configured" if row[1] else "Not configured", inline=True)
            embed.add_field(name="Leave embed", value="Configured" if row[2] else "Not configured", inline=True)
            embed.add_field(name="Join card", value="Enabled" if row[5] else "Disabled", inline=True)
            embed.add_field(name="Leave card", value="Enabled" if row[6] else "Disabled", inline=True)
        if text_settings:
            join_channel = ctx.guild.get_channel(text_settings[0]) if text_settings[0] else None
            leave_channel = ctx.guild.get_channel(text_settings[1]) if text_settings[1] else None
            embed.add_field(
                name="Text greetings",
                value=(
                    f"Join: {join_channel.mention if join_channel else 'Off'} | {'set' if text_settings[2] else 'default'}\n"
                    f"Leave: {leave_channel.mention if leave_channel else 'Off'} | {'set' if text_settings[3] else 'default'}\n"
                    f"Vanity message: {'set' if text_settings[4] else 'Off'}"
                ),
                inline=False,
            )
        if channel_settings:
            lines = []
            for channel_id, greet_type in channel_settings:
                channel = ctx.guild.get_channel(channel_id)
                lines.append(f"{channel.mention if channel else f'Unavailable ({channel_id})'}: {greet_type}")
            embed.add_field(name="Additional greet channels", value="\n".join(lines), inline=False)
        await ctx.send(embed=embed, ephemeral=ctx.interaction is not None)

    @greet_group.command(name="preview", description="Preview the configured join, leave, or vanity greeting")
    async def greet_preview(self, ctx, event: str = "join"):
        await self.greet_test.callback(self, ctx, event)

    @greet_group.command(name="config", description="Show this server's greeting configuration")
    async def greet_config(self, ctx):
        await self.greet_show.callback(self, ctx)

    @commands.hybrid_group(name="leave", invoke_without_command=True, case_insensitive=True)
    async def leave_group(self, ctx):
        await ctx.send(
            "Use `/leave setup`, `/leave enable`, `/leave disable`, `/leave channel`, "
            "`/leave message`, `/leave test`, `/leave config`, or `/leave reset`.",
            ephemeral=ctx.interaction is not None,
        )

    @leave_group.command(name="setup", description="Set the leave channel and configure its embed")
    @commands.has_guild_permissions(manage_guild=True)
    async def leave_setup(self, ctx, channel: discord.TextChannel):
        await self.bot.db.execute(
            "INSERT INTO guild_settings (guild_id, leave_channel_id, leave_enabled) VALUES (?, ?, 1) "
            "ON CONFLICT(guild_id) DO UPDATE SET leave_channel_id=excluded.leave_channel_id, leave_enabled=1",
            (ctx.guild.id, channel.id),
        )
        await self.bot.db.commit()
        await self.bot.db.execute(
            "INSERT INTO greeting_settings "
            "(guild_id, channel_id, updated_by, updated_at, join_enabled, leave_enabled) "
            "VALUES (?, ?, ?, ?, 1, 1) ON CONFLICT(guild_id) DO UPDATE SET "
            "channel_id=excluded.channel_id, leave_enabled=1, updated_by=excluded.updated_by, "
            "updated_at=excluded.updated_at",
            (ctx.guild.id, channel.id, ctx.author.id, utc_now().isoformat()),
        )
        await self.bot.db.commit()
        view = GreetingConfigView(self, ctx.guild.id, ctx.author.id)
        await ctx.send(
            f"Leave channel set to {channel.mention}. Configure the leave embed below.",
            view=view,
            ephemeral=ctx.interaction is not None,
        )

    @leave_group.command(name="enable", description="Enable leave notifications")
    @commands.has_guild_permissions(manage_guild=True)
    async def leave_enable(self, ctx):
        async with self.bot.db.execute(
            "SELECT leave_channel_id FROM guild_settings WHERE guild_id=?", (ctx.guild.id,)
        ) as cursor:
            row = await cursor.fetchone()
        if not row or not row[0]:
            return await ctx.send("Set a leave channel first with `/leave setup`.", ephemeral=ctx.interaction is not None)
        await self.bot.db.execute(
            "UPDATE guild_settings SET leave_enabled=1 WHERE guild_id=?", (ctx.guild.id,)
        )
        await self.bot.db.execute(
            "UPDATE greeting_settings SET leave_enabled=1 WHERE guild_id=?", (ctx.guild.id,)
        )
        await self.bot.db.commit()
        await ctx.send("Leave notifications enabled.", ephemeral=ctx.interaction is not None)

    @leave_group.command(name="disable", description="Disable leave notifications")
    @commands.has_guild_permissions(manage_guild=True)
    async def leave_disable(self, ctx):
        await self.bot.db.execute(
            "INSERT INTO guild_settings (guild_id, leave_enabled) VALUES (?, 0) "
            "ON CONFLICT(guild_id) DO UPDATE SET leave_enabled=0",
            (ctx.guild.id,),
        )
        await self.bot.db.execute(
            "UPDATE greeting_settings SET leave_enabled=0 WHERE guild_id=?", (ctx.guild.id,)
        )
        await self.bot.db.commit()
        await ctx.send("Leave notifications disabled.", ephemeral=ctx.interaction is not None)

    @leave_group.command(name="channel", description="Set the leave notification channel")
    @commands.has_guild_permissions(manage_guild=True)
    async def leave_channel(self, ctx, channel: discord.TextChannel):
        await self.bot.db.execute(
            "INSERT INTO guild_settings (guild_id, leave_channel_id, leave_enabled) VALUES (?, ?, 1) "
            "ON CONFLICT(guild_id) DO UPDATE SET leave_channel_id=excluded.leave_channel_id, leave_enabled=1",
            (ctx.guild.id, channel.id),
        )
        await self.bot.db.execute(
            "INSERT INTO greeting_settings "
            "(guild_id, channel_id, updated_by, updated_at, leave_enabled) VALUES (?, ?, ?, ?, 1) "
            "ON CONFLICT(guild_id) DO UPDATE SET channel_id=excluded.channel_id, leave_enabled=1, "
            "updated_by=excluded.updated_by, updated_at=excluded.updated_at",
            (ctx.guild.id, channel.id, ctx.author.id, utc_now().isoformat()),
        )
        await self.bot.db.commit()
        await ctx.send(f"Leave notifications will be sent to {channel.mention}.", ephemeral=ctx.interaction is not None)

    @leave_group.command(name="message", description="Set the leave text message")
    @commands.has_guild_permissions(manage_guild=True)
    async def leave_message(self, ctx, *, message: str):
        message = message.strip()
        if not message or len(message) > 2000:
            return await ctx.send("Leave messages must contain 1 to 2000 characters.", ephemeral=ctx.interaction is not None)
        await self.bot.db.execute(
            "INSERT INTO guild_settings (guild_id, leave_message, leave_enabled) VALUES (?, ?, 1) "
            "ON CONFLICT(guild_id) DO UPDATE SET leave_message=excluded.leave_message, leave_enabled=1",
            (ctx.guild.id, message),
        )
        await self.bot.db.commit()
        await ctx.send("Leave message updated.", ephemeral=ctx.interaction is not None)

    @leave_group.command(name="embed", description="Open the greeting embed builder for leave messages")
    @commands.has_guild_permissions(manage_guild=True)
    async def leave_embed(self, ctx, channel: discord.TextChannel = None):
        channel = channel or ctx.guild.get_channel(
            await self._guild_leave_channel_id(ctx.guild.id)
        ) or ctx.channel
        await self.leave_setup(ctx, channel)

    async def _guild_leave_channel_id(self, guild_id):
        async with self.bot.db.execute(
            "SELECT leave_channel_id FROM guild_settings WHERE guild_id=?", (guild_id,)
        ) as cursor:
            row = await cursor.fetchone()
        return row[0] if row else None

    @leave_group.command(name="test", description="Preview the leave notification")
    async def leave_test(self, ctx):
        await self._send_leave_preview(ctx, deliver=False)

    @leave_group.command(name="preview", description="Preview the configured leave message or embed")
    async def leave_preview(self, ctx):
        await self._send_leave_preview(ctx, deliver=False)

    async def _send_leave_preview(self, ctx, *, deliver):
        async with self.bot.db.execute(
            "SELECT leave_message FROM guild_settings WHERE guild_id=?", (ctx.guild.id,)
        ) as cursor:
            text_row = await cursor.fetchone()
        if text_row and text_row[0]:
            preview = render_variables(
                text_row[0], ctx.author, ctx.guild, ctx.channel, self.bot.user
            )
            await ctx.send(preview[:2000], allowed_mentions=discord.AllowedMentions.none())
            return
        async with self.bot.db.execute(
            "SELECT leave_config FROM greeting_settings WHERE guild_id=?", (ctx.guild.id,)
        ) as cursor:
            embed_row = await cursor.fetchone()
        if embed_row and embed_row[0]:
            try:
                embed = build_custom_embed(
                    json.loads(embed_row[0]), ctx.author, ctx.guild, ctx.channel, self.bot.user
                )
            except (ValueError, TypeError, discord.DiscordException) as error:
                return await ctx.send(f"Saved leave embed is invalid: {error}")
            await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())
            return
        await ctx.send("No leave message or embed is configured. Use `/leave setup`.")

    @leave_group.command(name="config", description="Show leave notification settings")
    async def leave_config(self, ctx):
        async with self.bot.db.execute(
            "SELECT leave_channel_id, leave_message, leave_enabled FROM guild_settings WHERE guild_id=?",
            (ctx.guild.id,),
        ) as cursor:
            text_config = await cursor.fetchone()
        async with self.bot.db.execute(
            "SELECT channel_id, leave_config, leave_enabled FROM greeting_settings WHERE guild_id=?",
            (ctx.guild.id,),
        ) as cursor:
            embed_config = await cursor.fetchone()
        channel_id = text_config[0] if text_config and text_config[0] else (embed_config[0] if embed_config else None)
        channel = ctx.guild.get_channel(channel_id) if channel_id else None
        enabled = bool(text_config and text_config[2]) or bool(embed_config and embed_config[2])
        embed = discord.Embed(title="Leave Configuration", color=0xFFDD00)
        embed.add_field(name="Status", value="Enabled" if enabled else "Disabled", inline=True)
        embed.add_field(name="Channel", value=channel.mention if channel else "Not configured", inline=True)
        embed.add_field(name="Text", value="Configured" if text_config and text_config[1] else "Not configured", inline=True)
        embed.add_field(name="Embed", value="Configured" if embed_config and embed_config[1] else "Not configured", inline=True)
        await ctx.send(embed=embed)

    @leave_group.command(name="reset", description="Reset leave notification configuration")
    @commands.has_guild_permissions(manage_guild=True)
    async def leave_reset(self, ctx):
        async def reset_leave():
            await self.bot.db.execute(
                "UPDATE guild_settings SET leave_channel_id=NULL, leave_message=NULL, leave_enabled=0 WHERE guild_id=?",
                (ctx.guild.id,),
            )
            await self.bot.db.execute(
                "UPDATE greeting_settings SET leave_config=NULL, leave_enabled=0 WHERE guild_id=?",
                (ctx.guild.id,),
            )
            await self.bot.db.commit()

        await self._confirm_destructive_action(
            ctx,
            "Reset all leave notification settings for this server?",
            "Leave notification settings reset.",
            reset_leave,
        )

    @commands.hybrid_group(name="config", invoke_without_command=True, case_insensitive=True)
    async def config_group(self, ctx):
        await self._send_feature_config(ctx)

    async def _send_feature_config(self, ctx, section=None):
        guild_id = ctx.guild.id
        embed = discord.Embed(title="Falcon Server Configuration", color=0xFFDD00)
        if section in (None, "greet", "leave"):
            async with self.bot.db.execute(
                "SELECT join_channel_id, leave_channel_id, join_enabled, leave_enabled "
                "FROM guild_settings WHERE guild_id=?",
                (guild_id,),
            ) as cursor:
                greeting = await cursor.fetchone()
            async with self.bot.db.execute(
                "SELECT join_config, leave_config FROM greeting_settings WHERE guild_id=?",
                (guild_id,),
            ) as cursor:
                greeting_embeds = await cursor.fetchone()
            if section in (None, "greet"):
                join_channel = ctx.guild.get_channel(greeting[0]) if greeting and greeting[0] else None
                embed.add_field(
                    name="Greet",
                    value=(
                        f"Status: {'Enabled' if not greeting or greeting[2] else 'Disabled'}\n"
                        f"Channel: {join_channel.mention if join_channel else 'Not configured'}\n"
                        f"Embed: {'Configured' if greeting_embeds and greeting_embeds[0] else 'Not configured'}"
                    ),
                    inline=True,
                )
            if section in (None, "leave"):
                leave_channel = ctx.guild.get_channel(greeting[1]) if greeting and greeting[1] else None
                embed.add_field(
                    name="Leave",
                    value=(
                        f"Status: {'Enabled' if not greeting or greeting[3] else 'Disabled'}\n"
                        f"Channel: {leave_channel.mention if leave_channel else 'Not configured'}\n"
                        f"Embed: {'Configured' if greeting_embeds and greeting_embeds[1] else 'Not configured'}"
                    ),
                    inline=True,
                )
        if section in (None, "boost"):
            async with self.bot.db.execute(
                "SELECT channel_id, enabled FROM boost_settings WHERE guild_id=?", (guild_id,)
            ) as cursor:
                boost = await cursor.fetchone()
            channel = ctx.guild.get_channel(boost[0]) if boost else None
            embed.add_field(
                name="Boost",
                value=f"Status: {'Enabled' if boost and boost[1] else 'Disabled'}\nChannel: {channel.mention if channel else 'Not configured'}",
                inline=True,
            )
        if section in (None, "autoresponder", "autoresponders"):
            async with self.bot.db.execute(
                "SELECT COUNT(*), COALESCE(SUM(enabled), 0) FROM autoresponders WHERE guild_id=?",
                (guild_id,),
            ) as cursor:
                total, enabled = await cursor.fetchone()
            embed.add_field(name="Autoresponders", value=f"{enabled} enabled / {total} total", inline=True)
        if section in (None, "customcommands", "customcommand"):
            async with self.bot.db.execute(
                "SELECT COUNT(*), COALESCE(SUM(enabled), 0) FROM custom_commands WHERE guild_id=?",
                (guild_id,),
            ) as cursor:
                total, enabled = await cursor.fetchone()
            embed.add_field(name="Custom Commands", value=f"{enabled} enabled / {total} total", inline=True)
        if section in (None, "embeds"):
            async with self.bot.db.execute(
                "SELECT COUNT(*) FROM custom_embeds WHERE guild_id=?", (guild_id,)
            ) as cursor:
                count = (await cursor.fetchone())[0]
            embed.add_field(name="Saved Embeds", value=str(count), inline=True)
        await ctx.send(embed=embed)

    @config_group.command(name="greet", description="Show greet configuration")
    async def config_greet(self, ctx):
        await self._send_feature_config(ctx, "greet")

    @config_group.command(name="leave", description="Show leave configuration")
    async def config_leave(self, ctx):
        await self._send_feature_config(ctx, "leave")

    @config_group.command(name="boost", description="Show boost configuration")
    async def config_boost(self, ctx):
        await self._send_feature_config(ctx, "boost")

    @config_group.command(name="autoresponder", description="Show autoresponder configuration")
    async def config_autoresponder(self, ctx):
        await self._send_feature_config(ctx, "autoresponder")

    @config_group.command(name="customcommands", description="Show custom command configuration")
    async def config_customcommands(self, ctx):
        await self._send_feature_config(ctx, "customcommands")

    @config_group.command(name="embeds", description="Show saved embed configuration")
    async def config_embeds(self, ctx):
        await self._send_feature_config(ctx, "embeds")

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.guild is None or message.author.bot or message.webhook_id:
            return
        if (await self.bot.get_context(message)).valid:
            return
        content = message.content.casefold()
        if not content:
            return

        prefixes = await self.bot.get_prefix(message)
        if isinstance(prefixes, str):
            prefixes = [prefixes]
        for prefix in sorted((prefix for prefix in prefixes if prefix), key=len, reverse=True):
            if not message.content.startswith(prefix):
                continue
            command_text = message.content[len(prefix):].strip()
            name = command_text.split(maxsplit=1)[0].casefold() if command_text else ""
            if name:
                async with self.bot.db.execute(
                    "SELECT response, role_id, channel_id, cooldown, enabled FROM custom_commands "
                    "WHERE guild_id=? AND name=?",
                    (message.guild.id, name),
                ) as cursor:
                    custom_command = await cursor.fetchone()
                if custom_command:
                    response, role_id, channel_id, cooldown, enabled = custom_command
                    if not enabled:
                        return
                    if (channel_id is None or channel_id == message.channel.id) and (
                        role_id is None or any(role.id == role_id for role in message.author.roles)
                    ):
                        if self._response_cooldown_ready(
                            ("custom", message.guild.id, name, message.author.id), cooldown
                        ):
                            raw_args = command_text[len(name):].strip()
                            try:
                                args = shlex.split(raw_args)
                            except ValueError:
                                args = raw_args.split()
                            await self._send_automated_response(
                                message,
                                response,
                                extra_values={"args": " ".join(args)},
                                command_args=args,
                            )
                    return
            break

        async with self.bot.db.execute(
            "SELECT trigger, response, mode, channel_id, role_id, cooldown, excluded_channel_ids, "
            "allowed_role_ids, excluded_role_ids, cooldown_scope, case_sensitive FROM autoresponders "
            "WHERE guild_id=? AND enabled=1 ORDER BY LENGTH(trigger) DESC",
            (message.guild.id,),
        ) as cursor:
            rows = await cursor.fetchall()
        for trigger, response, mode, channel_id, role_id, cooldown, excluded_channels, allowed_roles, excluded_roles, cooldown_scope, case_sensitive in rows:
            if not _matches_autoresponder_trigger(
                message.content,
                trigger,
                mode,
                case_sensitive=bool(case_sensitive),
            ):
                continue
            if channel_id is not None and channel_id != message.channel.id:
                continue
            try:
                blocked_channels = {int(item) for item in json.loads(excluded_channels or "[]")}
                allowed_role_set = {int(item) for item in json.loads(allowed_roles or "[]")}
                excluded_role_set = {int(item) for item in json.loads(excluded_roles or "[]")}
            except (TypeError, ValueError, json.JSONDecodeError):
                print(f"[community] Invalid restriction data for autoresponder {trigger!r} in guild {message.guild.id}.")
                continue
            if message.channel.id in blocked_channels:
                continue
            author_roles = {role.id for role in message.author.roles}
            admin_bypass = message.author.guild_permissions.administrator
            if not admin_bypass and role_id is not None:
                allowed_role_set.add(role_id)
            if not admin_bypass and allowed_role_set and not author_roles.intersection(allowed_role_set):
                continue
            if not admin_bypass and author_roles.intersection(excluded_role_set):
                continue
            cooldown_key = ("autoresponder", message.guild.id, trigger)
            if cooldown_scope == "channel":
                cooldown_key += (message.channel.id,)
            elif cooldown_scope != "global":
                cooldown_key += (message.author.id,)
            if not self._response_cooldown_ready(
                cooldown_key, cooldown
            ):
                continue
            arguments = _autoresponder_arguments(
                message.content,
                trigger,
                mode,
                case_sensitive=bool(case_sensitive),
            )
            await self._send_automated_response(
                message,
                response,
                extra_values={
                    "message": message.content,
                    "message.content": message.content,
                    "args": " ".join(arguments),
                },
                command_args=arguments,
            )
            return

    def _response_cooldown_ready(self, key, cooldown):
        now = asyncio.get_running_loop().time()
        last_used = self._response_cooldowns.get(key)
        if cooldown and last_used is not None and now < last_used[1]:
            return False
        if cooldown:
            self._response_cooldowns[key] = (now, now + cooldown)
        self._cooldown_checks += 1
        if self._cooldown_checks % 128 == 0:
            self._response_cooldowns = {
                entry: timestamps
                for entry, timestamps in self._response_cooldowns.items()
                if now < timestamps[1]
            }
        return True

    async def _send_automated_response(
        self,
        message,
        response,
        *,
        allow_delete=True,
        channel=None,
        user=None,
        guild=None,
        extra_values=None,
        command_args=None,
    ):
        user = user or getattr(message, "author", None)
        guild = guild or getattr(message, "guild", None)
        source_channel = channel or getattr(message, "channel", None)
        if user is None or guild is None or source_channel is None:
            return False

        actions = AUTORESPONDER_ACTION_PATTERN.findall(response)
        delete_source = allow_delete and any(action.casefold() == "delete" for action in actions)
        destination = source_channel
        embed_name = None
        for action in actions:
            action = action.strip()
            if action.casefold() == "delete":
                continue
            action_type, _, value = action.partition(":")
            value = value.strip()
            if action_type.casefold() == "sendto":
                channel_id = value.strip("<#>")
                if not channel_id.isdecimal():
                    print(f"[community] Invalid sendto channel in automated response for guild {guild.id}.")
                    return False
                target = guild.get_channel_or_thread(int(channel_id))
                if target is None or not hasattr(target, "send"):
                    print(f"[community] sendto channel {channel_id} is unavailable in guild {guild.id}.")
                    return False
                bot_member = guild.me or guild.get_member(self.bot.user.id)
                if bot_member is None:
                    return False
                permissions = target.permissions_for(bot_member)
                if not permissions.view_channel or not permissions.send_messages:
                    print(f"[community] Missing view/send permission for sendto channel {channel_id} in guild {guild.id}.")
                    return False
                destination = target
            elif action_type.casefold() == "embed":
                embed_name = value.casefold()
        rendered = AUTORESPONDER_ACTION_PATTERN.sub("", response).strip()
        rendered = render_variables(
            rendered,
            user,
            guild,
            source_channel,
            self.bot.user,
            extra_values,
        )
        if command_args is not None:
            arguments = list(command_args)

            def substitute_argument(match):
                index = int(match.group(1)) - 1
                if match.group(2):
                    return " ".join(arguments[index:]) if 0 <= index < len(arguments) else ""
                return arguments[index] if 0 <= index < len(arguments) else ""

            rendered = re.sub(r"\$(\d+)(\+?)", substitute_argument, rendered)
        embed = None
        if embed_name:
            async with self.bot.db.execute(
                "SELECT config FROM custom_embeds WHERE guild_id=? AND name=?",
                (guild.id, embed_name),
            ) as cursor:
                saved_embed = await cursor.fetchone()
            if not saved_embed:
                print(f"[community] Automated response references missing embed {embed_name!r} in guild {guild.id}.")
                return False
            try:
                embed = build_custom_embed(
                    json.loads(saved_embed[0]), user, guild, source_channel, self.bot.user, extra_values
                )
            except (ValueError, TypeError, discord.DiscordException) as error:
                print(f"[community] Invalid saved embed {embed_name!r} for guild {guild.id}: {error}")
                return False
        bot_member = guild.me or guild.get_member(self.bot.user.id)
        if bot_member is None:
            return False
        permissions = destination.permissions_for(bot_member)
        if not permissions.view_channel or not permissions.send_messages:
            print(f"[community] Missing view/send permission in response channel for guild {guild.id}.")
            return False
        if embed is not None and not permissions.embed_links:
            print(f"[community] Missing embed links permission in response channel for guild {guild.id}.")
            return False
        try:
            if rendered or embed is not None:
                await send_v2(
                    destination,
                    rendered[:2000] if rendered else None,
                    embed=embed,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
            if delete_source and hasattr(message, "delete"):
                await message.delete(reason="Automated response requested message deletion")
        except discord.HTTPException as error:
            print(f"[community] Failed to send automated response in guild {guild.id}: {error}")
            return False
        return True

    async def _build_member_event_card(self, member, event_kind, detail):
        timeout = aiohttp.ClientTimeout(total=15, connect=5, sock_read=10)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            avatar_bytes = await self._download_avatar(session, member)
            guild_icon_bytes = None
            if member.guild.icon:
                icon_url = member.guild.icon.replace(format="png", size=128).url
                async with session.get(icon_url) as response:
                    if response.status == 200:
                        guild_icon_bytes = await response.read()
            card_bytes = await asyncio.to_thread(
                render_member_event_card,
                avatar_bytes,
                member.display_name,
                member.guild.name,
                event_kind,
                detail,
                guild_icon_bytes=guild_icon_bytes,
            )
        return discord.File(
            io.BytesIO(card_bytes),
            filename=f"falcon-{event_kind}-{member.id}.png",
        )

    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if before.premium_since is not None or after.premium_since is None:
            return
        async with self.bot.db.execute(
            "SELECT channel_id, message, enabled, embed_name, card_enabled "
            "FROM boost_settings WHERE guild_id=?",
            (after.guild.id,),
        ) as cursor:
            row = await cursor.fetchone()
        if not row or not row[2]:
            return
        channel = after.guild.get_channel(row[0])
        if channel is None:
            return
        subscription_count = getattr(after.guild, "premium_subscription_count", 0) or 0
        boost_level = getattr(after.guild, "premium_tier", 0) or 0
        extra_values = {
            "booster": after.mention,
            "boost.user": after.mention,
            "boost.count": subscription_count,
            "boost_count": subscription_count,
            "boost.level": boost_level,
        }
        if row[4]:
            try:
                card = await self._build_member_event_card(
                    after,
                    "boost",
                    f"LEVEL {boost_level}  •  BOOST #{subscription_count}",
                )
                card_embed = discord.Embed(color=0xB58CFF)
                card_embed.set_image(url=f"attachment://{card.filename}")
                await send_v2(
                    channel,
                    f"Thank you {after.mention} for boosting **{after.guild.name}**!",
                    embed=card_embed,
                    file=card,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
                return
            except (aiohttp.ClientError, asyncio.TimeoutError, OSError, ValueError, discord.HTTPException) as error:
                print(f"[boost] Card generation failed for member {after.id} in guild {after.guild.id}: {error}")
        embed = None
        if row[3]:
            async with self.bot.db.execute(
                "SELECT config FROM custom_embeds WHERE guild_id=? AND name=?",
                (after.guild.id, row[3]),
            ) as cursor:
                embed_row = await cursor.fetchone()
            if embed_row:
                try:
                    embed = build_custom_embed(
                        json.loads(embed_row[0]), after, after.guild, channel, self.bot.user, extra_values
                    )
                except (ValueError, TypeError, discord.DiscordException) as error:
                    print(f"[boost] Invalid saved embed {row[3]!r} for guild {after.guild.id}: {error}")
        rendered = render_variables(row[1], after, after.guild, channel, self.bot.user, extra_values)
        try:
            await send_v2(
                channel,
                None if embed else rendered[:2000],
                embed=embed,
                allowed_mentions=discord.AllowedMentions.none(),
            )
        except discord.HTTPException:
            pass

    @staticmethod
    def _format_tag_duration(seconds):
        for unit_seconds, unit_name in (
            (604800, "week"),
            (86400, "day"),
            (3600, "hour"),
            (60, "minute"),
            (1, "second"),
        ):
            if seconds % unit_seconds == 0:
                amount = seconds // unit_seconds
                return f"{amount} {unit_name}{'' if amount == 1 else 's'}"
        return f"{seconds} seconds"

    async def _build_tag_setup_embed(self, guild):
        async with self.bot.db.execute(
            "SELECT delete_after_seconds, enabled FROM tag_settings WHERE guild_id=?", (guild.id,)
        ) as cursor:
            settings = await cursor.fetchone()
        async with self.bot.db.execute(
            "SELECT channel_id FROM tag_channels WHERE guild_id=? ORDER BY channel_id", (guild.id,)
        ) as cursor:
            channel_ids = [row[0] for row in await cursor.fetchall()]

        embed = discord.Embed(title="Join Tag Setup", color=0xFFDD00)
        channel_mentions = [f"<#{channel_id}>" for channel_id in channel_ids]
        channel_value = ", ".join(channel_mentions) if channel_mentions else "No channels added"
        if len(channel_value) > 1024:
            channel_value = channel_value[:1000].rsplit(", ", 1)[0] + ", and more"
        embed.add_field(name=f"Channels ({len(channel_ids)})", value=channel_value, inline=False)
        delete_after = settings[0] if settings else None
        duration_value = self._format_tag_duration(delete_after) if delete_after else "Not set"
        embed.add_field(name="Delete after", value=duration_value, inline=False)
        enabled = bool(settings and settings[1])
        embed.add_field(name="Status", value="Enabled" if enabled else "Disabled", inline=False)
        return embed

    async def _send_tag_setup(self, ctx):
        view = TagSetupView(self, ctx.guild.id, ctx.author.id)
        embed = await self._build_tag_setup_embed(ctx.guild)
        await ctx.send(embed=embed, view=view, ephemeral=ctx.interaction is not None)

    @commands.hybrid_group(name="tag", invoke_without_command=True, case_insensitive=True)
    @commands.guild_only()
    @commands.has_guild_permissions(manage_guild=True)
    async def tag(self, ctx):
        await self._send_tag_setup(ctx)

    @tag.command(name="setup", description="Choose tag channels and auto-delete duration")
    async def tag_setup(self, ctx):
        await self._send_tag_setup(ctx)

    @tag.command(name="list", description="Show tag channels, duration, and status")
    async def tag_list(self, ctx):
        embed = await self._build_tag_setup_embed(ctx.guild)
        await ctx.send(embed=embed, ephemeral=ctx.interaction is not None)

    @tag.command(name="enable", description="Enable automatic join tag pings")
    async def tag_enable(self, ctx):
        async with self.bot.db.execute(
            "SELECT delete_after_seconds FROM tag_settings WHERE guild_id=?", (ctx.guild.id,)
        ) as cursor:
            settings = await cursor.fetchone()
        async with self.bot.db.execute(
            "SELECT 1 FROM tag_channels WHERE guild_id=? LIMIT 1", (ctx.guild.id,)
        ) as cursor:
            has_channel = await cursor.fetchone()
        if not settings or not settings[0] or not has_channel:
            return await ctx.send(
                "Run `,tag setup` and choose at least one channel and a delete duration first.",
                ephemeral=ctx.interaction is not None,
            )
        await self.bot.db.execute(
            "UPDATE tag_settings SET enabled=1 WHERE guild_id=?", (ctx.guild.id,)
        )
        await self.bot.db.commit()
        await ctx.send("Automatic join tag pings enabled.", ephemeral=ctx.interaction is not None)

    @tag.command(name="disable", description="Disable automatic join tag pings")
    async def tag_disable(self, ctx):
        await self.bot.db.execute(
            "INSERT INTO tag_settings (guild_id, delete_after_seconds, enabled) VALUES (?, NULL, 0) "
            "ON CONFLICT(guild_id) DO UPDATE SET enabled=0",
            (ctx.guild.id,),
        )
        await self.bot.db.commit()
        await ctx.send("Automatic join tag pings disabled.", ephemeral=ctx.interaction is not None)

    async def send_tag_on_join(self, member):
        async with self.bot.db.execute(
            "SELECT delete_after_seconds, enabled FROM tag_settings WHERE guild_id=?", (member.guild.id,)
        ) as cursor:
            settings = await cursor.fetchone()
        if not settings or not settings[0] or not settings[1]:
            return

        async with self.bot.db.execute(
            "SELECT channel_id FROM tag_channels WHERE guild_id=?", (member.guild.id,)
        ) as cursor:
            channel_ids = [row[0] for row in await cursor.fetchall()]
        allowed_mentions = discord.AllowedMentions(
            users=[member], roles=False, everyone=False, replied_user=False
        )
        for channel_id in channel_ids:
            channel = member.guild.get_channel(channel_id)
            if not isinstance(channel, discord.TextChannel):
                continue
            try:
                await channel.send(
                    member.mention,
                    allowed_mentions=allowed_mentions,
                    delete_after=settings[0],
                )
            except discord.HTTPException as error:
                print(f"[tag] Failed to ping new member in channel {channel_id}: {error}")

    @commands.Cog.listener()
    async def on_member_join(self, member):
        await self.send_configured_greeting(member, "join")
        await self.send_tag_on_join(member)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        await self.send_configured_greeting(member, "leave")

    async def send_configured_greeting(self, member, greeting_type, inviter=None):
        async with self.bot.db.execute(
            "SELECT channel_id, join_config, leave_config, join_enabled, leave_enabled, "
            "join_card_enabled, leave_card_enabled "
            "FROM greeting_settings WHERE guild_id=?",
            (member.guild.id,),
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return False
        channel_id, join_config, leave_config, join_enabled, leave_enabled, join_card_enabled, leave_card_enabled = row
        if not (join_enabled if greeting_type == "join" else leave_enabled):
            return False
        raw_config = join_config if greeting_type == "join" else leave_config
        card_enabled = join_card_enabled if greeting_type == "join" else leave_card_enabled
        channel = member.guild.get_channel(channel_id)
        if (not raw_config and not card_enabled) or channel is None:
            return False
        try:
            if card_enabled:
                detail = f"MEMBER #{member.guild.member_count or 0}"
                if inviter:
                    detail += f"  •  INVITED BY {inviter.display_name}"
                card = await self._build_member_event_card(member, greeting_type, detail)
                card_embed = discord.Embed(
                    color=0x6FE0C2 if greeting_type == "join" else 0xB6C2D9
                )
                card_embed.set_image(url=f"attachment://{card.filename}")
                await send_v2(
                    channel,
                    embed=card_embed,
                    file=card,
                    allowed_mentions=discord.AllowedMentions.none(),
                )
                return True
            config = json.loads(raw_config)
            if inviter:
                config = dict(config)
                description = config.get("description", "")
                config["description"] = f"{description}\nInvited by: {inviter.mention}".strip()
            embed = build_custom_embed(
                config,
                member,
                member.guild,
                channel,
                self.bot.user,
                {
                    "inviter": inviter.mention if inviter else "Unknown",
                    "inviter.name": inviter.display_name if inviter else "Unknown",
                    "inviter.id": inviter.id if inviter else "",
                },
            )
            await send_v2(channel, embed=embed, allowed_mentions=discord.AllowedMentions.none())
        except (
            ValueError,
            TypeError,
            discord.DiscordException,
            aiohttp.ClientError,
            asyncio.TimeoutError,
            OSError,
        ) as error:
            print(f"[greeting] Failed to send {greeting_type} embed for guild {member.guild.id}: {error}")
        return True

    def _next_fun_gif(self, action, gif_urls=None):
        if gif_urls:
            self._fun_gif_cache[action] = list(dict.fromkeys(gif_urls))
        cached_urls = self._fun_gif_cache.get(action, [])
        if not cached_urls:
            return None
        index = self._fun_gif_indexes.get(action, 0) % len(cached_urls)
        self._fun_gif_indexes[action] = index + 1
        return cached_urls[index]

    async def _request_fun_gif_urls(self, category):
        api_key = os.getenv("GIPHY_API_KEY", "").strip()
        if not api_key:
            raise ValueError("GIPHY_API_KEY is not configured")
        timeout = aiohttp.ClientTimeout(total=7, connect=3, sock_read=5)
        params = {
            "api_key": api_key,
            "q": category,
            "limit": 10,
            "rating": "pg-13",
        }
        async with aiohttp.ClientSession(timeout=timeout) as session:
            for attempt in range(2):
                try:
                    async with session.get(
                        "https://api.giphy.com/v1/gifs/search",
                        params=params,
                    ) as response:
                        if response.status == 200:
                            payload = await response.json()
                            return [
                                image["url"]
                                for result in payload.get("data", [])
                                if isinstance(result, dict)
                                for image in (
                                    result.get("images", {}).get("original")
                                    or result.get("images", {}).get("downsized_medium"),
                                )
                                if isinstance(image, dict) and image.get("url")
                            ]
                        if response.status == 429 or response.status >= 500:
                            if attempt == 0:
                                await asyncio.sleep(0.5)
                                continue
                        response.raise_for_status()
                        raise aiohttp.ClientResponseError(
                            response.request_info,
                            response.history,
                            status=response.status,
                            message="Unexpected Giphy API response",
                            headers=response.headers,
                        )
                except aiohttp.ClientResponseError as error:
                    if error.status != 429 and error.status < 500:
                        raise
                    if attempt == 0:
                        await asyncio.sleep(0.5)
                        continue
                    raise
                except (aiohttp.ClientError, asyncio.TimeoutError):
                    if attempt == 0:
                        await asyncio.sleep(0.5)
                        continue
                    raise
        return []

    def _log_fun_gif_failure(self, action, error):
        loop = asyncio.get_running_loop()
        now = loop.time()
        if now >= self._fun_gif_retry_after:
            print(
                f"[fun] Giphy GIF request failed for {action} "
                f"({type(error).__name__}); pausing requests for 5 minutes."
            )
        self._fun_gif_retry_after = now + 300

    async def _fetch_fun_gif(self, action):
        category = FUN_GIF_SEARCH_FALLBACKS.get(action, action)
        loop = asyncio.get_running_loop()
        if loop.time() < self._fun_gif_retry_after:
            return self._next_fun_gif(action)

        try:
            gif_urls = await self._request_fun_gif_urls(category)
            if not gif_urls and category != "happy":
                gif_urls = await self._request_fun_gif_urls("happy")
        except (aiohttp.ClientError, asyncio.TimeoutError, ValueError) as error:
            self._log_fun_gif_failure(action, error)
            return self._next_fun_gif(action)

        self._fun_gif_retry_after = 0.0
        return self._next_fun_gif(action, gif_urls)

    async def send_fun_action(self, ctx, action, member, *, spam=False):
        description = FUN_ACTIONS[action]
        embed = discord.Embed(
            title=f"{action.title()} Spam" if spam else None,
            description="\n".join(
                f"{ctx.author.mention} {description} {member.mention}!"
                for _ in range(5 if spam else 1)
            ),
            color=0xFFDD00,
        )
        gif_url = await self._fetch_fun_gif(action)
        if gif_url:
            embed.set_image(url=gif_url)
        await ctx.send(embed=embed, allowed_mentions=discord.AllowedMentions.none())

    @commands.hybrid_command(name="ship", description="Create a fun compatibility card")
    async def ship(self, ctx, user: discord.Member = None, second: discord.Member = None):
        if user is None:
            user = await self._resolve_member_from_context(ctx)
        if user is None:
            return await ctx.send("Use `,ship @user`, reply to a user's message with `,ship`, or use `,ship @user1 @user2`.", ephemeral=ctx.interaction is not None)
        first_member, second_member = (ctx.author, user) if second is None else (user, second)
        low_id, high_id = sorted((first_member.id, second_member.id))
        digest = hashlib.sha256(f"{low_id}:{high_id}".encode("ascii")).digest()
        percentage = int.from_bytes(digest[:4], "big") % 101
        if percentage >= 90:
            label = "Perfect Match"
        elif percentage >= 75:
            label = "Amazing Chemistry"
        elif percentage >= 60:
            label = "Cute Pair"
        elif percentage >= 40:
            label = "Good Match"
        elif percentage >= 20:
            label = "Maybe"
        else:
            label = "Friend Zone"
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=12)) as session:
                first_bytes, second_bytes = await asyncio.gather(
                    self._download_avatar(session, first_member),
                    self._download_avatar(session, second_member),
                )
            card = await asyncio.to_thread(
                render_ship_card,
                first_bytes,
                second_bytes,
                first_member.display_name,
                second_member.display_name,
                percentage,
                label,
            )
        except (aiohttp.ClientError, asyncio.TimeoutError, OSError, ValueError) as error:
            print(f"[ship] Card generation failed: {error}")
            return await ctx.send("Could not create the ship card right now. Please try again.", ephemeral=ctx.interaction is not None)
        file = discord.File(io.BytesIO(card), filename="falcon-ship.png")
        embed = discord.Embed(
            title=f"{first_member.mention} ship to {second_member.mention}",
            description=(
                f"**Compatibility:** {percentage}%\n"
                f"**Result:** {label}\n"
                "Just for fun; not a serious compatibility claim."
            ),
            color=0xFFDD00,
        )
        embed.set_image(url="attachment://falcon-ship.png")
        await ctx.send(
            embed=embed,
            file=file,
            allowed_mentions=discord.AllowedMentions.none(),
        )

    async def _download_avatar(self, session, member):
        avatar_url = member.display_avatar.replace(format="png", size=256).url
        async with session.get(avatar_url) as response:
            if response.status != 200:
                raise aiohttp.ClientError(f"Avatar download returned HTTP {response.status}")
            return await response.read()


def render_ship_card(first_avatar, second_avatar, first_name, second_name, percentage, label):
    width, height = 1024, 420
    image = Image.new("RGB", (width, height), "#21111C")
    draw = ImageDraw.Draw(image)
    for y in range(height):
        blend = y / max(1, height - 1)
        color = (int(31 + 30 * blend), int(15 + 11 * blend), int(29 + 20 * blend))
        draw.line((0, y, width, y), fill=color)
    rose = "#E987A6"
    pale_rose = "#FFE3EA"
    draw.rounded_rectangle((18, 18, width - 18, height - 18), radius=24, fill="#281622", outline=rose, width=2)
    draw.rounded_rectangle((28, 28, width - 28, height - 28), radius=18, outline="#684052", width=1)

    try:
        score_font = ImageFont.truetype("DejaVuSans.ttf", 48)
        name_font = ImageFont.truetype("DejaVuSans.ttf", 25)
        label_font = ImageFont.truetype("DejaVuSans.ttf", 17)
        small_font = ImageFont.truetype("DejaVuSans.ttf", 14)
        heart_font = ImageFont.truetype("DejaVuSans.ttf", 34)
    except OSError:
        score_font = ImageFont.load_default()
        name_font = ImageFont.load_default()
        label_font = ImageFont.load_default()
        small_font = ImageFont.load_default()
        heart_font = small_font

    draw.text((width // 2, 57), "F A L C O N   /   L O V E   M A T C H", font=small_font, fill=pale_rose, anchor="mm")
    draw.line((78, 82, width - 78, 82), fill="#754257", width=1)
    for x, y in ((105, 116), (350, 110), (674, 110), (919, 116), (132, 342), (892, 342)):
        draw.text((x, y), "♥", font=heart_font, fill="#A84E71", anchor="mm")

    def draw_avatar(data, center):
        avatar = Image.open(io.BytesIO(data)).convert("RGBA")
        avatar = ImageOps.fit(avatar, (172, 172))
        mask = Image.new("L", (172, 172), 0)
        ImageDraw.Draw(mask).ellipse((0, 0, 171, 171), fill=255)
        image.paste(avatar, (center[0] - 86, center[1] - 86), mask)
        draw.ellipse((center[0] - 96, center[1] - 96, center[0] + 96, center[1] + 96), outline=rose, width=3)
        draw.ellipse((center[0] - 102, center[1] - 102, center[0] + 102, center[1] + 102), outline="#87526A", width=1)

    try:
        draw_avatar(first_avatar, (228, 210))
        draw_avatar(second_avatar, (796, 210))
    except (OSError, ValueError):
        draw.ellipse((132, 114, 324, 306), fill="#432637", outline=rose, width=3)
        draw.ellipse((700, 114, 892, 306), fill="#432637", outline=rose, width=3)

    draw.text((228, 330), first_name[:22], font=name_font, fill="#FFF2F5", anchor="mm")
    draw.text((796, 330), second_name[:22], font=name_font, fill="#FFF2F5", anchor="mm")
    draw.text((512, 116), "CHEMISTRY SCORE", font=small_font, fill=rose, anchor="mm")
    draw.ellipse((425, 127, 599, 301), fill="#1D1119", outline="#754257", width=2)
    draw.ellipse((433, 135, 591, 293), outline=rose, width=3)
    draw.ellipse((491, 146, 516, 171), fill="#F08EAB")
    draw.ellipse((508, 146, 533, 171), fill="#F08EAB")
    draw.polygon([(491, 160), (533, 160), (512, 185)], fill="#F08EAB")
    draw.text((512, 218), f"{percentage}%", font=score_font, fill="#FFFFFF", anchor="mm")
    draw.text((512, 264), label.upper(), font=label_font, fill=pale_rose, anchor="mm")
    draw.rounded_rectangle((390, 358, 634, 366), radius=4, fill="#563448")
    draw.rounded_rectangle((390, 358, 390 + int(244 * percentage / 100), 366), radius=4, fill=rose)
    draw.text((512, 389), "A LITTLE LOVE, A LOT OF CHEMISTRY", font=small_font, fill="#E8B9C8", anchor="mm")

    output = io.BytesIO()
    image.save(output, format="PNG", optimize=True)
    return output.getvalue()


def _make_fun_command(action):
    async def callback(ctx, *, arguments: str = ""):
        cog = ctx.bot.get_cog("CommunityFeatures")
        parts = arguments.strip().split(maxsplit=1)
        spam = bool(parts and parts[0].casefold() == "spam")
        target_query = parts[1] if spam and len(parts) > 1 else ("" if spam else arguments.strip())
        target = await cog._resolve_member_from_context(ctx, query=target_query)
        if target is None:
            return await ctx.send(
                f"Use `,{action} @user`, `,{action} spam @user`, or reply to a user's message.",
                ephemeral=ctx.interaction is not None,
            )
        await cog.send_fun_action(ctx, action, target, spam=spam)

    return commands.command(name=action, help=f"{action.title()} another member")(callback)


def register_fun_commands(bot):
    for action in FUN_ACTIONS:
        if bot.get_command(action) is None:
            bot.add_command(_make_fun_command(action))


async def setup(bot):
    cog = CommunityFeatures(bot)
    await bot.add_cog(cog)
    register_fun_commands(bot)
