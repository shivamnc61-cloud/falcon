import datetime
import json

import discord
from discord.ext import commands

from components_v2 import edit_interaction_v2, send_interaction_v2


NATIVE_AUTOMOD_MODULES = {
    "keyword": ("Keyword", "Blocked words from `,filterword`"),
    "spam": ("Spam", "Discord-native message spam detection"),
    "mention": ("Mention Spam", "Mass mention protection"),
    "preset": ("Profanity", "Discord profanity, sexual content, and slur presets"),
}

NATIVE_AUTOMOD_MODES = ("block", "timeout", "alert")


def _load_ids(value):
    try:
        decoded = json.loads(value or "[]")
    except (TypeError, json.JSONDecodeError):
        return []
    return [int(item) for item in decoded if str(item).isdigit()]


class NativeAutoModView(discord.ui.View):
    def __init__(self, cog, guild, owner_id):
        super().__init__(timeout=600)
        self.cog = cog
        self.guild = guild
        self.owner_id = owner_id
        self.module = "keyword"
        self.mode = "block"
        self.enabled = False
        self.rule_id = None
        self.exempt_role_ids = []
        self.exempt_channel_ids = []
        self.keyword_count = 0
        self.weekly_actions = 0
        self.monthly_actions = 0
        self.recent_actions = []
        self.dm_enabled = False
        self.escalation_enabled = True
        self.notice = None

        self.module_select = discord.ui.Select(
            placeholder="Select a native AutoMod module",
            options=[
                discord.SelectOption(
                    label=label,
                    value=key,
                    description=description,
                    default=key == self.module,
                )
                for key, (label, description) in NATIVE_AUTOMOD_MODULES.items()
            ],
            row=0,
        )
        self.module_select.callback = self.select_module
        self.add_item(self.module_select)

        self.mode_select = discord.ui.Select(
            placeholder="Choose what Discord should do",
            options=[
                discord.SelectOption(label="Block message", value="block"),
                discord.SelectOption(label="Timeout for 10 minutes", value="timeout"),
                discord.SelectOption(label="Alert only", value="alert"),
            ],
            row=1,
        )
        self.mode_select.callback = self.select_mode
        self.add_item(self.mode_select)

        self.role_select = discord.ui.RoleSelect(
            placeholder="Exempt roles (optional)", min_values=0, max_values=25, row=2
        )
        self.role_select.callback = self.select_roles
        self.add_item(self.role_select)

        self.channel_select = discord.ui.ChannelSelect(
            placeholder="Exempt channels (optional)", min_values=0, max_values=25, row=3
        )
        self.channel_select.callback = self.select_channels
        self.add_item(self.channel_select)

    async def load_module(self):
        config = await self.cog.get_rule_config(self.guild.id, self.module)
        self.mode = config["mode"]
        self.enabled = config["enabled"]
        self.rule_id = config["rule_id"]
        self.exempt_role_ids = config["exempt_roles"]
        self.exempt_channel_ids = config["exempt_channels"]
        self.keyword_count = await self.cog.keyword_count(self.guild.id) if self.module == "keyword" else 0
        since = (discord.utils.utcnow() - datetime.timedelta(days=7)).isoformat()
        async with self.cog.bot.db.execute(
            "SELECT COUNT(*) FROM native_automod_violations "
            "WHERE guild_id=? AND module=? AND created_at>=?",
            (self.guild.id, NATIVE_AUTOMOD_MODULES[self.module][0], since),
        ) as cursor:
            row = await cursor.fetchone()
        self.weekly_actions = row[0] if row else 0
        month_since = (discord.utils.utcnow() - datetime.timedelta(days=30)).isoformat()
        async with self.cog.bot.db.execute(
            "SELECT COUNT(*) FROM native_automod_violations "
            "WHERE guild_id=? AND module=? AND created_at>=?",
            (self.guild.id, NATIVE_AUTOMOD_MODULES[self.module][0], month_since),
        ) as cursor:
            row = await cursor.fetchone()
        self.monthly_actions = row[0] if row else 0
        async with self.cog.bot.db.execute(
            "SELECT user_id, action, channel_id, matched_keyword, created_at "
            "FROM native_automod_violations WHERE guild_id=? AND module=? "
            "ORDER BY violation_id DESC LIMIT 5",
            (self.guild.id, NATIVE_AUTOMOD_MODULES[self.module][0]),
        ) as cursor:
            self.recent_actions = await cursor.fetchall()
        self.dm_enabled, self.escalation_enabled = await self.cog.get_settings(self.guild.id)
        for option in self.module_select.options:
            option.default = option.value == self.module
        for option in self.mode_select.options:
            option.default = option.value == self.mode

    def make_embed(self):
        label, description = NATIVE_AUTOMOD_MODULES[self.module]
        state = "Enabled" if self.enabled else "Paused"
        if self.enabled and self.rule_id is None:
            state = "Not synced"
        rule_label = f"`{self.rule_id}`" if self.rule_id else "Not synced"
        embed = discord.Embed(
            color=0xFFDD00,
            title="Falcon Native AutoMod",
            description=(
                f"**Module:** {label}\n{description}\n\n"
                f"**Status:** {state}\n"
                f"**Action:** {self.mode.title()}\n"
                f"**Discord rule:** {rule_label}"
            ),
        )
        if self.module == "keyword":
            embed.add_field(
                name="Keyword Source",
                value=f"{self.keyword_count} blocked word(s) from `,filterword`.",
                inline=False,
            )
        recent_lines = []
        for user_id, action, channel_id, match, created_at in self.recent_actions:
            try:
                timestamp = int(datetime.datetime.fromisoformat(created_at).timestamp())
                time_label = f"<t:{timestamp}:R>"
            except (TypeError, ValueError, OverflowError):
                time_label = "time unknown"
            safe_match = " ".join(str(match or "").replace("`", "'").split())[:80]
            channel_label = f" in <#{channel_id}>" if channel_id else ""
            recent_lines.append(
                f"<@{user_id}> · {action}{channel_label} · {time_label}"
                + (f" · `{safe_match}`" if safe_match else "")
            )
        embed.add_field(
            name="7-Day Actions",
            value=str(self.weekly_actions),
            inline=True,
        )
        embed.add_field(
            name="30-Day Actions",
            value=str(self.monthly_actions),
            inline=True,
        )
        embed.add_field(
            name="Recent Logs",
            value="\n".join(recent_lines) or "No recent actions.",
            inline=False,
        )
        roles = [f"<@&{role_id}>" for role_id in self.exempt_role_ids]
        channels = [f"<#{channel_id}>" for channel_id in self.exempt_channel_ids]
        embed.add_field(name="Exempt Roles", value=", ".join(roles) or "None", inline=True)
        embed.add_field(name="Exempt Channels", value=", ".join(channels) or "None", inline=True)
        embed.add_field(name="Offender DMs", value="ON" if self.dm_enabled else "OFF", inline=True)
        embed.add_field(name="Repeat Escalation", value="ON" if self.escalation_enabled else "OFF", inline=True)
        if self.notice:
            embed.add_field(name="Status", value=self.notice[:1024], inline=False)
        if self.cog.bot.user:
            embed.set_thumbnail(url=self.cog.bot.user.display_avatar.url)
        embed.set_footer(text="Native rules are enforced by Discord and need Manage Server permission.")
        return embed

    async def interaction_check(self, interaction):
        if interaction.user.id == self.owner_id:
            return True
        await send_interaction_v2(
            interaction,
            "Only the administrator who opened this AutoMod panel can use it.",
            ephemeral=True,
            allow_ephemeral=True,
        )
        return False

    async def _refresh(self, interaction):
        await edit_interaction_v2(interaction, embed=self.make_embed(), view=self)

    async def select_module(self, interaction):
        self.module = self.module_select.values[0]
        self.notice = None
        await self.load_module()
        await self._refresh(interaction)

    async def select_mode(self, interaction):
        self.mode = self.mode_select.values[0]
        self.notice = "Action mode selected. Use Save + Sync to apply it."
        await self._refresh(interaction)

    async def select_roles(self, interaction):
        self.exempt_role_ids = [role.id for role in self.role_select.values]
        self.notice = "Role exclusions selected. Use Save + Sync to apply them."
        await self._refresh(interaction)

    async def select_channels(self, interaction):
        self.exempt_channel_ids = [channel.id for channel in self.channel_select.values]
        self.notice = "Channel exclusions selected. Use Save + Sync to apply them."
        await self._refresh(interaction)

    async def _save_current(self):
        await self.cog.save_rule_config(
            self.guild.id,
            self.module,
            enabled=self.enabled,
            mode=self.mode,
            exempt_roles=self.exempt_role_ids,
            exempt_channels=self.exempt_channel_ids,
            rule_id=self.rule_id,
        )

    async def _sync_selected(self, interaction, *, enable):
        self.enabled = enable
        await self._save_current()
        try:
            self.rule_id = await self.cog.sync_rule(self.guild, self.module)
            self.notice = "Native Discord rule synced successfully." if enable else "Native Discord rule paused."
        except (ValueError, discord.Forbidden, discord.HTTPException) as error:
            self.notice = f"Could not sync rule: {error}"
        await self.load_module()
        await self._refresh(interaction)

    @discord.ui.button(label="Save + Sync", emoji="💾", style=discord.ButtonStyle.primary, row=4)
    async def save_and_sync(self, interaction, _button):
        await self._sync_selected(interaction, enable=True)

    @discord.ui.button(label="Enable / Pause", style=discord.ButtonStyle.secondary, row=4)
    async def toggle_selected(self, interaction, _button):
        await self._sync_selected(interaction, enable=not self.enabled)

    @discord.ui.button(label="Sync Enabled", style=discord.ButtonStyle.success, row=4)
    async def sync_enabled(self, interaction, _button):
        await self._save_current()
        try:
            synced = await self.cog.sync_enabled_rules(self.guild)
            self.notice = f"Synced {synced} enabled native rule(s)."
        except (discord.Forbidden, discord.HTTPException, ValueError) as error:
            self.notice = f"Could not sync enabled rules: {error}"
        await self.load_module()
        await self._refresh(interaction)

    @discord.ui.button(label="Toggle DMs", style=discord.ButtonStyle.secondary, row=4)
    async def toggle_dms(self, interaction, _button):
        self.dm_enabled = not self.dm_enabled
        await self.cog.save_settings(
            self.guild.id,
            dm_enabled=self.dm_enabled,
            escalation_enabled=self.escalation_enabled,
        )
        self.notice = f"Offender DMs {'enabled' if self.dm_enabled else 'disabled'}."
        await self._refresh(interaction)

    @discord.ui.button(label="Toggle Escalation", style=discord.ButtonStyle.secondary, row=4)
    async def toggle_escalation(self, interaction, _button):
        self.escalation_enabled = not self.escalation_enabled
        await self.cog.save_settings(
            self.guild.id,
            dm_enabled=self.dm_enabled,
            escalation_enabled=self.escalation_enabled,
        )
        self.notice = f"Repeat-violation escalation {'enabled' if self.escalation_enabled else 'disabled'}."
        await self._refresh(interaction)


class NativeAutoMod(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        await self.bot.db.execute(
            "CREATE TABLE IF NOT EXISTS native_automod_rules ("
            "guild_id INTEGER NOT NULL, module TEXT NOT NULL, rule_id INTEGER, "
            "enabled INTEGER NOT NULL DEFAULT 0, mode TEXT NOT NULL DEFAULT 'block', "
            "mention_limit INTEGER NOT NULL DEFAULT 5, exempt_roles TEXT NOT NULL DEFAULT '[]', "
            "exempt_channels TEXT NOT NULL DEFAULT '[]', updated_at TEXT NOT NULL, "
            "PRIMARY KEY(guild_id, module))"
        )
        await self.bot.db.execute(
            "CREATE TABLE IF NOT EXISTS native_automod_violations ("
            "violation_id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL, "
            "user_id INTEGER NOT NULL, module TEXT NOT NULL, rule_id INTEGER NOT NULL, "
            "channel_id INTEGER, action TEXT NOT NULL, matched_keyword TEXT, created_at TEXT NOT NULL)"
        )
        await self.bot.db.execute(
            "CREATE TABLE IF NOT EXISTS native_automod_settings ("
            "guild_id INTEGER PRIMARY KEY, dm_enabled INTEGER NOT NULL DEFAULT 0, "
            "escalation_enabled INTEGER NOT NULL DEFAULT 1)"
        )
        await self.bot.db.commit()

    async def get_settings(self, guild_id):
        await self.bot.db.execute(
            "INSERT OR IGNORE INTO native_automod_settings (guild_id) VALUES (?)",
            (guild_id,),
        )
        await self.bot.db.commit()
        async with self.bot.db.execute(
            "SELECT dm_enabled,escalation_enabled FROM native_automod_settings WHERE guild_id=?",
            (guild_id,),
        ) as cursor:
            row = await cursor.fetchone()
        return bool(row[0]), bool(row[1])

    async def save_settings(self, guild_id, *, dm_enabled, escalation_enabled):
        await self.bot.db.execute(
            "INSERT INTO native_automod_settings (guild_id,dm_enabled,escalation_enabled) "
            "VALUES (?,?,?) ON CONFLICT(guild_id) DO UPDATE SET "
            "dm_enabled=excluded.dm_enabled, escalation_enabled=excluded.escalation_enabled",
            (guild_id, int(dm_enabled), int(escalation_enabled)),
        )
        await self.bot.db.commit()

    async def get_rule_config(self, guild_id, module):
        async with self.bot.db.execute(
            "SELECT rule_id, enabled, mode, mention_limit, exempt_roles, exempt_channels "
            "FROM native_automod_rules WHERE guild_id=? AND module=?",
            (guild_id, module),
        ) as cursor:
            row = await cursor.fetchone()
        if not row:
            return {
                "rule_id": None,
                "enabled": False,
                "mode": "block",
                "mention_limit": 5,
                "exempt_roles": [],
                "exempt_channels": [],
            }
        return {
            "rule_id": row[0],
            "enabled": bool(row[1]),
            "mode": row[2],
            "mention_limit": row[3],
            "exempt_roles": _load_ids(row[4]),
            "exempt_channels": _load_ids(row[5]),
        }

    async def save_rule_config(
        self,
        guild_id,
        module,
        *,
        enabled,
        mode,
        exempt_roles,
        exempt_channels,
        rule_id=None,
        mention_limit=5,
    ):
        await self.bot.db.execute(
            "INSERT INTO native_automod_rules "
            "(guild_id,module,rule_id,enabled,mode,mention_limit,exempt_roles,exempt_channels,updated_at) "
            "VALUES (?,?,?,?,?,?,?,?,?) ON CONFLICT(guild_id,module) DO UPDATE SET "
            "rule_id=excluded.rule_id, enabled=excluded.enabled, mode=excluded.mode, "
            "mention_limit=excluded.mention_limit, exempt_roles=excluded.exempt_roles, "
            "exempt_channels=excluded.exempt_channels, updated_at=excluded.updated_at",
            (
                guild_id,
                module,
                rule_id,
                int(enabled),
                mode,
                mention_limit,
                json.dumps(sorted(set(exempt_roles))),
                json.dumps(sorted(set(exempt_channels))),
                discord.utils.utcnow().isoformat(),
            ),
        )
        await self.bot.db.commit()

    async def keyword_count(self, guild_id):
        try:
            async with self.bot.db.execute(
                "SELECT COUNT(*) FROM zyre_filter_words WHERE guild_id=?", (guild_id,)
            ) as cursor:
                row = await cursor.fetchone()
            return row[0] if row else 0
        except Exception:
            return 0

    async def _trigger_for(self, guild_id, module, config):
        if module == "keyword":
            try:
                async with self.bot.db.execute(
                    "SELECT word FROM zyre_filter_words WHERE guild_id=? ORDER BY word LIMIT 100",
                    (guild_id,),
                ) as cursor:
                    words = [row[0][:100] for row in await cursor.fetchall()]
            except Exception:
                words = []
            if not words:
                raise ValueError("Add at least one blocked word with `,filterword add <word>` first.")
            return discord.AutoModTrigger(
                type=discord.AutoModRuleTriggerType.keyword,
                keyword_filter=words,
            )
        if module == "spam":
            return discord.AutoModTrigger(type=discord.AutoModRuleTriggerType.spam)
        if module == "mention":
            return discord.AutoModTrigger(
                type=discord.AutoModRuleTriggerType.mention_spam,
                mention_limit=config["mention_limit"],
                mention_raid_protection=True,
            )
        if module == "preset":
            presets = (
                discord.AutoModPresets.profanity
                | discord.AutoModPresets.sexual_content
                | discord.AutoModPresets.slurs
            )
            return discord.AutoModTrigger(
                type=discord.AutoModRuleTriggerType.keyword_preset,
                presets=presets,
            )
        raise ValueError("Unknown AutoMod module.")

    async def _actions_for(self, guild, config):
        actions = []
        async with self.bot.db.execute(
            "SELECT log_channel_id FROM automod_settings WHERE guild_id=?",
            (guild.id,),
        ) as cursor:
            row = await cursor.fetchone()
        log_channel_id = row[0] if row else None
        if log_channel_id:
            actions.append(
                discord.AutoModRuleAction(
                    type=discord.AutoModRuleActionType.send_alert_message,
                    channel_id=log_channel_id,
                )
            )
        if config["mode"] == "block":
            actions.append(
                discord.AutoModRuleAction(
                    type=discord.AutoModRuleActionType.block_message,
                    custom_message="Your message was blocked by Falcon AutoMod.",
                )
            )
        elif config["mode"] == "timeout":
            actions.append(
                discord.AutoModRuleAction(
                    type=discord.AutoModRuleActionType.timeout,
                    duration=datetime.timedelta(minutes=10),
                )
            )
        elif config["mode"] == "alert" and not log_channel_id:
            raise ValueError("Configure `,automod log #channel` before using alert-only mode.")
        elif config["mode"] not in NATIVE_AUTOMOD_MODES:
            raise ValueError("Choose block, timeout, or alert mode.")
        return actions

    async def sync_rule(self, guild, module):
        config = await self.get_rule_config(guild.id, module)
        if not config["enabled"] and config["rule_id"] is None:
            return None
        if not config["enabled"]:
            rules = await guild.fetch_automod_rules()
            existing = next(
                (rule for rule in rules if rule.id == config["rule_id"]),
                None,
            )
            if existing is None:
                await self.save_rule_config(
                    guild.id,
                    module,
                    enabled=False,
                    mode=config["mode"],
                    exempt_roles=config["exempt_roles"],
                    exempt_channels=config["exempt_channels"],
                    rule_id=None,
                    mention_limit=config["mention_limit"],
                )
                return None
            await existing.edit(
                enabled=False,
                reason="Pause Falcon native AutoMod rule",
            )
            return existing.id
        trigger = await self._trigger_for(guild.id, module, config)
        actions = await self._actions_for(guild, config)
        if not actions:
            raise ValueError("Native AutoMod needs at least one action.")
        module_name = NATIVE_AUTOMOD_MODULES[module][0]
        rule_name = f"Falcon AutoMod · {module_name}"
        exempt_roles = [
            guild.get_role(role_id)
            for role_id in config["exempt_roles"]
            if guild.get_role(role_id) is not None
        ]
        exempt_channels = [
            guild.get_channel(channel_id)
            for channel_id in config["exempt_channels"]
            if guild.get_channel(channel_id) is not None
        ]
        kwargs = {
            "name": rule_name,
            "event_type": discord.AutoModRuleEventType.message_send,
            "trigger": trigger,
            "actions": actions,
            "enabled": config["enabled"],
            "exempt_roles": exempt_roles,
            "exempt_channels": exempt_channels,
            "reason": "Configure Falcon native AutoMod",
        }
        rules = await guild.fetch_automod_rules()
        existing = next(
            (
                rule
                for rule in rules
                if rule.id == config["rule_id"] or rule.name == rule_name
            ),
            None,
        )
        if existing:
            await existing.edit(**kwargs)
            rule_id = existing.id
        else:
            created = await guild.create_automod_rule(**kwargs)
            rule_id = created.id
        await self.save_rule_config(
            guild.id,
            module,
            enabled=config["enabled"],
            mode=config["mode"],
            exempt_roles=config["exempt_roles"],
            exempt_channels=config["exempt_channels"],
            rule_id=rule_id,
            mention_limit=config["mention_limit"],
        )
        return rule_id

    async def sync_enabled_rules(self, guild):
        async with self.bot.db.execute(
            "SELECT module FROM native_automod_rules WHERE guild_id=? AND enabled=1 ORDER BY module",
            (guild.id,),
        ) as cursor:
            modules = [row[0] for row in await cursor.fetchall()]
        for module in modules:
            await self.sync_rule(guild, module)
        return len(modules)

    async def open_dashboard(self, ctx):
        view = NativeAutoModView(self, ctx.guild, ctx.author.id)
        await view.load_module()
        return await ctx.send(embed=view.make_embed(), view=view)

    @commands.Cog.listener()
    async def on_automod_action(self, execution):
        guild = execution.guild
        module = "AutoMod"
        async with self.bot.db.execute(
            "SELECT module FROM native_automod_rules WHERE guild_id=? AND rule_id=?",
            (execution.guild_id, execution.rule_id),
        ) as cursor:
            row = await cursor.fetchone()
        if row and row[0] in NATIVE_AUTOMOD_MODULES:
            module = NATIVE_AUTOMOD_MODULES[row[0]][0]
        action_name = execution.action.type.name.replace("_", " ").title()
        matched = execution.matched_keyword or execution.matched_content or "Not available"
        created_at = discord.utils.utcnow().isoformat()
        await self.bot.db.execute(
            "INSERT INTO native_automod_violations "
            "(guild_id,user_id,module,rule_id,channel_id,action,matched_keyword,created_at) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (
                execution.guild_id,
                execution.user_id,
                module,
                execution.rule_id,
                execution.channel_id,
                action_name,
                str(matched)[:200],
                created_at,
            ),
        )
        await self.bot.db.commit()

        member = execution.member
        member_mention = member.mention if member else f"<@{execution.user_id}>"
        channel_mention = f"<#{execution.channel_id}>" if execution.channel_id else "Unknown"
        embed = discord.Embed(
            color=0xFFDD00,
            title="AutoMod Action",
            description=(
                f"**Member:** {member_mention} (`{execution.user_id}`)\n"
                f"**Module:** {module}\n"
                f"**Action:** {action_name}\n"
                f"**Channel:** {channel_mention}\n"
                f"**Match:** `{str(matched)[:200]}`"
            ),
            timestamp=discord.utils.utcnow(),
        )
        if self.bot.user:
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        async with self.bot.db.execute(
            "SELECT log_channel_id FROM automod_settings WHERE guild_id=?",
            (execution.guild_id,),
        ) as cursor:
            log_row = await cursor.fetchone()
        channel = guild.get_channel(log_row[0]) if log_row and log_row[0] else None
        if channel is None:
            try:
                from main import _ensure_automod_log

                channel = await _ensure_automod_log(guild)
            except (discord.Forbidden, discord.HTTPException, RuntimeError) as error:
                print(f"[automod] Could not resolve native AutoMod log channel in guild {guild.id}: {error}")
                return
        try:
            from main import _send_security_log

            await _send_security_log(guild, channel, embed)
        except discord.HTTPException as error:
            print(f"[automod] Could not write native AutoMod log in guild {guild.id}: {error}")

        dm_enabled, escalation_enabled = await self.get_settings(guild.id)
        if dm_enabled:
            dm_target = member
            if dm_target is None:
                try:
                    dm_target = await self.bot.fetch_user(execution.user_id)
                except (discord.NotFound, discord.Forbidden, discord.HTTPException):
                    dm_target = None
            if dm_target is not None:
                try:
                    await dm_target.send(
                        f"Your message in **{guild.name}** was flagged by Falcon AutoMod ({module})."
                    )
                except (discord.Forbidden, discord.HTTPException):
                    pass

        if escalation_enabled:
            await self._escalate(guild, member, execution.user_id)

    async def _escalate(self, guild, member, user_id):
        window_start = (discord.utils.utcnow() - datetime.timedelta(minutes=10)).isoformat()
        async with self.bot.db.execute(
            "SELECT COUNT(*) FROM native_automod_violations "
            "WHERE guild_id=? AND user_id=? AND created_at>=?",
            (guild.id, user_id, window_start),
        ) as cursor:
            count = (await cursor.fetchone())[0]
        if count < 5:
            return
        if member is None:
            try:
                member = await guild.fetch_member(user_id)
            except (discord.NotFound, discord.Forbidden, discord.HTTPException):
                return
        bot_member = guild.me
        if (
            user_id == guild.owner_id
            or member.guild_permissions.administrator
            or bot_member is None
            or not bot_member.guild_permissions.moderate_members
            or bot_member.top_role <= member.top_role
        ):
            return
        if member.timed_out_until and member.timed_out_until > discord.utils.utcnow():
            return
        try:
            await member.timeout(
                datetime.timedelta(hours=1),
                reason="Falcon AutoMod: repeated native AutoMod violations",
            )
        except (discord.Forbidden, discord.HTTPException) as error:
            print(f"[automod] Could not escalate repeated violations in guild {guild.id}: {error}")

    @commands.Cog.listener()
    async def on_automod_rule_delete(self, rule):
        await self.bot.db.execute(
            "UPDATE native_automod_rules SET rule_id=NULL "
            "WHERE guild_id=? AND rule_id=?",
            (rule.guild.id, rule.id),
        )
        await self.bot.db.commit()
