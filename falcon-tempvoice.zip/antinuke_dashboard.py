import datetime

import discord

from components_v2 import edit_interaction_v2, send_interaction_v2


class AntiNukeDashboardView(discord.ui.View):
    PAGE_SIZE = 25

    def __init__(self, bot, guild, owner_id, events):
        super().__init__(timeout=600)
        self.bot = bot
        self.guild = guild
        self.owner_id = owner_id
        self.events = tuple(events.items())
        self.page = 0
        self.selected_event = None
        self.global_enabled = False
        self.event_states = {}
        self.settings = (1, 1, "ban", 3, 10, None)
        self.incidents = []
        self.notice = None

        self.event_select = discord.ui.Select(
            placeholder="Select an Anti-Nuke event to toggle",
            min_values=1,
            max_values=1,
            row=0,
        )
        self.event_select.callback = self.select_event
        self.add_item(self.event_select)

        self.punish_select = discord.ui.Select(
            placeholder="Choose the escalation action",
            options=[
                discord.SelectOption(label="Ban executor", value="ban"),
                discord.SelectOption(label="Quarantine executor", value="quarantine"),
            ],
            row=4,
        )
        self.punish_select.callback = self.select_punishment
        self.add_item(self.punish_select)

    async def load_state(self):
        async with self.bot.db.execute(
            "SELECT enabled FROM antinuke_settings WHERE guild_id=?",
            (self.guild.id,),
        ) as cursor:
            row = await cursor.fetchone()
        self.global_enabled = bool(row and row[0])

        async with self.bot.db.execute(
            "SELECT event_name, enabled FROM antinuke_v2_events WHERE guild_id=?",
            (self.guild.id,),
        ) as cursor:
            self.event_states = {name: bool(enabled) for name, enabled in await cursor.fetchall()}

        async with self.bot.db.execute(
            "SELECT recreate_channels, recreate_roles, punish_action, action_threshold, "
            "action_window_seconds, log_channel_id FROM antinuke_v2_settings WHERE guild_id=?",
            (self.guild.id,),
        ) as cursor:
            row = await cursor.fetchone()
        self.settings = row or (1, 1, "ban", 3, 10, None)
        for option in self.punish_select.options:
            option.default = option.value == self.settings[2]

        async with self.bot.db.execute(
            "SELECT incident_id,event_name,executor_id,severity,risk_score,created_at "
            "FROM antinuke_incidents WHERE guild_id=? ORDER BY incident_id DESC LIMIT 3",
            (self.guild.id,),
        ) as cursor:
            self.incidents = await cursor.fetchall()
        self._sync_event_options()

    def _sync_event_options(self):
        start = self.page * self.PAGE_SIZE
        page_events = self.events[start : start + self.PAGE_SIZE]
        self.event_select.options = [
            discord.SelectOption(
                label=f"{'ON' if self.event_states.get(key, True) else 'OFF'} · {label}"[:100],
                value=key,
                default=key == self.selected_event,
            )
            for key, label in page_events
        ]
        self.previous_page.disabled = self.page <= 0
        self.next_page.disabled = start + self.PAGE_SIZE >= len(self.events)

    def make_embed(self):
        recreate_channels, recreate_roles, punish_action, threshold, window, log_channel_id = self.settings
        embed = discord.Embed(
            color=0xFFDD00,
            title="Falcon Anti-Nuke Dashboard",
            description=(
                f"**Protection:** {'ENABLED' if self.global_enabled else 'DISABLED'}\n"
                f"**Escalation:** {punish_action.title()} after {threshold} attributed event(s) in {window}s\n"
                f"**Channel recovery:** {'ON' if recreate_channels else 'OFF'} · "
                f"**Role recovery:** {'ON' if recreate_roles else 'OFF'}\n"
                f"**Log channel:** {f'<#{log_channel_id}>' if log_channel_id else 'System channel'}"
            ),
        )
        start = self.page * self.PAGE_SIZE
        event_lines = [
            f"{'✅' if self.event_states.get(key, True) else '❌'} **{label}**"
            for key, label in self.events[start : start + self.PAGE_SIZE]
        ]
        embed.add_field(
            name=f"Event Guards · Page {self.page + 1}/{(len(self.events) + self.PAGE_SIZE - 1) // self.PAGE_SIZE}",
            value="\n".join(event_lines) or "No event guards configured.",
            inline=False,
        )
        if self.incidents:
            incident_lines = []
            for incident_id, event_name, executor_id, severity, score, created_at in self.incidents:
                try:
                    timestamp = discord.utils.format_dt(
                        datetime.datetime.fromisoformat(created_at), style="R"
                    )
                except (TypeError, ValueError):
                    timestamp = "time unknown"
                incident_lines.append(
                    f"`#{incident_id}` **{severity}** · {event_name} · `{score}/100` · "
                    f"<@{executor_id}> · {timestamp}"
                )
            embed.add_field(name="Recent Incidents", value="\n".join(incident_lines), inline=False)
        if self.notice:
            embed.add_field(name="Status", value=self.notice, inline=False)
        if self.bot.user:
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        embed.set_footer(text="Use the event menu to select a guard, then toggle it. Text commands remain available.")
        return embed

    async def interaction_check(self, interaction):
        if interaction.user.id == self.owner_id:
            return True
        await send_interaction_v2(
            interaction,
            "Only the administrator who opened this Anti-Nuke dashboard can use it.",
            ephemeral=True,
            allow_ephemeral=True,
        )
        return False

    async def _refresh(self, interaction):
        await self.load_state()
        await edit_interaction_v2(interaction, embed=self.make_embed(), view=self)

    async def select_event(self, interaction):
        self.selected_event = self.event_select.values[0]
        self.notice = f"Selected `{self.selected_event}`. Use Toggle Event to change it."
        await self._refresh(interaction)

    async def _set_event(self, event_name, enabled):
        await self.bot.db.execute(
            "INSERT INTO antinuke_v2_events (guild_id,event_name,enabled) VALUES (?,?,?) "
            "ON CONFLICT(guild_id,event_name) DO UPDATE SET enabled=excluded.enabled",
            (self.guild.id, event_name, int(enabled)),
        )
        await self.bot.db.commit()

    async def save_threshold(self, threshold, window_seconds):
        await self.bot.db.execute(
            "INSERT INTO antinuke_v2_settings "
            "(guild_id,action_threshold,action_window_seconds) VALUES (?,?,?) "
            "ON CONFLICT(guild_id) DO UPDATE SET action_threshold=excluded.action_threshold, "
            "action_window_seconds=excluded.action_window_seconds",
            (self.guild.id, threshold, window_seconds),
        )
        await self.bot.db.commit()
        from main import _AN_ENFORCED_UNTIL, _AN_RISK_TRACKER

        for risk_key in tuple(_AN_RISK_TRACKER):
            if risk_key[0] == self.guild.id:
                _AN_RISK_TRACKER.pop(risk_key, None)
                _AN_ENFORCED_UNTIL.pop(risk_key, None)

    @discord.ui.button(label="Previous", style=discord.ButtonStyle.secondary, row=1)
    async def previous_page(self, interaction, _button):
        self.page = max(0, self.page - 1)
        self.notice = None
        await self._refresh(interaction)

    @discord.ui.button(label="Next", style=discord.ButtonStyle.secondary, row=1)
    async def next_page(self, interaction, _button):
        max_page = max(0, (len(self.events) - 1) // self.PAGE_SIZE)
        self.page = min(max_page, self.page + 1)
        self.notice = None
        await self._refresh(interaction)

    @discord.ui.button(label="Threshold", style=discord.ButtonStyle.secondary, row=1)
    async def edit_threshold(self, interaction, _button):
        await interaction.response.send_modal(AntiNukeThresholdModal(self))

    @discord.ui.button(label="Toggle Event", style=discord.ButtonStyle.primary, row=2)
    async def toggle_event(self, interaction, _button):
        if self.selected_event is None:
            self.notice = "Select an event first."
        else:
            await self._set_event(
                self.selected_event,
                not self.event_states.get(self.selected_event, True),
            )
            self.notice = f"Updated `{self.selected_event}`."
        await self._refresh(interaction)

    @discord.ui.button(label="All Events On", style=discord.ButtonStyle.success, row=2)
    async def all_events_on(self, interaction, _button):
        await self.bot.db.executemany(
            "INSERT INTO antinuke_v2_events (guild_id,event_name,enabled) VALUES (?,?,1) "
            "ON CONFLICT(guild_id,event_name) DO UPDATE SET enabled=1",
            [(self.guild.id, event_name) for event_name, _label in self.events],
        )
        await self.bot.db.commit()
        self.notice = "All Anti-Nuke event guards are enabled."
        await self._refresh(interaction)

    @discord.ui.button(label="All Events Off", style=discord.ButtonStyle.danger, row=2)
    async def all_events_off(self, interaction, _button):
        await self.bot.db.executemany(
            "INSERT INTO antinuke_v2_events (guild_id,event_name,enabled) VALUES (?,?,0) "
            "ON CONFLICT(guild_id,event_name) DO UPDATE SET enabled=0",
            [(self.guild.id, event_name) for event_name, _label in self.events],
        )
        await self.bot.db.commit()
        self.notice = "All Anti-Nuke event guards are disabled."
        await self._refresh(interaction)

    @discord.ui.button(label="Protection On / Off", style=discord.ButtonStyle.primary, row=3)
    async def toggle_protection(self, interaction, _button):
        enabled = not self.global_enabled
        if enabled:
            try:
                from main import _ensure_antinuke_log

                await _ensure_antinuke_log(self.guild)
            except (discord.Forbidden, discord.HTTPException, RuntimeError) as error:
                self.notice = f"Could not prepare the Anti-Nuke log channel: {error}"
                return await self._refresh(interaction)
        await self.bot.db.execute(
            "INSERT INTO antinuke_settings (guild_id,enabled) VALUES (?,?) "
            "ON CONFLICT(guild_id) DO UPDATE SET enabled=excluded.enabled",
            (self.guild.id, int(enabled)),
        )
        await self.bot.db.commit()
        self.notice = f"Anti-Nuke protection {'enabled' if enabled else 'disabled'}."
        await self._refresh(interaction)

    @discord.ui.button(label="Channel Restore On / Off", style=discord.ButtonStyle.secondary, row=3)
    async def toggle_channel_restore(self, interaction, _button):
        value = 0 if self.settings[0] else 1
        await self.bot.db.execute(
            "INSERT INTO antinuke_v2_settings (guild_id,recreate_channels) VALUES (?,?) "
            "ON CONFLICT(guild_id) DO UPDATE SET recreate_channels=excluded.recreate_channels",
            (self.guild.id, value),
        )
        await self.bot.db.commit()
        self.notice = f"Channel recovery {'enabled' if value else 'disabled'}."
        await self._refresh(interaction)

    @discord.ui.button(label="Role Restore On / Off", style=discord.ButtonStyle.secondary, row=3)
    async def toggle_role_restore(self, interaction, _button):
        value = 0 if self.settings[1] else 1
        await self.bot.db.execute(
            "INSERT INTO antinuke_v2_settings (guild_id,recreate_roles) VALUES (?,?) "
            "ON CONFLICT(guild_id) DO UPDATE SET recreate_roles=excluded.recreate_roles",
            (self.guild.id, value),
        )
        await self.bot.db.commit()
        self.notice = f"Role recovery {'enabled' if value else 'disabled'}."
        await self._refresh(interaction)

    async def select_punishment(self, interaction):
        action = self.punish_select.values[0]
        await self.bot.db.execute(
            "INSERT INTO antinuke_v2_settings (guild_id,punish_action) VALUES (?,?) "
            "ON CONFLICT(guild_id) DO UPDATE SET punish_action=excluded.punish_action",
            (self.guild.id, action),
        )
        await self.bot.db.commit()
        self.notice = f"Escalation action set to {action}."
        await self._refresh(interaction)


class AntiNukeThresholdModal(discord.ui.Modal):
    def __init__(self, view):
        super().__init__(title="Anti-Nuke Threshold")
        self.view = view
        self.action_threshold = discord.ui.TextInput(
            label="Attributed actions (1-20)",
            default=str(view.settings[3]),
            min_length=1,
            max_length=2,
        )
        self.window_seconds = discord.ui.TextInput(
            label="Time window in seconds (5-60)",
            default=str(view.settings[4]),
            min_length=1,
            max_length=2,
        )
        self.add_item(self.action_threshold)
        self.add_item(self.window_seconds)

    async def on_submit(self, interaction):
        try:
            threshold = int(self.action_threshold.value)
            window_seconds = int(self.window_seconds.value)
        except ValueError:
            return await interaction.response.send_message(
                "Enter whole numbers for both values.", ephemeral=True
            )
        if not 1 <= threshold <= 20 or not 5 <= window_seconds <= 60:
            return await interaction.response.send_message(
                "Actions must be 1-20 and the time window must be 5-60 seconds.",
                ephemeral=True,
            )
        await self.view.save_threshold(threshold, window_seconds)
        await self.view.load_state()
        self.view.notice = (
            f"Punishment threshold updated to {threshold} action(s) in {window_seconds}s."
        )
        await interaction.response.send_message(
            embed=self.view.make_embed(),
            view=self.view,
        )
