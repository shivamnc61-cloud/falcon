"""Persistent ticket and reaction-role features for Falcon (discord.py 2.x)."""

import asyncio
import datetime
import html
import io
import logging
import re

import aiosqlite
import discord
from discord.ext import commands


LOGGER = logging.getLogger(__name__)
UTC = datetime.timezone.utc
TEMPLATE_NAME_PATTERN = re.compile(r"^[a-z0-9][a-z0-9_-]{0,31}$")
TICKET_OPEN_CUSTOM_ID = "denycord_ticket_open:v1"
TICKET_CLOSE_CUSTOM_ID = "denycord_ticket_close:v1"


def _now() -> str:
    return datetime.datetime.now(UTC).isoformat()


def _ticket_filename(value: str) -> str:
    value = re.sub(r"[^a-z0-9-]+", "-", value.casefold()).strip("-")
    return (value or "member")[:32]


def _escape(value: object) -> str:
    return html.escape(str(value), quote=True)


class TicketPanelView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(
        label="Open a Ticket",
        style=discord.ButtonStyle.primary,
        emoji="🎫",
        custom_id=TICKET_OPEN_CUSTOM_ID,
    )
    async def open_ticket(self, interaction: discord.Interaction, _button: discord.ui.Button):
        await self.cog.open_ticket(interaction)


class TicketCloseView(discord.ui.View):
    def __init__(self, cog):
        super().__init__(timeout=None)
        self.cog = cog

    @discord.ui.button(
        label="Close Ticket",
        style=discord.ButtonStyle.danger,
        emoji="🔒",
        custom_id=TICKET_CLOSE_CUSTOM_ID,
    )
    async def close_ticket(self, interaction: discord.Interaction, _button: discord.ui.Button):
        await self.cog.close_ticket(interaction)


class DenycordInteractionFeatures(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._setup_lock = asyncio.Lock()

    async def cog_load(self):
        db = self.bot.db
        await db.execute(
            "CREATE TABLE IF NOT EXISTS denycord_ticket_config ("
            "guild_id INTEGER PRIMARY KEY, category_id INTEGER NOT NULL, "
            "panel_channel_id INTEGER NOT NULL, panel_message_id INTEGER NOT NULL, "
            "log_channel_id INTEGER NOT NULL, setup_by INTEGER NOT NULL, created_at TEXT NOT NULL)"
        )
        await db.execute(
            "CREATE TABLE IF NOT EXISTS denycord_tickets ("
            "channel_id INTEGER PRIMARY KEY, guild_id INTEGER NOT NULL, owner_id INTEGER NOT NULL, "
            "opened_at TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', "
            "closed_at TEXT, closed_by INTEGER)"
        )
        await db.execute(
            "CREATE INDEX IF NOT EXISTS denycord_tickets_guild_status "
            "ON denycord_tickets(guild_id, status)"
        )
        await db.execute(
            "CREATE TABLE IF NOT EXISTS denycord_ticket_templates ("
            "guild_id INTEGER NOT NULL, name TEXT NOT NULL, content TEXT NOT NULL, "
            "updated_by INTEGER NOT NULL, updated_at TEXT NOT NULL, "
            "PRIMARY KEY(guild_id, name))"
        )
        await db.execute(
            "CREATE TABLE IF NOT EXISTS denycord_reaction_roles ("
            "guild_id INTEGER NOT NULL, message_id INTEGER NOT NULL, emoji TEXT NOT NULL, "
            "role_id INTEGER NOT NULL, created_by INTEGER NOT NULL, created_at TEXT NOT NULL, "
            "PRIMARY KEY(guild_id, message_id, emoji))"
        )
        await db.commit()
        self.bot.add_view(TicketPanelView(self))
        self.bot.add_view(TicketCloseView(self))

    async def _fetchone(self, query, parameters=()):
        async with self.bot.db.execute(query, parameters) as cursor:
            return await cursor.fetchone()

    async def _send_ctx(self, ctx: commands.Context, content: str):
        await ctx.send(content, ephemeral=ctx.interaction is not None)

    async def _send_interaction(self, interaction: discord.Interaction, content: str, *, ephemeral=True):
        if interaction.response.is_done():
            await interaction.followup.send(content, ephemeral=ephemeral)
        else:
            await interaction.response.send_message(content, ephemeral=ephemeral)

    def _bot_member(self, guild: discord.Guild):
        return guild.me or guild.get_member(self.bot.user.id)

    def _staff_overwrites(self, guild: discord.Guild, *, send_messages: bool):
        permissions = discord.PermissionOverwrite(
            view_channel=True,
            read_message_history=True,
            send_messages=send_messages,
        )
        staff_roles = sorted(
            (
                role for role in guild.roles
                if not role.is_default()
                and (role.permissions.administrator or role.permissions.manage_channels)
            ),
            key=lambda role: role.position,
            reverse=True,
        )
        return {role: permissions for role in staff_roles[:95]}

    async def _ticket_record(self, guild_id: int, channel_id: int):
        return await self._fetchone(
            "SELECT owner_id, status FROM denycord_tickets WHERE guild_id=? AND channel_id=?",
            (guild_id, channel_id),
        )

    async def _ticket_config(self, guild_id: int):
        return await self._fetchone(
            "SELECT category_id, panel_channel_id, panel_message_id, log_channel_id "
            "FROM denycord_ticket_config WHERE guild_id=?",
            (guild_id,),
        )

    async def open_ticket(self, interaction: discord.Interaction):
        if not interaction.response.is_done():
            try:
                await interaction.response.defer(ephemeral=True, thinking=True)
            except discord.NotFound as error:
                LOGGER.warning("Ticket-open interaction expired before it could be deferred: %s", error)
                return
        guild = interaction.guild
        if guild is None or not isinstance(interaction.user, discord.Member):
            return await self._send_interaction(interaction, "Tickets can only be opened in a server.")
        config = await self._ticket_config(guild.id)
        if not config:
            return await self._send_interaction(interaction, "Tickets have not been set up in this server yet.")
        category = guild.get_channel(config[0])
        bot_member = self._bot_member(guild)
        if not isinstance(category, discord.CategoryChannel) or bot_member is None:
            return await self._send_interaction(
                interaction,
                "The ticket category or bot member is unavailable. Ask an administrator to run `ticket_setup` again.",
            )

        existing = await self._fetchone(
            "SELECT channel_id FROM denycord_tickets "
            "WHERE guild_id=? AND owner_id=? AND status='open'",
            (guild.id, interaction.user.id),
        )
        if existing:
            channel = guild.get_channel(existing[0])
            if channel is not None:
                return await self._send_interaction(interaction, f"You already have an open ticket: {channel.mention}")
            await self.bot.db.execute(
                "UPDATE denycord_tickets SET status='missing' WHERE channel_id=?",
                (existing[0],),
            )
            await self.bot.db.commit()

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            bot_member: discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                read_message_history=True,
                manage_channels=True,
                attach_files=True,
                embed_links=True,
            ),
            interaction.user: discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                read_message_history=True,
                attach_files=True,
                embed_links=True,
            ),
        }
        overwrites.update(self._staff_overwrites(guild, send_messages=True))
        try:
            channel = await guild.create_text_channel(
                name=f"ticket-{_ticket_filename(interaction.user.name)}-{interaction.user.id % 10000:04d}",
                category=category,
                overwrites=overwrites,
                reason=f"Ticket opened by {interaction.user} ({interaction.user.id})",
            )
        except discord.HTTPException as error:
            LOGGER.warning("Could not create a ticket channel in guild %s: %s", guild.id, error)
            return await self._send_interaction(interaction, "I couldn't create your ticket channel. Check my channel permissions.")

        try:
            await channel.send(
                f"{interaction.user.mention}, describe the help you need. A staff member will respond here.",
                embed=discord.Embed(
                    title="Ticket Opened",
                    description="Use the button below when your issue is resolved. Closing creates an HTML transcript.",
                    color=0xFFDD00,
                ),
                view=TicketCloseView(self),
                allowed_mentions=discord.AllowedMentions(users=[interaction.user]),
            )
            await self.bot.db.execute(
                "INSERT INTO denycord_tickets(guild_id, channel_id, owner_id, opened_at, status) "
                "VALUES(?,?,?,?, 'open')",
                (guild.id, channel.id, interaction.user.id, _now()),
            )
            await self.bot.db.commit()
        except discord.HTTPException as error:
            LOGGER.warning("Could not initialize ticket %s: %s", channel.id, error)
            try:
                await channel.delete(reason="Ticket initialization failed")
            except discord.HTTPException as delete_error:
                LOGGER.warning("Could not clean up incomplete ticket %s: %s", channel.id, delete_error)
            return await self._send_interaction(interaction, "I couldn't initialize the ticket. Please try again or contact an administrator.")
        except aiosqlite.Error as error:
            await self.bot.db.rollback()
            LOGGER.exception("Could not save ticket %s: %s", channel.id, error)
            try:
                await channel.delete(reason="Ticket database write failed")
            except discord.HTTPException as delete_error:
                LOGGER.warning("Could not clean up unsaved ticket %s: %s", channel.id, delete_error)
            return await self._send_interaction(interaction, "I couldn't save the ticket. Please try again later.")
        await self._send_interaction(interaction, f"Your private ticket is ready: {channel.mention}")

    async def _build_transcript(self, channel: discord.TextChannel):
        messages = []
        async for message in channel.history(limit=500, oldest_first=True):
            parts = [f'<div class="message"><header>{_escape(message.author)} '
                     f'&lt;{message.author.id}&gt; · {_escape(message.created_at.isoformat())}</header>']
            content = message.clean_content or message.content
            if content:
                parts.append(f'<pre>{_escape(content)}</pre>')
            for embed in message.embeds:
                embed_text = " · ".join(value for value in (embed.title, embed.description) if value)
                if embed_text:
                    parts.append(f'<blockquote>{_escape(embed_text[:6000])}</blockquote>')
            for attachment in message.attachments:
                url = _escape(attachment.url)
                parts.append(
                    f'<p>Attachment: <a href="{url}">{_escape(attachment.filename)}</a> '
                    f'({attachment.size} bytes)</p>'
                )
            parts.append("</div>")
            messages.append("".join(parts))

        document = (
            "<!doctype html><html><head><meta charset=\"utf-8\">"
            f"<title>Ticket {channel.id} transcript</title>"
            "<style>body{font:15px system-ui,sans-serif;background:#1e1f22;color:#dbdee1;"
            "max-width:1000px;margin:2rem auto;padding:0 1rem}.message{padding:1rem;"
            "border-bottom:1px solid #3f4147}header{color:#aeb2b8;font-size:.85rem}"
            "pre{white-space:pre-wrap;overflow-wrap:anywhere;font:inherit}a{color:#00a8fc}"
            "blockquote{border-left:3px solid #5865f2;padding-left:.8rem}</style></head><body>"
            f"<h1>Ticket transcript · {_escape(channel.name)}</h1>"
            f"<p>Channel ID: {channel.id} · Guild: {_escape(channel.guild.name)} "
            f"· Exported: {_escape(_now())}</p>"
        )
        footer = "</body></html>"
        truncated = False
        max_size = max(64_000, getattr(channel.guild, "filesize_limit", 8_000_000))
        body = "".join(messages)
        rendered = (document + body + footer).encode("utf-8")
        while len(rendered) > max_size and messages:
            messages.pop(0)
            truncated = True
            note = '<p><em>Earlier messages were omitted to fit the upload limit.</em></p>' if truncated else ""
            rendered = (document + note + "".join(messages) + footer).encode("utf-8")
        return rendered

    async def _close_ticket_for_actor(self, guild, channel, actor, respond):
        if guild is None or not isinstance(channel, discord.TextChannel):
            return await respond("This is not a ticket channel.")
        record = await self._ticket_record(guild.id, channel.id)
        if not record or record[1] != "open":
            return await respond("This ticket is already closed or was not created by Falcon.")
        owner_id = record[0]
        is_staff = isinstance(actor, discord.Member) and (
            actor.guild_permissions.manage_channels
            or actor.guild_permissions.administrator
        )
        if actor.id != owner_id and not is_staff:
            return await respond("Only the ticket owner or a channel manager can close this ticket.")
        config = await self._ticket_config(guild.id)
        logs = guild.get_channel(config[3]) if config else None
        if not isinstance(logs, discord.TextChannel):
            return await respond("The configured ticket log channel is unavailable; this ticket was not closed.")
        try:
            transcript = await self._build_transcript(channel)
            file = discord.File(io.BytesIO(transcript), filename=f"ticket-{channel.id}-transcript.html")
            await logs.send(
                content=f"Transcript for ticket #{channel.name} (ID `{channel.id}`), closed by {actor.mention}.",
                file=file,
                allowed_mentions=discord.AllowedMentions.none(),
            )
        except discord.HTTPException as error:
            LOGGER.warning("Could not export ticket %s: %s", channel.id, error)
            return await respond("I couldn't upload the transcript, so this ticket remains open.")

        owner = guild.get_member(owner_id)
        owner_transcript_sent = False
        try:
            owner_user = owner or self.bot.get_user(owner_id) or await self.bot.fetch_user(owner_id)
            await owner_user.send(
                content=f"Transcript for your ticket in **{guild.name}**.",
                file=discord.File(
                    io.BytesIO(transcript),
                    filename=f"ticket-{channel.id}-transcript.html",
                ),
                allowed_mentions=discord.AllowedMentions.none(),
            )
            owner_transcript_sent = True
        except discord.HTTPException as error:
            LOGGER.warning("Could not DM transcript for ticket %s to owner %s: %s", channel.id, owner_id, error)

        try:
            if owner is not None:
                await channel.set_permissions(
                    owner,
                    overwrite=discord.PermissionOverwrite(
                        view_channel=False,
                        send_messages=False,
                        read_message_history=False,
                    ),
                    reason=f"Ticket closed by {actor} ({actor.id})",
                )
            await channel.edit(
                name=f"closed-{channel.id}",
                reason=f"Ticket closed by {actor} ({actor.id})",
            )
        except discord.HTTPException as error:
            LOGGER.warning("Transcript was saved, but ticket %s could not be locked: %s", channel.id, error)
            return await respond(
                "The transcript was saved, but I couldn't lock the channel. Check my permissions and close it again.",
            )
        try:
            await self.bot.db.execute(
                "UPDATE denycord_tickets SET status='closed', closed_at=?, closed_by=? "
                "WHERE guild_id=? AND channel_id=? AND status='open'",
                (_now(), actor.id, guild.id, channel.id),
            )
            await self.bot.db.commit()
        except aiosqlite.Error as error:
            await self.bot.db.rollback()
            LOGGER.exception("Could not record closure of ticket %s: %s", channel.id, error)
            return await respond("The transcript is saved and channel locked, but I couldn't record the closure.")
        owner_delivery = " The owner also received a DM copy." if owner_transcript_sent else " The owner could not be sent a DM copy."
        await respond(f"Ticket closed and HTML transcript sent to the configured logs.{owner_delivery}")

    async def close_ticket(self, interaction: discord.Interaction):
        if not interaction.response.is_done():
            try:
                await interaction.response.defer(ephemeral=True, thinking=True)
            except discord.NotFound as error:
                LOGGER.warning("Ticket-close interaction expired before it could be deferred: %s", error)
                return

        async def respond(content):
            await self._send_interaction(interaction, content, ephemeral=True)

        await self._close_ticket_for_actor(
            interaction.guild,
            interaction.channel,
            interaction.user,
            respond,
        )

    @commands.hybrid_group(name="ticket", invoke_without_command=True)
    async def ticket(self, ctx: commands.Context):
        await self._send_ctx(
            ctx,
            "Ticket commands: `,close`, `,delete`, `,rename <name>`, `ticket setup`, `ticket user_add`, `ticket user_remove`, "
            "and `ticket template_set|template_list|template_delete|template_post`.",
        )

    @commands.command(name="close", description="Close this ticket and export its transcript")
    @commands.guild_only()
    async def close_ticket_command(self, ctx: commands.Context):
        async def respond(content):
            await self._send_ctx(ctx, content)

        await self._close_ticket_for_actor(ctx.guild, ctx.channel, ctx.author, respond)

    @commands.command(name="delete", description="Delete a closed Falcon ticket")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_channels=True)
    async def delete_ticket_command(self, ctx: commands.Context):
        record = await self._ticket_record(ctx.guild.id, ctx.channel.id)
        if not record:
            return await self._send_ctx(ctx, "Use this command in a Falcon ticket.")
        if record[1] != "closed":
            return await self._send_ctx(ctx, "Close the ticket first with `,close` before deleting it.")
        try:
            await ctx.send("Deleting this closed ticket…")
            await ctx.channel.delete(reason=f"Closed ticket deleted by {ctx.author} ({ctx.author.id})")
        except discord.HTTPException as error:
            LOGGER.warning("Could not delete closed ticket %s: %s", ctx.channel.id, error)
            return
        try:
            await self.bot.db.execute(
                "UPDATE denycord_tickets SET status='deleted' WHERE guild_id=? AND channel_id=?",
                (ctx.guild.id, ctx.channel.id),
            )
            await self.bot.db.commit()
        except aiosqlite.Error as error:
            await self.bot.db.rollback()
            LOGGER.exception("Ticket %s was deleted but its database status was not updated: %s", ctx.channel.id, error)

    @commands.command(name="rename", description="Rename a Falcon ticket channel")
    @commands.guild_only()
    async def rename_ticket_command(self, ctx: commands.Context, *, name: str):
        record = await self._ticket_record(ctx.guild.id, ctx.channel.id)
        if not record or record[1] not in {"open", "closed"}:
            return await self._send_ctx(ctx, "Use this command in an open or closed Falcon ticket.")
        is_staff = ctx.author.guild_permissions.manage_channels or ctx.author.guild_permissions.administrator
        if ctx.author.id != record[0] and not is_staff:
            return await self._send_ctx(ctx, "Only the ticket owner or a channel manager can rename this ticket.")
        safe_name = _ticket_filename(name)
        if safe_name == "member" and not name.strip():
            return await self._send_ctx(ctx, "Provide a ticket name containing letters or numbers.")
        prefix = "closed-ticket" if record[1] == "closed" else "ticket"
        new_name = f"{prefix}-{safe_name}"[:100]
        try:
            await ctx.channel.edit(
                name=new_name,
                reason=f"Ticket renamed by {ctx.author} ({ctx.author.id})",
            )
        except discord.HTTPException as error:
            LOGGER.warning("Could not rename ticket %s: %s", ctx.channel.id, error)
            return await self._send_ctx(ctx, "I couldn't rename this ticket. Check my Manage Channels permission.")
        await self._send_ctx(ctx, f"Ticket renamed to `{new_name}`.")

    @ticket.command(name="setup", description="Create a private ticket category, panel, and transcript log")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_channels=True)
    async def ticket_setup(self, ctx: commands.Context):
        guild = ctx.guild
        bot_member = self._bot_member(guild)
        if bot_member is None or not bot_member.guild_permissions.manage_channels:
            return await self._send_ctx(ctx, "I need Manage Channels to set up tickets.")
        if not bot_member.guild_permissions.send_messages or not bot_member.guild_permissions.embed_links:
            return await self._send_ctx(ctx, "I need Send Messages and Embed Links permissions to post the ticket panel.")
        channel_permissions = ctx.channel.permissions_for(bot_member)
        if not channel_permissions.send_messages or not channel_permissions.embed_links:
            return await self._send_ctx(ctx, "I need Send Messages and Embed Links in this channel for the ticket panel.")

        async with self._setup_lock:
            current = await self._ticket_config(guild.id)
            if current:
                panel_channel = guild.get_channel(current[1])
                panel_message_id = current[2]
                suffix = f" Panel: {panel_channel.mention} (message `{panel_message_id}`)." if panel_channel else ""
                return await self._send_ctx(ctx, f"Ticket setup already exists. Existing channels and panel were left unchanged.{suffix}")

            category = None
            logs = None
            panel_message = None
            try:
                category = await guild.create_category(
                    name="Support Tickets",
                    overwrites={
                        guild.default_role: discord.PermissionOverwrite(view_channel=False),
                        bot_member: discord.PermissionOverwrite(
                            view_channel=True,
                            send_messages=True,
                            read_message_history=True,
                            manage_channels=True,
                        ),
                    },
                    reason=f"Ticket setup by {ctx.author} ({ctx.author.id})",
                )
                log_overwrites = {
                    guild.default_role: discord.PermissionOverwrite(view_channel=False),
                    bot_member: discord.PermissionOverwrite(
                        view_channel=True,
                        send_messages=True,
                        read_message_history=True,
                        attach_files=True,
                    ),
                }
                log_overwrites.update(self._staff_overwrites(guild, send_messages=True))
                logs = await guild.create_text_channel(
                    name="ticket-logs",
                    category=category,
                    overwrites=log_overwrites,
                    reason=f"Ticket setup by {ctx.author} ({ctx.author.id})",
                )
                panel = await ctx.send(
                    embed=discord.Embed(
                        title=f"{guild.name} Support",
                        description="Press **Open a Ticket** to create a private support channel. "
                                    "Only you, the bot, and server staff can see it.",
                        color=0xFFDD00,
                    ),
                    view=TicketPanelView(self),
                    allowed_mentions=discord.AllowedMentions.none(),
                )
                panel_message = panel
                await self.bot.db.execute(
                    "INSERT INTO denycord_ticket_config"
                    "(guild_id, category_id, panel_channel_id, panel_message_id, log_channel_id, setup_by, created_at) "
                    "VALUES(?,?,?,?,?,?,?)",
                    (guild.id, category.id, ctx.channel.id, panel.id, logs.id, ctx.author.id, _now()),
                )
                await self.bot.db.commit()
            except discord.HTTPException as error:
                await self.bot.db.rollback()
                LOGGER.warning("Ticket setup API operation failed in guild %s: %s", guild.id, error)
                await self._rollback_setup(panel_message, logs, category)
                return await self._send_ctx(ctx, "Ticket setup failed because Discord rejected an operation. Check permissions and try again.")
            except aiosqlite.Error as error:
                await self.bot.db.rollback()
                LOGGER.exception("Could not save ticket setup in guild %s: %s", guild.id, error)
                await self._rollback_setup(panel_message, logs, category)
                return await self._send_ctx(ctx, "Ticket setup could not be saved. Newly created setup resources were removed when possible.")
        await self._send_ctx(ctx, f"Ticket setup complete. Category: {category.mention} · Logs: {logs.mention} · Panel posted here.")

    async def _rollback_setup(self, panel_message, logs, category):
        if panel_message is not None:
            try:
                await panel_message.delete()
            except discord.HTTPException as error:
                LOGGER.warning("Could not remove failed ticket panel %s: %s", panel_message.id, error)
        for channel in (logs, category):
            if channel is not None:
                try:
                    await channel.delete(reason="Rolling back incomplete ticket setup")
                except discord.HTTPException as error:
                    LOGGER.warning("Could not remove incomplete ticket setup channel %s: %s", channel.id, error)

    @ticket.command(name="user_add", description="Add a member to this ticket")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_channels=True)
    async def ticket_user_add(self, ctx: commands.Context, member: discord.Member):
        record = await self._ticket_record(ctx.guild.id, ctx.channel.id)
        if not record or record[1] != "open":
            return await self._send_ctx(ctx, "Use this command in an open Falcon ticket.")
        if member.bot:
            return await self._send_ctx(ctx, "Bots cannot be added as ticket participants.")
        try:
            await ctx.channel.set_permissions(
                member,
                overwrite=discord.PermissionOverwrite(
                    view_channel=True,
                    send_messages=True,
                    read_message_history=True,
                    attach_files=True,
                    embed_links=True,
                ),
                reason=f"Ticket participant added by {ctx.author} ({ctx.author.id})",
            )
        except discord.HTTPException as error:
            LOGGER.warning("Could not add %s to ticket %s: %s", member.id, ctx.channel.id, error)
            return await self._send_ctx(ctx, "I couldn't update this ticket's permissions. Check my Manage Channels permission.")
        await self._send_ctx(ctx, f"Added {member.mention} to this ticket.")

    @ticket.command(name="user_remove", description="Remove a member from this ticket")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_channels=True)
    async def ticket_user_remove(self, ctx: commands.Context, member: discord.Member):
        record = await self._ticket_record(ctx.guild.id, ctx.channel.id)
        if not record or record[1] != "open":
            return await self._send_ctx(ctx, "Use this command in an open Falcon ticket.")
        if member.id == record[0]:
            return await self._send_ctx(ctx, "The ticket opener cannot be removed. Close the ticket instead.")
        try:
            await ctx.channel.set_permissions(
                member,
                overwrite=discord.PermissionOverwrite(
                    view_channel=False,
                    send_messages=False,
                    read_message_history=False,
                ),
                reason=f"Ticket participant removed by {ctx.author} ({ctx.author.id})",
            )
        except discord.HTTPException as error:
            LOGGER.warning("Could not remove %s from ticket %s: %s", member.id, ctx.channel.id, error)
            return await self._send_ctx(ctx, "I couldn't update this ticket's permissions. Check my Manage Channels permission.")
        await self._send_ctx(ctx, f"Removed {member.mention} from this ticket.")

    @ticket.command(name="template_set", description="Create or update a canned ticket template")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_channels=True)
    async def ticket_template_set(self, ctx: commands.Context, name: str, *, content: str):
        name = name.strip().casefold()
        content = content.strip()
        if not TEMPLATE_NAME_PATTERN.fullmatch(name):
            return await self._send_ctx(ctx, "Template names must be 1-32 letters, numbers, underscores, or hyphens.")
        if not content or len(content) > 2000:
            return await self._send_ctx(ctx, "Template content must contain 1-2000 characters.")
        try:
            await self.bot.db.execute(
                "INSERT INTO denycord_ticket_templates(guild_id,name,content,updated_by,updated_at) "
                "VALUES(?,?,?,?,?) ON CONFLICT(guild_id,name) DO UPDATE SET "
                "content=excluded.content, updated_by=excluded.updated_by, updated_at=excluded.updated_at",
                (ctx.guild.id, name, content, ctx.author.id, _now()),
            )
            await self.bot.db.commit()
        except aiosqlite.Error as error:
            await self.bot.db.rollback()
            LOGGER.exception("Could not save ticket template %s in guild %s: %s", name, ctx.guild.id, error)
            return await self._send_ctx(ctx, "I couldn't save that ticket template.")
        await self._send_ctx(ctx, f"Saved ticket template `{name}`.")

    @ticket.command(name="template_list", description="List this server's canned ticket templates")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_channels=True)
    async def ticket_template_list(self, ctx: commands.Context):
        async with self.bot.db.execute(
            "SELECT name FROM denycord_ticket_templates WHERE guild_id=? ORDER BY name LIMIT 50",
            (ctx.guild.id,),
        ) as cursor:
            rows = await cursor.fetchall()
        if not rows:
            return await self._send_ctx(ctx, "This server has no ticket templates yet.")
        await self._send_ctx(ctx, "Ticket templates: " + ", ".join(f"`{row[0]}`" for row in rows))

    @ticket.command(name="template_delete", description="Delete a canned ticket template")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_channels=True)
    async def ticket_template_delete(self, ctx: commands.Context, name: str):
        name = name.strip().casefold()
        try:
            cursor = await self.bot.db.execute(
                "DELETE FROM denycord_ticket_templates WHERE guild_id=? AND name=?",
                (ctx.guild.id, name),
            )
            await self.bot.db.commit()
        except aiosqlite.Error as error:
            await self.bot.db.rollback()
            LOGGER.exception("Could not delete ticket template %s in guild %s: %s", name, ctx.guild.id, error)
            return await self._send_ctx(ctx, "I couldn't delete that ticket template.")
        await self._send_ctx(ctx, f"Deleted ticket template `{name}`." if cursor.rowcount else f"No template named `{name}` exists.")

    @ticket.command(name="template_post", description="Post a canned template in this ticket")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_channels=True)
    async def ticket_template_post(self, ctx: commands.Context, name: str):
        record = await self._ticket_record(ctx.guild.id, ctx.channel.id)
        if not record or record[1] != "open":
            return await self._send_ctx(ctx, "Use this command in an open Falcon ticket.")
        row = await self._fetchone(
            "SELECT content FROM denycord_ticket_templates WHERE guild_id=? AND name=?",
            (ctx.guild.id, name.strip().casefold()),
        )
        if not row:
            return await self._send_ctx(ctx, f"No ticket template named `{name}` exists.")
        try:
            await ctx.channel.send(row[0], allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException as error:
            LOGGER.warning("Could not post ticket template in channel %s: %s", ctx.channel.id, error)
            return await self._send_ctx(ctx, "I couldn't post that template. Check my Send Messages permission.")
        await self._send_ctx(ctx, f"Posted ticket template `{name}`.")

    @ticket.command(name="template_add", description="Alias for template_set")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_channels=True)
    async def ticket_template_add(self, ctx: commands.Context, name: str, *, content: str):
        await self.ticket_template_set(ctx, name, content)

    @ticket.command(name="template_remove", description="Alias for template_delete")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_channels=True)
    async def ticket_template_remove(self, ctx: commands.Context, name: str):
        await self.ticket_template_delete(ctx, name)

    @commands.hybrid_command(name="rr_add", description="Alias for reactionrole add")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_roles=True)
    async def rr_add(self, ctx: commands.Context, message_id: int, emoji: str, role: discord.Role):
        await self.reactionrole_add(ctx, message_id, emoji, role)

    @commands.hybrid_command(name="rr_remove", description="Alias for reactionrole remove")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_roles=True)
    async def rr_remove(self, ctx: commands.Context, message_id: int, emoji: str):
        await self.reactionrole_remove(ctx, message_id, emoji)

    @commands.hybrid_command(name="rr_list", description="Alias for reactionrole list")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_roles=True)
    async def rr_list(self, ctx: commands.Context):
        await self.reactionrole_list(ctx)

    def _role_is_assignable(self, guild: discord.Guild, role: discord.Role):
        bot_member = self._bot_member(guild)
        if role.is_default() or role.managed:
            return False
        if bot_member is None or not bot_member.guild_permissions.manage_roles:
            return False
        return role < bot_member.top_role

    @commands.hybrid_group(name="reactionrole", invoke_without_command=True)
    async def reactionrole(self, ctx: commands.Context):
        await self._send_ctx(ctx, "Reaction-role commands: `reactionrole add`, `reactionrole list`, and `reactionrole remove`.")

    @reactionrole.command(name="add", description="Map a message reaction to a server role")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_roles=True)
    async def reactionrole_add(self, ctx: commands.Context, message_id: int, emoji: str, role: discord.Role):
        guild = ctx.guild
        if message_id <= 0:
            return await self._send_ctx(ctx, "Enter a valid Discord message ID.")
        if role.guild.id != guild.id:
            return await self._send_ctx(ctx, "Choose a role from this server.")
        if not self._role_is_assignable(guild, role):
            return await self._send_ctx(ctx, "I need Manage Roles, and my highest role must be above the selected role.")
        try:
            partial_emoji = discord.PartialEmoji.from_str(emoji.strip())
        except (TypeError, ValueError):
            return await self._send_ctx(ctx, "Enter a valid Unicode or custom emoji.")
        emoji_key = str(partial_emoji)
        if not emoji_key:
            return await self._send_ctx(ctx, "Enter a valid Unicode or custom emoji.")
        existing = await self._fetchone(
            "SELECT role_id FROM denycord_reaction_roles WHERE guild_id=? AND message_id=? AND emoji=?",
            (guild.id, message_id, emoji_key),
        )
        if existing:
            return await self._send_ctx(ctx, "That message and emoji already have a role mapping. Remove it before adding another.")
        try:
            await self.bot.db.execute(
                "INSERT INTO denycord_reaction_roles"
                "(guild_id,message_id,emoji,role_id,created_by,created_at) VALUES(?,?,?,?,?,?)",
                (guild.id, message_id, emoji_key, role.id, ctx.author.id, _now()),
            )
            await self.bot.db.commit()
        except aiosqlite.Error as error:
            await self.bot.db.rollback()
            LOGGER.exception("Could not save reaction role mapping for message %s: %s", message_id, error)
            return await self._send_ctx(ctx, "I couldn't save that reaction-role mapping.")
        await self._send_ctx(
            ctx,
            f"Mapped {emoji_key} on message `{message_id}` to {role.mention}. "
            "Add that reaction to the message; Falcon will assign or remove the role when users react.",
        )

    @reactionrole.command(name="list", description="List this server's reaction-role mappings")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_roles=True)
    async def reactionrole_list(self, ctx: commands.Context):
        async with self.bot.db.execute(
            "SELECT message_id, emoji, role_id FROM denycord_reaction_roles "
            "WHERE guild_id=? ORDER BY message_id, emoji LIMIT 50",
            (ctx.guild.id,),
        ) as cursor:
            rows = await cursor.fetchall()
        if not rows:
            return await self._send_ctx(ctx, "This server has no reaction-role mappings.")
        lines = []
        for message_id, emoji, role_id in rows:
            role = ctx.guild.get_role(role_id)
            role_label = role.mention if role else f"missing role `{role_id}`"
            lines.append(f"Message `{message_id}` · {emoji} → {role_label}")
        await self._send_ctx(ctx, "Reaction-role mappings:\n" + "\n".join(lines))

    @reactionrole.command(name="remove", description="Remove a reaction-role mapping")
    @commands.guild_only()
    @commands.has_guild_permissions(manage_roles=True)
    async def reactionrole_remove(self, ctx: commands.Context, message_id: int, emoji: str):
        try:
            emoji_key = str(discord.PartialEmoji.from_str(emoji.strip()))
        except (TypeError, ValueError):
            return await self._send_ctx(ctx, "Enter a valid Unicode or custom emoji.")
        try:
            cursor = await self.bot.db.execute(
                "DELETE FROM denycord_reaction_roles WHERE guild_id=? AND message_id=? AND emoji=?",
                (ctx.guild.id, message_id, emoji_key),
            )
            await self.bot.db.commit()
        except aiosqlite.Error as error:
            await self.bot.db.rollback()
            LOGGER.exception("Could not remove reaction role mapping for message %s: %s", message_id, error)
            return await self._send_ctx(ctx, "I couldn't remove that reaction-role mapping.")
        if cursor.rowcount:
            await self._send_ctx(ctx, f"Removed {emoji_key} mapping from message `{message_id}`.")
        else:
            await self._send_ctx(ctx, "No mapping for that message and emoji was found.")

    async def _handle_raw_reaction(self, payload: discord.RawReactionActionEvent, *, adding: bool):
        guild = self.bot.get_guild(payload.guild_id) if payload.guild_id else None
        if guild is None or payload.user_id == self.bot.user.id:
            return
        mapping = await self._fetchone(
            "SELECT role_id FROM denycord_reaction_roles WHERE guild_id=? AND message_id=? AND emoji=?",
            (guild.id, payload.message_id, str(payload.emoji)),
        )
        if mapping is None:
            return
        role = guild.get_role(mapping[0])
        if role is None or not self._role_is_assignable(guild, role):
            return
        member = payload.member if adding else guild.get_member(payload.user_id)
        if member is None:
            try:
                member = await guild.fetch_member(payload.user_id)
            except discord.NotFound:
                return
            except discord.Forbidden as error:
                LOGGER.warning("Cannot fetch reaction user %s in guild %s: %s", payload.user_id, guild.id, error)
                return
            except discord.HTTPException as error:
                LOGGER.warning("Cannot fetch reaction user %s in guild %s: %s", payload.user_id, guild.id, error)
                return
        if member.bot:
            return
        try:
            if adding:
                await member.add_roles(role, reason=f"Reaction role on message {payload.message_id}")
            else:
                await member.remove_roles(role, reason=f"Reaction role removed from message {payload.message_id}")
        except discord.Forbidden as error:
            LOGGER.warning("Role operation forbidden for %s in guild %s: %s", member.id, guild.id, error)
        except discord.HTTPException as error:
            LOGGER.warning("Role operation failed for %s in guild %s: %s", member.id, guild.id, error)

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        await self._handle_raw_reaction(payload, adding=True)

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload: discord.RawReactionActionEvent):
        await self._handle_raw_reaction(payload, adding=False)


async def setup(bot):
    await bot.add_cog(DenycordInteractionFeatures(bot))
