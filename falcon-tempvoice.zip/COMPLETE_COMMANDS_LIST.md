# Falcon Premium Bot - Complete Commands List

**Total Commands:** 600+ registered prefix commands (core commands + Power Command shortcuts)  
**Last Updated:** October 8, 2026

---

## 📑 Quick Navigation

- [Invite Commands](#invite-commands) (8)
- [Message Commands](#message-commands) (13)
- [Voice Commands](#voice-commands) (5)
- [VoiceMaster](#voicemaster) (28)
- [Tickets & Reaction Roles](#tickets--reaction-roles) (13)
- [Birthdays & Live Stats](#birthdays--live-stats) (7)
- [Server Backups](#server-backups) (4)
- [Reminder Commands](#reminder-commands) (3)
- [Leaderboard Commands](#leaderboard-commands) (8)
- [Auto-Role Commands](#auto-role-commands) (4)
- [Giveaway Commands](#giveaway-commands) (8)
- [Timer Commands](#timer-commands) (4)
- [Greeting Commands](#greeting-commands) (4)
- [Moderation Commands](#moderation-commands) (10)
- [Guild Event Logs](#guild-event-logs)
- [Poll Commands](#poll-commands) (2)
- [Utility Commands](#utility-commands) (5)
- [Premium Commands](#premium-commands) (3)
- [Admin Commands](#admin-commands) (12)
- [Help & Info Commands](#help--info-commands) (4)

---

## 👥 Invite Commands

Track invitations and who invited members.

| Command | Alias | Parameters | Permission | Description |
|---------|-------|-----------|-----------|-------------|
| `!invites` | `!i` | `[user]` | Anyone | View invite stats for a user (self if not specified) |
| `!inviter` | - | `[user]` | Anyone | See who invited a user |
| `!invited` | - | `[user]` | Anyone | View members invited by a user |
| `!inviteinfo` | - | `[user]` | Anyone | Detailed invite information for a user |
| `!addinvites` | - | `<user> <amount>` | Administrator | Add bonus invites to a user |
| `!removeinvites` | - | `<user> <amount>` | Administrator | Remove invites from a user |
| `!clearinvites` | - | `[user]` | Administrator | Clear all invites (for all users if not specified) |
| `!resetmyinvites` | - | None | Anyone | Reset your own invite stats |

### Invite Configuration Commands

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!setinviterole` | `<role> <invites>` | Manage Guild | Set auto-role at invite milestone |
| `!unsetinviterole` | `<role>` | Manage Guild | Remove invite role requirement |
| `!viewinviteroles` | None | Anyone | List all invite role requirements |
| `!setaltthreshold` | `<days>` | Manage Guild | Set account age threshold |
| `!unsetaltthreshold` | None | Manage Guild | Remove account age threshold |

---

## 💬 Message Commands

Track message counts across the guild.

| Command | Alias | Parameters | Permission | Description |
|---------|-------|-----------|-----------|-------------|
| `!messages` | `!m` | `[user]` | Anyone | View message stats for a user (self if not specified) |
| `!addmessages` | - | `<user> <amount>` | Administrator | Add messages to a user |
| `!removemessages` | - | `<user> <amount>` | Administrator | Remove messages from a user |
| `!clearmsgs` | - | `[user]` | Administrator | Clear all messages (for all users if not specified) |
| `!resetmymessages` | - | None | Anyone | Reset your own message stats |
| `!setmessagerole` | - | `<role> <count>` | Manage Guild | Set auto-role at message milestone |
| `!unsetmessagerole` | - | `<role>` | Manage Guild | Remove message role requirement |
| `!viewmessageroles` | - | None | Anyone | List all message role requirements |

### Blacklist Commands (exclude channels from tracking)

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!blacklistchannel` | `[channel]` | Manage Guild | Exclude channel from message tracking |
| `!unblacklistchannel` | `[channel]` | Manage Guild | Include channel in message tracking |
| `!blacklistedchannels` | None | Anyone | View all blacklisted channels |
| `!blacklistcategory` | `<category_name>` | Manage Guild | Exclude entire category from tracking |
| `!unblacklistcategory` | `<category_name>` | Manage Guild | Include category in tracking |
| `!blacklistedcategories` | None | Anyone | View all blacklisted categories |

### Message Configuration

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!setresettime` | `<mode> <time>` | Manage Guild | Set weekly/daily message reset time |
| `!variables` | None | Anyone | Show message variable placeholders |
| `!testmsg` | `<message>` | Manage Guild | Test join/leave message variables |

---

## 🎙️ Voice Commands

Track voice channel time.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!vc` | - | `[user]` | Anyone | View voice time stats for a user (self if not specified) |
| `!addvctime` | - | `<user> <seconds>` | Administrator | Add voice time to a user |
| `!reducevctime` | - | `<user> <seconds>` | Administrator | Remove voice time from a user |
| `!clearvoice` | - | `[user]` | Administrator | Clear all voice time (for all users if not specified) |
| `!resetmyvoice` | - | None | Anyone | Reset your own voice stats |

## VoiceMaster

Join the configured hub to create an open temporary voice room with an emoji-prefixed name. Empty managed rooms are deleted automatically. Room owners can lock rooms and manage individual member access.

| Command | Parameters | Permission | Description |
|---------|-----------|------------|-------------|
| `,voicehub` | `setup [hub] [panel] [category]` | Manage Guild | Create or reuse the hub and category, create a dedicated interface channel, and post one persistent golden control card |
| `,voicehub` | `status` / `disable` | Manage Guild | View or disable the hub (existing rooms remain managed) |
| `,room` / `,temp_vc` / `,temp` / `,tv` / `,temp_voice` | None | Anyone | Show the temporary voice-room command summary |
| `,room info` | None | Anyone | Show admin setup and owner command reference |
| `,room set_channel` | `<voice-channel>` | Manage Guild | Set the join-to-create channel |
| `,room set_category` | `[category]` | Manage Guild | Set or clear the category for new rooms |
| `,room rename` | `<name>` | Room owner | Rename your room with an emoji prefix |
| `,room limit` | `<0-99>` | Room owner | Set the user limit; zero means unlimited |
| `,room bitrate` | `<kbps>` | Room owner | Set room bitrate within the server's boost-tier limit |
| `,room region` | `[region]` | Room owner | List or set the RTC region (`auto` resets it) |
| `,room lock` / `,room unlock` | None | Room owner | Lock or unlock your room |
| `,room hide` / `,room unhide` | None | Room owner | Hide or show your room to other members |
| `,room allow` / `,room block` / `,room ban` | `<member>` | Room owner | Persistently allow or deny a member |
| `,room clear` | `[member]` | Room owner | Clear one member's overrides or all overrides |
| `,room permit` | `<member>` | Room owner | Allow a member to join and chat |
| `,room openchat` / `,room closechat` | None | Room owner | Open or close text-in-voice chat |
| `,room kick` / `,room mute` / `,room unmute` | `<member>` | Room owner | Disconnect or mute/unmute a room member |
| `,room summon` | `<member>` | Room owner | Move a member into your room |
| `,room claim` | None | Member in room | Claim a room after its owner leaves |
| `,room transfer` | `<member>` | Room owner | Transfer ownership to a current room member |
| `,room status` / `,room reset` | None | Room owner | View room state or reset settings and overrides |

---

## ⭐ XP & Leveling Commands

Leveling is disabled by default and must be enabled per server with `,leveling true`.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `,rank` | `[member]` | Anyone | Show a generated XP rank card with level progress and server position |
| `,levelprofile` | `[member]` | Anyone | Show the rank card, leveling profile, and daily streak |
| `,xpleaderboard` | `[limit 1-25]` | Anyone | View the server XP leaderboard |
| `,streak` | `[member]` | Anyone | View a daily-claim streak |
| `,claimreward` | None | Anyone | Claim daily XP and extend a consecutive-day streak |
| `,rewards` | None | Anyone | List level-based role rewards |
| `,serverstats` | None | Anyone | View server leveling statistics |
| `,leveling` | `[enabled] [reward_level] [reward_role]` | Manage Guild | Enable/disable XP and configure a level role reward |
| `,multiplier` | `<0.1-10>` | Manage Guild | Set the message XP multiplier |
| `,xpblacklist` | `add|remove @member` or `list` | Manage Guild | Exclude or restore a member's XP earning |
| `,voicexp` | `<amount> [interval_minutes]` | Manage Guild | Configure eligible voice XP |
| `,xpconfig` | `[daily_reward]` | Manage Guild | View settings or update the daily base reward |
| `,xpcooldown` | `<seconds>` | Manage Guild | Set message XP cooldown |
| `,xprange` | `<minimum> <maximum>` | Manage Guild | Set randomized message XP range |
| `,givexp` | `<member> <amount>` | Manage Guild | Grant XP to a member |
| `,setlevel` | `<member> <level>` | Manage Guild | Set a member's level |
| `,resetxp` | `<member>` | Manage Guild | Reset a member's XP, streak, and claim history |

Message XP, voice XP, eligible voice time, streaks, and reward roles are stored per server. Rank and profile commands render a custom card with the member avatar, level, total XP, progress bar, server position, and recorded voice time; profile cards also show the streak and voice activity. Voice XP and voice-time tracking exclude bots, AFK-channel users, and deafened users. Message XP has a per-member cooldown and duplicate-event protection.

---

## 🏆 Leaderboard Commands

View and manage leaderboards.

| Command | Subcommand | Parameters | Description |
|---------|-----------|-----------|-------------|
| `!leaderboard` / `!lb` | (main) | None | Main leaderboard view (invites) |
| `!lb` | `invites` / `!lb_invites` | None | View invite leaderboard |
| `!lb` | `messages` / `!lb_messages` | None | View total message leaderboard |
| `!lb` | `weekly` / `!lb_weekly` | None | View weekly message leaderboard |
| `!lb` | `daily` / `!lb_daily` | None | View daily message leaderboard |
| `!lb` | `voice` / `!lb_voice` | None | View total voice leaderboard |
| `!lb` | `weeklyvoice` / `!lb_weeklyvoice` | None | View weekly voice leaderboard |
| `!lb` | `dailyvoice` / `!lb_dailyvoice` | None | View daily voice leaderboard |

### Live Leaderboard Commands

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!createlivelb` | `[lb_type]` | Manage Guild | Create auto-updating leaderboard |
| `!deletelivelb` | `[lb_type]` | Manage Guild | Delete live leaderboard |
| `!showlivelbs` | None | Anyone | View all active live leaderboards |

---

## 🎭 Auto-Role Commands

Automatically assign roles on events.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!autorole` | None | Manage Guild | Show auto-role configuration menu |
| `!setautorole` | `<role> [type]` | Manage Guild | Add auto-role (type: all/bots/humans) |
| `!unsetautorole` | `<role>` | Manage Guild | Remove auto-role |
| `!viewautoroles` | None | Anyone | List all auto-roles |

---

## 🎉 Giveaway Commands

Create and manage giveaways.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!gcreate` | `<time> <winners> <prize>` | Manager+ | Create giveaway (react with 🎉 to enter) |
| `!gstart` | `<time> <winners> <prize>` | Manager+ | Start giveaway (alias for gcreate) |
| `!gwstart` | `<time> <winners> <prize>` | Manager+ | Start winner-role giveaway |
| `!greroll` | None | Manager+ | Reroll most recent giveaway |
| `!gend` | None | Manager+ | End active giveaway |
| `!setwin` | `<user>` | Manager+ | Force-set giveaway winner |
| `!finish` | None | Manager+ | Finish and announce giveaway winner |
| `!reroll` | None | Manager+ | Reroll last giveaway |

### Giveaway Configuration

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!setgiveaway` | None | Manager+ | Set giveaway winner role |
| `!unsetgiveaway` | None | Manager+ | Unset giveaway winner role |
| `!viewwinnerrole` | None | Anyone | View giveaway winner role |
| `!viewbypassrole` | None | Anyone | View bypass role (exclude from giveaway) |

---

## ⏱️ Timer Commands

Create countdowns and timers.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!tstart` | `<duration> [label]` | Anyone | Start a timer (e.g., "5m", "2h") |
| `!tpause` | None | Anyone | Pause active timer |
| `!tresume` | None | Anyone | Resume paused timer |
| `!tend` | None | Anyone | End active timer |

**Duration Format:** `10s`, `5m`, `1h`, `2d`

---

## 👋 Greeting Commands

Configure join/leave messages.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!setjoinchannel` | `[channel]` | Manage Guild | Set join message channel |
| `!unsetwelcomechannel` | None | Manage Guild | Remove join channel |
| `!setleave` | `[channel]` | Manage Guild | Set leave message channel |
| `!unsetleavechannel` | None | Manage Guild | Remove leave channel |
| `!setjoinmessage` | `<message>` | Manage Guild | Set custom join message |
| `!unsetjoinmessage` | None | Manage Guild | Remove custom join message |
| `!setleavemessage` | `<message>` | Manage Guild | Set custom leave message |
| `!unsetleavemessage` | None | Manage Guild | Remove custom leave message |
| `!setvanitymessage` | `<message>` | Manage Guild | Alternative message for vanity invites |
| `!unsetvanitymessage` | None | Manage Guild | Remove vanity message |

### Greeting Channel Commands

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!setgreet` | `[mode] [channel]` | Manage Guild | Add greeting channel (mode: embed/text) |
| `!disablegreet` | `[channel]` | Manage Guild | Remove greeting channel |
| `!greetchannels` | None | Anyone | List all greeting channels |
| `!greetvariables` | None | Anyone | Show greeting message variables |

**Message Variables:** `{user}`, `{username}`, `{server}`, `{membercount}`, `{inviter}`

---

## 🧩 Community Utility Commands

Autoresponders and custom text commands are stored per server. Destructive changes require a confirmation button.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `,autoresponder add` | `<trigger> <response>` | Manage Guild | Add a case-insensitive keyword response |
| `,autoresponder edit` | `<trigger> <response>` | Manage Guild | Change a configured response |
| `,autoresponder options` | `<trigger> [mode] [channel] [role] [cooldown] [enabled] [clear_restrictions]` | Manage Guild | Configure contains/exact/starts/ends matching, restrictions, and cooldown |
| `,autoresponder test` | `<trigger>` | Manage Guild | Send a preview of the configured response |
| `,autoresponder list` | None | Anyone | View response matching and access settings |
| `,autoresponder remove` | `<trigger>` | Manage Guild | Remove a configured response after confirmation |
| `,customcommand add` | `<name> <response> [cooldown] [role] [channel]` | Manage Guild | Create a server-scoped command invoked with the bot prefix |
| `,customcommand test` | `<name> [args]` | Manage Guild | Preview a custom command response without deleting the test message |
| `,customcommand list` | None | Anyone | List command restrictions and cooldowns |
| `,customcommand remove` | `<name>` | Manage Guild | Remove a custom command after confirmation |
| `,embed create` / `,embed edit` | `<name> [JSON config]` | Manage Guild | Create or edit a reusable embed |
| `,embed show` / `,embed list` | `[name]` | Anyone | Preview a saved embed or list saved embeds |
| `,embed delete` | `<name>` | Manage Guild | Delete an embed after confirmation |

Autoresponder and custom-command responses support existing user/server placeholders. Add `{delete}` to remove the triggering message, `{sendto:CHANNEL_ID}` (or a channel mention) to route the response, and `{embed:NAME}` to insert a saved embed. Custom commands also support `{args}` for text following the command name. Mentions are suppressed in generated responses.

---

## 🎫 Tickets & Reaction Roles

Ticket setup creates a private support category, a transcript-log channel, and a persistent button panel. Closing a ticket exports its HTML transcript to the log channel.

| Command | Parameters | Permission | Description |
|---------|-----------|------------|-------------|
| `,ticket setup` | None | Manage Channels | Create the ticket category, panel, and transcript log |
| `,close` | None | Ticket owner or Manage Channels | Export the transcript, lock, and close the current ticket |
| `,delete` | None | Manage Channels | Delete the current ticket after it has been closed |
| `,rename` | `<name>` | Ticket owner or Manage Channels | Rename the current open or closed ticket |
| `,ticket user_add` / `,ticket user_remove` | `<member>` | Manage Channels | Change access to the current open ticket |
| `,ticket template_set` | `<name> <text>` | Manage Channels | Create or update a reusable ticket response |
| `,ticket template_list` | None | Manage Channels | List saved ticket templates |
| `,ticket template_delete` | `<name>` | Manage Channels | Delete a saved template |
| `,ticket template_post` | `<name>` | Manage Channels | Post a template in an open ticket |
| `,reactionrole add` | `<message_id> <emoji> <role>` | Manage Roles | Map a message reaction to a role |
| `,reactionrole list` | None | Manage Roles | List reaction-role mappings |
| `,reactionrole remove` | `<message_id> <emoji>` | Manage Roles | Remove a reaction-role mapping |

Use the ticket panel's button to open a private ticket and the close button to save its transcript to logs and attempt delivery to the ticket owner's DMs before closing.

## 🎂 Birthdays & Live Stats

| Command | Parameters | Permission | Description |
|---------|-----------|------------|-------------|
| `,birthday setup` | `[#channel] [@role]` | Manage Guild | Set daily announcements; omit the channel to disable |
| `,birthday set` | `<month> <day>` | Anyone | Set your birthday in this server |
| `,birthday remove` | None | Anyone | Remove your birthday |
| `,birthday list` | None | Anyone | List birthdays registered in the server |
| `,birthday check` | None | Manage Guild | Manually announce today's registered birthdays |
| `,livestats setup` | None | Manage Channels | Create or refresh live member, human, bot, and boost voice stats |
| `,livestats remove` | None | Manage Channels | Delete configured live-stat voice channels |

The optional birthday role is assigned to birthday members for 24 hours, then removed automatically.

## 💤 Away Status

| Command | Parameters | Permission | Description |
|---------|-----------|------------|-------------|
| `,afk` | `[reason]` | Anyone | Set AFK status and temporarily prefix your nickname when Falcon can manage it |

Your AFK status clears when you send a message. Falcon restores your previous nickname if your nickname still has the `[AFK]` prefix; moderator changes made while you were away are preserved.

## 👋 Join Filter

| Command | Parameters | Permission | Description |
|---------|-----------|------------|-------------|
| `,joinfilter_setup` | `<enabled> [age_days] [no_avatar]` | Manage Messages | Configure account-age and profile-avatar join requirements |

Members who fail an enabled filter are sent a DM with the applicable reason before being kicked. If DMs are unavailable, Falcon logs that result and still enforces the configured filter.

## 💾 Server Backups

| Command | Parameters | Permission | Description |
|---------|-----------|------------|-------------|
| `,backup_create` | `<name>` | Administrator | Save roles, categories, and channel structure to Falcon's database |
| `,backup_list` | None | Manage Guild | List saved structure backups |
| `,backup_load` | `<name>` | Administrator | Preview and confirm a non-destructive restore of missing structure |
| `,backup_restore` | `<JSON attachment>` | Administrator | Validate an uploaded backup and preview a non-destructive restore |
| `,serverbackup` | `channel #channel` / `enable` / `disable` / `status` / `now` | Manage Guild | Configure hourly structure backups or create one immediately |

Manual backups are stored in Falcon's database and sent via Discord DM as a JSON structure export. Scheduled JSON snapshots are delivered to the selected channel. Backups are never restored automatically. Manual restore only creates missing roles and channels after confirmation; it does not overwrite existing resources.

---

## 🛡️ Moderation Commands

Manage members and messages.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!kick` | `<member> [reason]` | Kick Members | Kick member from guild |
| `!ban` | `<member> [reason]` | Ban Members | Ban member from guild |
| `!unban` | `<user_id>` | Ban Members | Unban user |
| `!mute` | `<member> [duration] [reason]` | Moderate Members | Mute member (default 10m) |
| `!unmute` | `<member>` | Moderate Members | Unmute member |
| `!erase` | `[amount]` | Manage Messages | Delete messages (default 10) |
| `,purge` | `[@member] <amount>` | Manage Messages | Delete recent channel messages, optionally from one member |
| `,purgeall` | None | Manage Messages | Delete all messages visible in the channel history |
| `,channel delete` | `[#channel]` | Owner or Administrator | Pick a channel from the dropdown, then confirm deletion; channel argument is optional |
| `,role add` / `,role remove` | `<member> <role>` | Manage Roles | Add or remove one role |
| `,role all bot` / `,role all humans` | `<role>` | Manage Roles | Assign a role to all bots or all human members |
| `,roleall` | `<role>` | Manage Roles | Assign a role to every member |
| `,role create` | `<alias> <role>` | Manage Roles | Create a persistent self-service role toggle command |
| `,warn` | `<member> [reason]` | Manage Messages | Record a member warning |
| `,warnings` | `[member]` | Manage Messages | View up to 20 active warnings |
| `,clearwarnings` | `<member>` | Manage Messages | Clear all warnings for a member |
| `,unwarn` | `<warning_id> [member]` | Manage Messages | Remove one warning |

### Command/Module Disabling

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!disable` | `<mode> <target>` | Administrator | Disable command/module in channel |
| `!enable` | `<mode> <target>` | Administrator | Enable command/module in channel |

**Modes:** `command` or `module`

### Automod Commands

- `automod status` - View global AutoMod and filter settings
- `automod native` - Open the Discord-native AutoMod dashboard for keyword, spam, mention, and profanity rules
- `automod enable|disable [invite|link|spam|duplicate|mentions|caps|emoji]` - Toggle AutoMod or one filter
- `automod limit spam <messages 2-20> <seconds 1-30>` - Configure flood detection threshold and time window
- `automod limit duplicate <2-20>` - Set repeated-message threshold
- `automod limit mentions <1-50>` - Set mention threshold
- `automod limit caps <50-100>` - Set uppercase percentage threshold
- `automod limit emoji <1-100>` - Set the maximum emoji count in a message
- `automod punishment set <threshold 1-100> <delete|timeout|kick|ban> [timeout_minutes]` - Add or update an escalation tier
- `automod punishment remove <threshold>` / `automod punishment list` - Manage escalation tiers
- `automod violations [member]` - View violations from this bot session (Manage Messages)
- `antinuke incidents` - View the ten newest persisted Anti-Nuke incidents with severity and risk scores
- `antinuke snapshots` - View the latest persisted channel/role baselines; `antinuke snapshot capture` refreshes them
- `antinuke` / `antinuke panel` - Open the paginated Anti-Nuke dashboard for event toggles, recovery, punishment mode, and thresholds
- `antinuke status` - View the text status and configuration summary
- Anti-Nuke also monitors native AutoMod rule creation, suspicious updates, protected-rule deletion, and bursts of five invite creates/deletes in ten seconds; configure guards with `antinuke event <event_name> on|off`
- `automod reset_violations [member]` - Reset a member's session count (Manage Guild)
- `automod exempt role|channel add|remove|list [target]` - Manage role/channel exemptions
- `automod log #channel|off` - Configure the AutoMod action log channel
- Native rules support block, 10-minute timeout, or alert-only actions and role/channel exemptions; keyword rules use `,filterword` entries
- Native AutoMod dashboard includes per-module seven-day action counts and recent enforcement logs
- Native AutoMod settings include offender DMs and optional one-hour timeout escalation after five violations in ten minutes
- `wl @member` - Open the member AutoMod filter picker; select enabled filters and Save, Whitelist All, or Remove All
- `automodwhitelist add|remove <user>` - Add or remove a global AutoMod user exemption
- `automodwhitelist list` - Open the security whitelist dashboard
- `securityowner` (alias `extraowner`) `add|remove @member` / `list` - Server owner manages trusted security owners
- Enabling AutoMod or Anti-Nuke creates a private security-log channel and webhook and posts a status embed
- AutoMod escalation counts are per server/member and reset when the bot restarts; with no matching rule, current defaults remain (message floods receive a five-minute timeout, other violations are deleted)
- Only the server owner and configured security owners can manage AutoMod or Anti-Nuke whitelists

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!automod` | `[action] [setting]` | Manage Guild | Configure automod (anti-link, anti-invite, anti-spam) |

---

## ⏰ Reminder Commands

| Command | Parameters | Permission | Description |
|---------|-----------|------------|-------------|
| `,remindme` | `<duration> <reminder>` | Anyone | Schedule a personal reminder |
| `,reminders_list` | None | Anyone | List your active reminders in this server or DM |
| `,reminders_cancel` | `<reminder_id>` | Anyone | Cancel one of your reminders |

---

## 📊 Poll Commands

Create and manage polls.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!createpoll` | `<args>` | Anyone | Create poll (custom format) |
| `!epoll` | None | Anyone | End most recent poll |

---

## 📋 Guild Event Logs

Configure a per-server event log. Logging is off until a server manager enables it. Deleted/edited message text is included in the configured log destination.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `,eventlog enable` | `[text_channel]` | Manage Guild | Enable event logging, using the private security log channel if no channel is supplied |
| `,setup_logs enable` | `[text_channel]` | Manage Guild | Alias for `,eventlog enable` |
| `,eventlog channel` | `<text_channel>` | Manage Guild | Change the event-log destination and enable logging |
| `,eventlog status` | None | Manage Guild | Show event-logging state and destination |
| `,eventlog disable` | None | Manage Guild | Disable general event logging |

Events: member joins/leaves/kicks/bans/unbans/timeouts, message edits/deletions and bulk deletions, voice state changes, and channel/role create/update/delete. Moderator attribution for kicks, bans, unbans, and timeouts is included when the audit-log entry is available; Falcon needs View Audit Log permission for attribution.

---

---

## 🔧 Utility Commands

General bot utilities.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!ping` | None | Anyone | Check bot latency |
| `,status` | None | Anyone | View bot servers, users, latency, uptime, memory, and Python version |
| `,stats` | None | Anyone | View bot servers, users, latency, uptime, memory, and Python version |
| `!serverinfo` | None | Anyone | View guild information |
| `!userinfo` | `[user]` | Anyone | View user details (self if not specified) |
| `!avatar` | `[user]` | Anyone | View user avatar (self if not specified) |
| `!crypto` | `[symbol]` | Anyone | Get crypto price (e.g., BTC, ETH) |

Channel access commands require Manage Channels and default to the current channel when no target is provided.

| Command | Parameters | Permission | Description |
|---------|-----------|------------|-------------|
| `,lock` | `[channel]` | Manage Channels | Stop sending in text channels or connecting to voice channels |
| `,unlock` | `[channel]` | Manage Channels | Restore inherited sending or connect permissions |
| `,hide` | `[channel]` | Manage Channels | Hide a channel from @everyone |
| `,unhide` | `[channel]` | Manage Channels | Restore inherited visibility |

---

## ⭐ Premium Commands

Manage premium status.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!premium` | `<action> [target]` | Owner | Manage premium (add, remove, check) |
| `!premium_add` | `[user] [days]` | Owner | Add premium to user (default 30 days) |
| `!premium_remove` | `[user]` | Owner | Remove premium from user |

### No-Prefix Feature

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!noprefix` | `<action> <user> [duration]` | Owner | Allow commands without prefix for user |

---

## 👨‍💼 Admin Commands

Bot owner and staff management.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!setowner` | `<user>` | Primary Owner | Add bot owner |
| `!unsetowner` | `<user>` | Primary Owner | Remove bot owner |
| `!owners` | None | Anyone | List all bot owners |
| `!setstaff` | `<user>` | Bot Owner | Add bot staff member |
| `!unsetstaff` | `<user>` | Bot Owner | Remove bot staff member |
| `!staff` | None | Anyone | List all bot staff |
| `!blacklist_user` | `<user> [reason]` | Bot Owner | Blacklist user from bot |
| `!customize` | `[action] [url]` | Bot Owner | Customize bot appearance |
| `!emoji` | `[arg]` | Bot Owner | Manage custom emojis |
| `!refresh_emojis` | None | Bot Owner | Refresh emoji cache |
| `!reset_emojis` | None | Bot Owner | Reset to default emojis |
| `!bonus` | `<user> <amount>` | Bot Owner | Quick add invites to user |

---

## ℹ️ Help & Info Commands

Get help and information about the bot.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!help` | None | Anyone | Open interactive help menu |
| `!credits` | None | Anyone | View bot credits and developers |
| `!about` | None | Anyone | About Falcon Premium Bot |

---

## 🛡️ Security & Anti-Raid Commands

Protect guild from raids and nukes.

| Command | Parameters | Permission | Description |
|---------|-----------|-----------|-------------|
| `!antinuke` | `[subcommand]` | Manage Guild | Configure antinuke protection |
| `!antiraid` | `[enable|lockdown|disable] [limit] [window] [minutes]` | Administrator | Configure join-spike response |

### Antinuke Subcommands

- `enable` / `disable` - Enable or disable anti-nuke protection
- `event <name> on|off` - Toggle an event, including `dangerous_role_add`
- Event names include `unban`, `emoji_create|emoji_update|emoji_delete`, `sticker_create|sticker_update|sticker_delete`, `scheduled_event_create|scheduled_event_update|scheduled_event_delete`, `role_ping`, `role_link`, and `member_update`, in addition to the existing protection events
- `role_ping` removes messages that ping 3 or more roles; `role_link` blocks links/invites unless the member is trusted for that event
- `config threshold <actions> <seconds>` - Set the cross-action punishment threshold (1-20 actions, 5-60 seconds)
- `wl add @user [events|*]` / `wl remove @user` / `wl list` - Manage event-specific exemptions
- `wl role add|remove @role [events|*]` / `wl role list` - Manage trusted moderator-role exemptions
- `quarantine @user [reason]` / `unquarantine @user` - Manually quarantine a member; stripped roles are not restored automatically
- `config recreate on|off` - Toggle deleted-channel recovery
- `config recreate_roles on|off` - Toggle deleted-role recovery
- `config log #channel` - Set the anti-nuke security log destination
- `config quarantine @role` - Set and sync a locked-down quarantine role
- `config punish ban|quarantine` - Choose automatic enforcement
- Run `,antinuke` to view protection, recovery, whitelist, and log status
- Enabling AutoMod or Anti-Nuke posts a combined module-status embed to the security log webhook and command channel
- Audit-driven actions require View Audit Log and only punish a recent, target-matched entry with a known actor
- Automatic ban/quarantine waits until the configured number of attributed actions is reached; channel/role recovery and unauthorized-action rollback still run immediately
- Integration create/update events are removed when possible; integration deletion cannot be restored automatically
- Member prune detection relies on the guild-wide prune audit entry, so the bot avoids attributing an individual member removal to an unknown actor
- Native AutoMod rule create/update/delete gateway events are handled: unauthorized rules are deleted, risky updates are reverted, and protected-rule deletions are recreated when Discord permissions allow

### Anti-Raid Subcommands

- `enable` - Enable anti-raid
- `disable` - Disable anti-raid
- `set <limit> <window>` - Set join threshold
- `lockdown <limit> <window> <minutes>` - Temporarily lock channels and restore their previous permissions automatically
- During lockdown, new accounts with high account risk (very new and no custom avatar) are timed out for 10 minutes when bot permissions and role hierarchy allow it; the action is logged
- `restore` - End an active lockdown and restore channel permissions
- `status` - Show status

---

## 📋 Command Groups Summary

| Category | Commands | Total |
|----------|----------|-------|
| Invites | invites, i, inviter, invited, inviteinfo, addinvites, removeinvites, clearinvites, resetmyinvites | 9 |
| Messages | messages, m, addmessages, removemessages, clearmsgs, resetmymessages, blacklistchannel, unblacklistchannel, blacklistedchannels, blacklistcategory, unblacklistcategory, blacklistedcategories, setmessagerole, unsetmessagerole, viewmessageroles, setresettime, variables, testmsg | 18 |
| Voice | vc, addvctime, reducevctime, clearvoice, resetmyvoice | 5 |
| Leaderboards | leaderboard, lb, lb_invites, lb_messages, lb_weekly, lb_daily, lb_voice, lb_weeklyvoice, lb_dailyvoice, createlivelb, deletelivelb, showlivelbs | 12 |
| Auto-Roles | autorole, setautorole, unsetautorole, viewautoroles | 4 |
| Giveaways | gcreate, gstart, gwstart, greroll, gend, setwin, finish, reroll, setgiveaway, unsetgiveaway, viewwinnerrole, viewbypassrole | 12 |
| Timers | tstart, tpause, tresume, tend | 4 |
| Greetings | setjoinchannel, unsetwelcomechannel, setleave, unsetleavechannel, setjoinmessage, unsetjoinmessage, setleavemessage, unsetleavemessage, setvanitymessage, unsetvanitymessage, setgreet, disablegreet, greetchannels, greetvariables | 14 |
| Moderation | kick, ban, unban, mute, unmute, erase, warn, warnings, clearwarnings, unwarn, disable, enable, automod | 13 |
| VoiceMaster | voicehub, room info, room set_channel, room set_category, room lock, room unlock, room hide, room unhide, room rename, room limit, room bitrate, room region, room allow, room block, room ban, room clear, room permit, room openchat, room closechat, room kick, room mute, room unmute, room summon, room claim, room transfer, room status, room reset | 28 |
| Tickets & Reaction Roles | ticket setup, close, delete, rename, ticket user_add, ticket user_remove, ticket template_set, ticket template_list, ticket template_delete, ticket template_post, reactionrole add, reactionrole list, reactionrole remove | 13 |
| Birthdays & Live Stats | birthday setup, birthday set, birthday remove, birthday list, birthday check, livestats setup, livestats remove | 7 |
| Server Backups | backup_create, backup_list, backup_load, serverbackup | 4 |
| Reminders | remindme, reminders_list, reminders_cancel | 3 |
| Polls | createpoll, epoll | 2 |
| Utility | ping, status, stats, serverinfo, userinfo, avatar, crypto, lock, unlock, hide, unhide | 11 |
| Premium | premium, premium_add, premium_remove, noprefix | 4 |
| Admin | setowner, unsetowner, owners, setstaff, unsetstaff, staff, blacklist_user, customize, emoji, refresh_emojis, reset_emojis, bonus | 12 |
| Help | help, credits, about | 3 |
| Security | antinuke, antiraid | 2 |

**Total Commands: ~120+**

---

## 🔑 Command Prefixes

- Primary Prefix: `!`
- Secondary Prefix: `,`
- No Prefix Mode: Available to premium users (e.g., `invites` works without prefix)

---

## ⚙️ Permission Levels

- **Anyone:** No special permissions required
- **Manage Guild:** Requires manage_guild permission
- **Manage Messages:** Requires manage_messages permission
- **Moderate Members:** Requires moderate_members permission
- **Ban Members:** Requires ban_members permission
- **Kick Members:** Requires kick_members permission
- **Administrator:** Requires administrator permission
- **Bot Owner:** Owner account or in bot_owners DB table
- **Bot Staff:** Owner/Staff account or in bot_staff DB table
- **Primary Owner:** Hardcoded PRIMARY_OWNER_IDS (immutable)

---

## 💡 Tips & Tricks

1. **Invite Tracking:** Automatically tracks who invited whom when they join
2. **Auto-Roles:** Can assign roles based on invites, messages, or on all/bots/humans
3. **Live Leaderboards:** Updates every 30 seconds automatically
4. **Message Variables:** Use `{user}`, `{username}`, `{server}`, `{membercount}`, `{inviter}` in custom messages
5. **Giveaways:** React with 🎉 to enter, bot picks random winner
6. **Voice Tracking:** Separate counters for alltime, weekly, and daily voice time
7. **Blacklisting:** Channels/categories can be excluded from message tracking
8. **No-Prefix:** Premium users can use commands without prefix
9. **Antinuke:** Protects against server raids and unauthorized changes

---

**End of Commands List**

Generated: July 29, 2026


## Stability & Power Update
- `,setup create` / `,setup staff` / `,setup vip` / `,setup friends` / `,setup remove` / `,setup list`
- `,extraowner add|remove|list`
- `,customize name|bio|avatar|banner|reset`
- `,lock all` / `,unlock all`
- `,hide all` / `,unhide all`
- `,commandcount`
- Global user No-Prefix remains active across every guild until expiry/removal.
- Invite creation is never an Anti-Nuke punishment.
